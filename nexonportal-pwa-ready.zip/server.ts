import express from "express";
import path from "path";
import { GoogleGenAI, ThinkingLevel } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Access the API key dynamically from a robust key rotation pool.
// Supports KEY1, KEY2, KEY3... as well as GEMINI_API_KEY and GEMINI_API_KEY_1..50.
let activeGeminiKeyIndex = 0;

function cleanApiKey(key: string | undefined): string {
  if (!key) return "";
  // Strip zero-width spaces, zero-width non-joiners, direction marks, and non-printable ASCII
  return key
    .replace(/[\u200b\u200c\u200d\ufeff\u200e\u200f]/g, "")
    .replace(/[^\x20-\x7E]/g, "")
    .trim();
}

function getGeminiApiKeys(): string[] {
  const keys: string[] = [];

  const addKeyCandidate = (val: string | undefined) => {
    if (!val) return;
    // Support multiple keys separated by comma, semicolon, or newline
    const parts = val.split(/[\n,;]+/);
    for (const p of parts) {
      const cleaned = cleanApiKey(p);
      if (cleaned && cleaned.length > 10) {
        keys.push(cleaned);
      }
    }
  };

  // 1. Single standard env vars (AI Studio default platform key)
  addKeyCandidate(process.env.GEMINI_API_KEY);
  addKeyCandidate(process.env.GEMINI_KEY);
  addKeyCandidate(process.env.GEMINI_APIKEY);

  // 2. Numbered keys: KEY1..KEY50, KEY_1..KEY_50, GEMINI_API_KEY_1..50, GEMINI_KEY1..50
  for (let i = 1; i <= 50; i++) {
    addKeyCandidate(process.env[`KEY${i}`]);
    addKeyCandidate(process.env[`KEY_${i}`]);
    addKeyCandidate(process.env[`GEMINI_API_KEY_${i}`]);
    addKeyCandidate(process.env[`GEMINI_KEY_${i}`]);
    addKeyCandidate(process.env[`GEMINI_KEY${i}`]);
  }

  // 3. Fallback default keys pool provided by user
  const defaultUserKeys = [
    "AQ.Ab8RN6Ic1_7QqZOoZI06iTcPkp-DshBWTTTmb8QdZnffhuksTg",
    "AQ.Ab8RN6KbQ2ctiKpsoAvEvEzmVx3_V9DS5JBrDhoPzSvSo3rLMQ",
    "AQ.Ab8RN6I5uQ_kCHAQFxHAGfq6LCUVsjDuPL8K7FOHlYdam5yPTQ",
    "AQ.Ab8RN6K3J5Knmufj2qvcZSS0OdrquyLGhQjkj-C-0z713QY3vw",
    "AQ.Ab8RN6Kov9NIR4jYtm3sLE1migednQm0hT9EMNl5-Q0Seo4CFQ",
    "AQ.Ab8RN6KxOBbOTFJrMw-Q8fnFVtZ_Scm4efI_nNVkg-HM8xvIsw",
    "AQ.Ab8RN6Jittnk9iskd5wKkibzeSUCgRYjR02xXuIwPhpE6VLmmg",
    "AQ.Ab8RN6ITwPbWGr_6CizKyxAnKc5UsgDKMbZTRFXygz1Xaod-Zg",
    "AQ.Ab8RN6LKk9akPGtD1aqD3xktvWfqp56WulNYRlrU2tppvWSUcA",
    "AQ.Ab8RN6L559-fjoXJ2aseeHAWT26dU1jyIcdMRLqUSGRIoDVe8A"
  ];
  for (const k of defaultUserKeys) {
    addKeyCandidate(k);
  }

  return Array.from(new Set(keys)).filter(Boolean);
}

function getOpenRouterApiKey(): string | null {
  if (!process.env.OPENROUTER_API_KEY) return null;
  const cleaned = cleanApiKey(process.env.OPENROUTER_API_KEY);
  return cleaned || null;
}

function isAIAvailable(): boolean {
  return getGeminiApiKeys().length > 0 || !!getOpenRouterApiKey();
}

function getActiveGeminiKey(): string {
  const keys = getGeminiApiKeys();
  if (keys.length === 0) {
    throw new Error("No Gemini API keys are configured on the server.");
  }
  return keys[activeGeminiKeyIndex % keys.length];
}

function getGeminiClient(): GoogleGenAI {
  const activeKey = getActiveGeminiKey();
  return new GoogleGenAI({
    apiKey: activeKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });
}

function rotateGeminiKey() {
  const keys = getGeminiApiKeys();
  if (keys.length > 1) {
    activeGeminiKeyIndex = (activeGeminiKeyIndex + 1) % keys.length;
    console.log(`[KeyRotation] Switched to key index ${activeGeminiKeyIndex % keys.length} (key snippet: ...${keys[activeGeminiKeyIndex % keys.length].slice(-5)})`);
  }
}

// Convert Gemini structure to OpenRouter messages
function convertGeminiToOpenRouterMessages(contents: any, systemInstruction?: string): any[] {
  const messages: any[] = [];
  if (systemInstruction) {
    messages.push({ role: "system", content: systemInstruction });
  }

  if (typeof contents === "string") {
    messages.push({ role: "user", content: contents });
  } else if (Array.isArray(contents)) {
    for (const item of contents) {
      if (item.parts) {
        const role = item.role === "model" ? "assistant" : "user";
        let contentText = "";
        for (const part of item.parts) {
          if (part.text) {
            contentText += part.text + "\n";
          }
        }
        messages.push({ role, content: contentText.trim() });
      } else if (item.role) {
        messages.push({ role: item.role === "assistant" || item.role === "model" ? "assistant" : "user", content: item.text || "" });
      }
    }
  } else if (contents && typeof contents === "object") {
    if (contents.parts && Array.isArray(contents.parts)) {
      let contentText = "";
      const images: any[] = [];
      for (const part of contents.parts) {
        if (part.text) {
          contentText += part.text + "\n";
        } else if (part.inlineData) {
          const { mimeType, data } = part.inlineData;
          images.push({
            type: "image_url",
            image_url: {
              url: `data:${mimeType};base64,${data}`
            }
          });
        }
      }
      if (images.length > 0) {
        const contentParts: any[] = [];
        if (contentText.trim()) {
          contentParts.push({ type: "text", text: contentText.trim() });
        }
        for (const img of images) {
          contentParts.push(img);
        }
        messages.push({ role: "user", content: contentParts });
      } else {
        messages.push({ role: "user", content: contentText.trim() });
      }
    } else {
      messages.push({ role: "user", content: JSON.stringify(contents) });
    }
  }
  return messages;
}

// Call OpenRouter API with fallback support
async function callOpenRouter(params: {
  model?: string;
  contents: any;
  config?: any;
}) {
  const apiKey = getOpenRouterApiKey();
  if (!apiKey) {
    throw new Error("OpenRouter API key is not configured.");
  }

  let modelName = "google/gemini-2.5-flash"; // default robust OpenRouter model
  if (params.model) {
    if (params.model.includes("3.5-flash") || params.model.includes("3.1-flash")) {
      modelName = "google/gemini-2.5-flash";
    }
  }

  const messages = convertGeminiToOpenRouterMessages(params.contents, params.config?.systemInstruction);

  const requestBody: any = {
    model: modelName,
    messages: messages,
  };

  if (params.config?.responseMimeType === "application/json") {
    requestBody.response_format = { type: "json_object" };
  }

  console.log(`[OpenRouter] Sending request to OpenRouter using model ${modelName}...`);
  const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`,
      "HTTP-Referer": "https://nexonportal-academic-suite.ai",
      "X-Title": "NexonPortal Suite"
    },
    body: JSON.stringify(requestBody),
  });

  if (!response.ok) {
    const errorBody = await response.text();
    throw new Error(`OpenRouter API failed with status ${response.status}: ${errorBody}`);
  }

  const data = await response.json();
  const text = data.choices?.[0]?.message?.content || "";

  return {
    text: text,
    candidates: [
      {
        content: {
          parts: [{ text: text }]
        }
      }
    ]
  };
}

// Robust wrapper with automatic retries, key rotation, and OpenRouter fallback
async function generateContentWithRetry(params: {
  model?: string;
  contents: any;
  config?: any;
  fastFail?: boolean; // trims retries for latency-sensitive interactive chat
}): Promise<any> {
  const geminiKeys = getGeminiApiKeys();
  const openRouterKey = getOpenRouterApiKey();

  if (geminiKeys.length === 0 && !openRouterKey) {
    throw new Error("No active AI API keys configured on the server.");
  }

  const requestedModel = params.model || "gemini-3.5-flash";
  const fullChain = Array.from(new Set([
    requestedModel,
    "gemini-3.5-flash",
    "gemini-3.1-flash-lite",
    "gemini-flash-latest"
  ]));
  const modelsToTry = params.fastFail ? fullChain.slice(0, 2) : fullChain;
  let lastError: any = null;

  // 1. Try Gemini Keys with automatic round-robin rotation on failures
  if (geminiKeys.length > 0) {
    const maxGeminiAttempts = Math.max(geminiKeys.length * 2, 3);
    for (let attempt = 1; attempt <= maxGeminiAttempts; attempt++) {
      const currentModel = modelsToTry[(attempt - 1) % modelsToTry.length];
      try {
        console.log(`[Gemini-Rotation] Attempting ${currentModel} using key index ${activeGeminiKeyIndex % geminiKeys.length} (attempt ${attempt}/${maxGeminiAttempts})`);
        const ai = getGeminiClient();
        const response = await ai.models.generateContent({
          model: currentModel,
          contents: params.contents,
          config: params.config
        });
        if (response) {
          return response;
        }
      } catch (err: any) {
        lastError = err;
        const errStr = String(err.message || "").toUpperCase();
        console.warn(`[Gemini-Rotation] Warning using ${currentModel} (attempt ${attempt}):`, errStr);
        
        // Rotate key for the next try
        rotateGeminiKey();

        const isFatal = errStr.includes("UNAUTHORIZED") || 
                        errStr.includes("NOT FOUND") ||
                        errStr.includes("BAD REQUEST") ||
                        err.status === 400 || 
                        err.status === 401 || 
                        err.status === 403;

        // If fatal, we rotate key but don't wait as much
        if (!isFatal && attempt < maxGeminiAttempts) {
          await new Promise((resolve) => setTimeout(resolve, 300));
        }
      }
    }
  }

  // 2. Fallback to OpenRouter if Gemini failed or is not available
  if (openRouterKey) {
    try {
      console.log(`[Fallback] Gemini pool failed or is empty. Falling back to OpenRouter...`);
      return await callOpenRouter(params);
    } catch (openRouterErr: any) {
      console.error("[Fallback] OpenRouter failed as well:", openRouterErr.message || openRouterErr);
      throw new Error(`AI Service failed completely on both Gemini and OpenRouter. Last error: ${openRouterErr.message}`);
    }
  }

  throw lastError || new Error("Failed to generate content after retries and fallbacks.");
}

app.use(express.json({ limit: "25mb" }));

// API 1: Nexon AI Chat (General AI Assistant with File Support)
app.post("/api/chat", async (req, res) => {
  const { messages, fileData } = req.body;
  
  if (!isAIAvailable()) {
    return res.status(200).json({ 
      text: "Halo! Saya Nexon AI, asisten virtual serbaguna Anda. Saat ini saya berjalan dalam mode offline karena kunci API Nexon AI belum diatur di Secrets. Silakan tambahkan 'GEMINI_API_KEY' atau 'OPENROUTER_API_KEY' di panel Secrets agar saya dapat membantu Anda secara maksimal!\n\n(Ini adalah balasan contoh mode offline. Saya siap membantu menjawab pertanyaan, menerjemahkan, merangkum, dan menulis setelah kunci API diaktifkan!)"
    });
  }

  try {
    const parts: any[] = [];
    const systemPrompt = `Anda adalah Nexon AI, asisten kecerdasan buatan serbaguna yang sangat cerdas, profesional, ramah, dan berwawasan luas yang dikembangkan oleh Nexon.
Tugas utama Anda:
1. Membantu produktivitas, akademis, pembelajaran, kreativitas, penulisan, penerjemahan, perangkuman, dan matematika/sains.
2. Memberikan penjelasan yang berbobot, akurat, dan komprehensif tanpa kesalahan pengetikan (ejaan bahasa Indonesia sempurna, contoh: "Cari", "Hitung", "Tentukan").
3. Gunakan bahasa Indonesia yang sopan, ramah, profesional, dan menyenangkan.
4. Saat menyajikan data atau perbandingan, gunakan format Markdown Table (| Kolom | Kolom |) yang rapi. Gunakan format matematika jelas.`;

    // Process optional attachment file
    if (fileData && fileData.base64 && fileData.mimeType) {
      parts.push({
        inlineData: {
          mimeType: fileData.mimeType,
          data: fileData.base64
        }
      });
      parts.push({
        text: `Pengguna melampirkan berkas dengan tipe ${fileData.mimeType}. Lakukan analisis mendalam terhadap berkas ini sesuai dengan pertanyaan pengguna.`
      });
    }

    // Map conversation history
    const historyText = messages.map((m: any) => `${m.sender === "user" ? "User" : "Nexon AI"}: ${m.text}`).join("\n");
    
    parts.push({
      text: `${systemPrompt}\n\nRiwayat Percakapan:\n${historyText}\n\nTanggapi pesan terakhir pengguna dengan jawaban yang sangat cerdas, ramah, dan terstruktur.`
    });

    const response = await generateContentWithRetry({
      model: "gemini-3.5-flash",
      contents: { parts }
    });

    res.json({ text: response.text || "Mohon maaf, terjadi kendala saat memproses jawaban. Silakan coba kembali." });
  } catch (error: any) {
    console.error("Error at Nexon AI Chat API:", error);
    res.status(500).json({ error: "Gagal memproses obrolan Nexon AI: " + error.message });
  }
});

// API 2: Nexon AI Code (Specialized Developer Assistant)
app.post("/api/code", async (req, res) => {
  const { messages, language } = req.body;

  if (!isAIAvailable()) {
    return res.status(200).json({
      explanation: "Layanan Nexon AI Code sedang offline. Mohon tambahkan kunci 'GEMINI_API_KEY' atau 'OPENROUTER_API_KEY' di panel Secrets untuk mengaktifkan asisten programmer Nexon secara langsung.",
      code: `// Contoh kode simulasi untuk ${language || "JavaScript"}\nfunction sayHello() {\n  console.log('Halo dari Nexon AI Code!');\n}\n\nsayHello();`,
      language: language || "javascript"
    });
  }

  try {
    const systemPrompt = `Anda adalah Nexon AI Code, pakar pemrograman profesional yang dirancang khusus untuk membantu developer menulis, memperbaiki, menjelaskan, mengoptimalkan, dan mempelajari berbagai bahasa pemrograman (${language || "bahasa yang relevan"}).
Karakteristik Anda:
1. Selalu sertakan satu blok kode lengkap, bersih, siap-jalan, dan terstruktur dengan sintaks modern dan penanganan edge-case (seperti input kosong, validasi).
2. Jelaskan cara kerja kode secara terperinci menggunakan bahasa Indonesia yang ringkas, terarah, dan mudah dipahami.
3. Berikan saran performa, keamanan, atau alternatif yang lebih baik jika diperlukan.
4. Tanggapi dengan format Markdown lengkap yang sangat profesional.`;

    const historyText = messages.map((m: any) => `${m.sender === "user" ? "User" : "Nexon AI Code"}: ${m.text}`).join("\n");

    const response = await generateContentWithRetry({
      model: "gemini-3.5-flash", // gemini-3.5-flash handles programming tasks beautifully
      contents: `${systemPrompt}\n\nRiwayat Percakapan Coding:\n${historyText}\n\nTolong bantu pengguna dengan kode berkualitas tinggi dan penjelasan terstruktur.`
    });

    const rawText = response.text || "";
    
    // Parse the response to extract explanation and code block
    let code = "";
    let explanation = "";
    let parsedLanguage = language || "javascript";

    const regex = /```([a-zA-Z0-9+#\-]+)?\n([\s\S]*?)\n```/;
    const match = regex.exec(rawText);

    if (match) {
      if (match[1]) {
        parsedLanguage = match[1].trim();
      }
      code = match[2];
      explanation = rawText.replace(match[0], "").trim();
    } else {
      if (rawText.includes("function") || rawText.includes("class ") || rawText.includes("import ") || rawText.includes("def ")) {
        code = rawText;
        explanation = "Berikut adalah kode program yang Anda minta:";
      } else {
        code = "";
        explanation = rawText;
      }
    }

    res.json({
      explanation: explanation || "Kode berhasil digenerasikan.",
      code: code || "// Gagal memisahkan blok kode, silakan lihat penjelasan di bawah",
      language: parsedLanguage
    });
  } catch (error: any) {
    console.error("Error at Nexon AI Code API:", error);
    res.status(500).json({ error: "Gagal memproses kode pemrograman: " + error.message });
  }
});

// API for Liana Counsel (Counsel AI)
app.post("/api/counsel", async (req, res) => {
  const { messages } = req.body;

  if (!isAIAvailable()) {
    return res.status(200).json({
      text: "Halo sayang... Layanan konseling Liana sedang offline karena API key belum diatur di Secrets. Tapi tenang saja, Liana selalu mendoakanmu agar tetap bersemangat dan tenang ya! ❤️"
    });
  }

  try {
    const systemPrompt = `Anda adalah Liana, guru BK (Bimbingan Konseling) asisten pendukung bertenaga AI di NexonAcademic.
Karakteristik Anda:
1. Sangat hangat, penyayang, ramah, penuh empati, peduli, lemah lembut, dan bijaksana. Selalu panggil pengguna dengan sebutan hangat seperti "sayang", "kamu", atau panggilan yang akrab namun sopan.
2. Tempat mencurahkan keluh kesah yang aman, tanpa menghakimi (non-judgmental).
3. Berikan saran yang menenangkan, penuh motivasi akademis dan mental, serta teknik relaksasi jika pengguna merasa panik, stres ujian, cemas akan nilai, atau kesepian.
4. Gunakan bahasa Indonesia yang penuh kehangatan emosional, dilengkapi dengan emotikon pendukung (seperti ❤️, 🥰, 🌸, 🤗).
5. Gunakan format Markdown yang rapi agar pesan mudah dibaca.`;

    const historyText = (messages || []).map((m: any) => `${m.sender === "user" ? "Siswa" : "Liana"}: ${m.text}`).join("\n");

    const response = await generateContentWithRetry({
      model: "gemini-3.5-flash",
      contents: `${systemPrompt}\n\nRiwayat Obrolan Konseling:\n${historyText}\n\nBerikan tanggapan konseling yang sangat hangat, menenangkan, dan penuh solusi/empati sebagai Liana.`
    });

    res.json({ text: response.text || "Liana mendengar suaramu sayang, tapi terjadi kendala jaringan sejenak. Tarik napas dulu ya..." });
  } catch (error: any) {
    console.error("Error at Counsel API:", error);
    res.status(500).json({ error: "Gagal memproses konseling: " + error.message });
  }
});

// API for Nexon Lab React (Lab AI)
app.post("/api/lab-react", async (req, res) => {
  const { element1, element2 } = req.body;

  if (!element1 || !element2) {
    return res.status(400).json({ error: "Permintaan tidak lengkap: element1 dan element2 diperlukan." });
  }

  if (!isAIAvailable()) {
    return res.status(200).json({
      product: `Senyawa Simulasi ${element1.symbol}${element2.symbol}`,
      equation: `${element1.symbol} + ${element2.symbol} -> ${element1.symbol}${element2.symbol} (Simulasi)`,
      energy: "Eksotermik Sedang",
      vibe: "Tercampur dengan perubahan warna simulasi di laboratorium offline.",
      fullExplanation: `Anda mencampurkan **${element1.name}** dan **${element2.name}**.\n\nDalam mode simulasi offline (kunci API tidak aktif), kami menunjukkan alur fungsional pencampuran senyawa secara visual. Hubungkan API Key di Secrets untuk mensimulasikan reaksi kimia murni secara sains!`
    });
  }

  try {
    const prompt = `Anda adalah asisten ilmuwan kimia di laboratorium NexonLab.
Tugas Anda adalah memprediksi secara akurat hasil reaksi kimia ketika dua unsur berikut dicampurkan:
Unsur 1: ${element1.name} (${element1.symbol}), Nomor Atom: ${element1.number}, Kategori: ${element1.category}
Unsur 2: ${element2.name} (${element2.symbol}), Nomor Atom: ${element2.number}, Kategori: ${element2.category}

Analisislah secara ilmiah:
1. Apakah kedua unsur ini dapat bereaksi di laboratorium dalam kondisi standar atau tertentu?
2. Jika bereaksi, apa rumus kimia dan nama produk/senyawa hasil reaksinya? Tuliskan persamaan reaksi kimianya yang setara (misalnya: "2 Na + Cl2 -> 2 NaCl").
3. Berapa energi reaksinya (apakah eksotermik, endotermik, sangat eksplosif, lambat, atau tidak bereaksi)?
4. Bagaimana fenomena fisik/visual yang terlihat di laboratorium (mengeluarkan gas, perubahan warna, nyala api, uap, endapan, dll)?
5. Berikan penjelasan ilmiah lengkap dalam bahasa Indonesia tentang mekanisme transfer elektron atau ikatan yang terbentuk (kovalen, ionik, logam, dll).

Kembalikan respon JSON murni dengan format persis berikut:
{
  "product": "Nama Produk Senyawa (contoh: 'Natrium Klorida (Garam Dapur)')",
  "equation": "Persamaan reaksi setara (contoh: '2Na + Cl2 -> 2NaCl')",
  "energy": "Keterangan energi (contoh: 'Sangat Eksotermik (Eksplosif)')",
  "vibe": "Deskripsi singkat visual (contoh: 'Mengeluarkan kilatan cahaya kuning terang dan asap putih tebal')",
  "fullExplanation": "Penjelasan ilmiah lengkap menggunakan format Markdown yang rapi tentang mekanisme interaksi kedua unsur tersebut."
}

Kembalikan HANYA JSON tersebut tanpa pembungkus Markdown \`\`\`json atau teks pembuka/penutup lainnya.`;

    const response = await generateContentWithRetry({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json"
      }
    });

    const parsed = JSON.parse(response.text || "{}");
    res.json({
      product: parsed.product || "Senyawa Baru",
      equation: parsed.equation || `${element1.symbol} + ${element2.symbol} -> Hasil`,
      energy: parsed.energy || "Bereaksi",
      vibe: parsed.vibe || "Terjadi perubahan struktur unsur di tabung lab.",
      fullExplanation: parsed.fullExplanation || "Reaksi berhasil dianalisis."
    });
  } catch (error: any) {
    console.error("Error at Lab React API:", error);
    res.status(500).json({ error: "Gagal mensimulasikan reaksi kimia: " + error.message });
  }
});

// API 3: Nexon AI Canvas (Image Generation with Robust SVG Fallback)
app.post("/api/canvas", async (req, res) => {
  const { prompt, aspectRatio = "1:1" } = req.body;

  if (!isAIAvailable()) {
    return res.status(200).json({
      isFallback: true,
      mimeType: "image/svg+xml",
      data: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="100%" height="100%"><rect width="100%" height="100%" fill="#0f172a"/><circle cx="200" cy="200" r="80" fill="none" stroke="#3b82f6" stroke-width="8" stroke-dasharray="10 10"/><text x="200" y="210" fill="#f8fafc" font-size="14" font-family="sans-serif" text-anchor="middle">Nexon Canvas Offline</text><text x="200" y="235" fill="#94a3b8" font-size="11" font-family="sans-serif" text-anchor="middle">Aktifkan kunci API di Secrets</text></svg>`,
      explanation: "Layanan Canvas berjalan dalam mode offline. Silakan atur kunci GEMINI_API_KEY atau OPENROUTER_API_KEY di Secrets untuk menghasilkan gambar nyata."
    });
  }

  try {
    console.log(`[Canvas] Attempting image generation for: "${prompt}" (Ratio: ${aspectRatio})`);
    
    // Attempt standard image generation via gemini-3.1-flash-lite-image
    try {
      const ai = getGeminiClient();
      const response = await ai.models.generateContent({
        model: 'gemini-3.1-flash-lite-image',
        contents: {
          parts: [{ text: prompt }]
        },
        config: {
          imageConfig: {
            aspectRatio: aspectRatio
          }
        }
      });

      if (response && response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData && part.inlineData.data) {
            const base64 = part.inlineData.data;
            const mimeType = part.inlineData.mimeType || "image/png";
            return res.json({
              isFallback: false,
              mimeType: mimeType,
              data: base64,
              explanation: `Gambar berhasil dihasilkan menggunakan Nexon AI Canvas berdasarkan prompt Anda: "${prompt}".`
            });
          }
        }
      }
    } catch (imageErr: any) {
      console.warn("[Canvas] Image generation model failed or is unauthorized. Falling back to SVG coder:", imageErr.message);
    }

    // PREMIUM FALLBACK: Generate beautiful, highly polished, vector-graphic responsive SVGs using Gemini's text model
    const svgPrompt = `Anda adalah Nexon AI Canvas, desainer grafis dan ahli kode SVG berpengalaman.
Tugas Anda adalah menghasilkan berkas SVG mentah (tanpa pembungkus Markdown, tanpa penjelas teks, hanya kode <svg>...</svg> murni yang valid) yang mewakili deskripsi berikut:
"${prompt}"

Kriteria Desain SVG Anda:
1. Harus responsif menggunakan viewBox yang cocok dan width="100%" height="100%".
2. Gunakan warna-warna modern, modern gradients (<linearGradient>), efek bayangan (<filter>), jalur lekukan (<path>), lingkaran (<circle>), pola, dan elemen visual yang kaya.
3. Desain harus sangat memukau, estetis, artistik, dan relevan dengan kata kunci di prompt.
4. Tambahkan teks estetis di dalam SVG jika itu merupakan logo, lambang, atau poster.
5. Gunakan font sans-serif modern di dalam SVG.

Kembalikan HANYA kode SVG valid secara langsung, dimulai dengan <svg> dan diakhiri </svg>.`;

    const textResponse = await generateContentWithRetry({
      model: "gemini-3.5-flash",
      contents: svgPrompt
    });

    let rawSvg = textResponse.text || "";
    // Clean markdown fences
    rawSvg = rawSvg.trim().replace(/^```xml\s*/i, "").replace(/^```html\s*/i, "").replace(/^```svg\s*/i, "").replace(/^```\s*/i, "").replace(/```\s*$/i, "");
    if (!rawSvg.startsWith("<svg")) {
      const firstSvgTag = rawSvg.indexOf("<svg");
      const lastSvgTag = rawSvg.lastIndexOf("</svg>");
      if (firstSvgTag !== -1 && lastSvgTag !== -1) {
        rawSvg = rawSvg.substring(firstSvgTag, lastSvgTag + 6);
      } else {
        throw new Error("Gagal memformat kode SVG fallback.");
      }
    }

    res.json({
      isFallback: true,
      mimeType: "image/svg+xml",
      data: rawSvg,
      explanation: `Gambar ilustrasi vektor berkualitas tinggi berhasil digenerasikan oleh Nexon AI Canvas (Mode Desain Vektor) untuk prompt: "${prompt}".`
    });

  } catch (error: any) {
    console.error("Error at Nexon AI Canvas API:", error);
    res.status(500).json({ error: "Gagal memproses gambar Canvas: " + error.message });
  }
});

// API 4: Nexon AI Search (Google Search Grounded Companion)
app.post("/api/search", async (req, res) => {
  const { messages } = req.body;

  if (!isAIAvailable()) {
    return res.status(200).json({
      text: "Fitur Nexon AI Search sedang offline. Mohon tambahkan kunci API di Secrets untuk menjelajahi web secara langsung.\n\n(Pencarian offline: Saya siap mencari topik-topik hangat di internet setelah Anda mengatur kunci API!)"
    });
  }

  try {
    const lastUserMessage = messages[messages.length - 1]?.text || "Topik hangat hari ini";
    const systemPrompt = `Anda adalah Nexon AI Search, pendamping pencarian informasi cerdas dari Nexon yang terhubung langsung ke internet melalui Google Search.
Tugas Anda:
1. Sajikan jawaban yang ringkas, padat, berbobot, akurat, dan sangat mudah dipahami berdasarkan data pencarian Google terbaru.
2. JANGAN membuat asumsi kadaluarsa jika informasi baru tersedia di web.
3. Selalu sebutkan sumber atau kutipan penting dalam tulisan Anda secara elegan.
4. Tulis jawaban Anda dalam bahasa Indonesia yang profesional dan rapi menggunakan format Markdown.`;

    const response = await generateContentWithRetry({
      model: "gemini-3.5-flash",
      contents: `${systemPrompt}\n\nPertanyaan pencarian pengguna: ${lastUserMessage}`,
      config: {
        tools: [{ googleSearch: {} }]
      }
    });

    // Extract grounding metadata chunks for citations
    const rawChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    const sources = rawChunks
      .map((chunk: any) => {
        if (chunk.web) {
          return {
            title: chunk.web.title || "Sumber Web",
            uri: chunk.web.uri || "#"
          };
        }
        return null;
      })
      .filter(Boolean);

    // Filter unique sources by URI
    const uniqueSources: any[] = [];
    const seenUris = new Set();
    for (const src of sources) {
      if (src && !seenUris.has(src.uri)) {
        seenUris.add(src.uri);
        uniqueSources.push(src);
      }
    }

    res.json({
      text: response.text || "Pencarian tidak menemukan hasil relevan.",
      sources: uniqueSources.slice(0, 6) // return top 6 unique sources
    });

  } catch (error: any) {
    console.error("Error at Nexon AI Search API:", error);
    res.status(500).json({ error: "Gagal melakukan pencarian: " + error.message });
  }
});

// API 5: Nexon AI Deep Research (Autonomous Multi-Stage Research Loop)
app.post("/api/deep-research", async (req, res) => {
  const { query } = req.body;

  if (!query) {
    return res.status(400).json({ error: "Permintaan tidak valid: query penelitian kosong." });
  }

  if (!isAIAvailable()) {
    return res.status(200).json({
      thinkingLogs: [
        "Mempersiapkan mesin penelitian otonom Nexon Deep Research...",
        "Menghubungkan ke node pencarian web...",
        "Peringatan: Kunci API tidak terdeteksi. Menggunakan database lokal."
      ],
      markdown: `# Hasil Penelitian: ${query}\n\nLayanan Nexon Deep Research memerlukan kunci API aktif untuk menjelajahi web secara otonom. Silakan masukkan kunci 'GEMINI_API_KEY' atau 'OPENROUTER_API_KEY' di Secrets untuk menjalankan riset mendalam multi-tahap.`,
      sources: []
    });
  }

  try {
    const logs: string[] = [];
    logs.push(`Menginisialisasi modul penelitian Nexon Deep Research untuk topik: "${query}"`);
    logs.push("Menganalisis domain topik untuk merumuskan sub-pertanyaan riset...");

    // Stage 1: Generate sub-questions using standard Gemini text model
    const planningPrompt = `Anda adalah asisten perencana riset Nexon Deep Research.
Topik penelitian utama pengguna adalah: "${query}"

Berdasarkan topik ini, rumuskan TIGA pertanyaan penelitian (sub-queries) spesifik dan terpisah untuk dicari di Google agar penelitian ini berjalan mendalam dan menyeluruh.
Kembalikan respon JSON murni dengan format persis berikut:
{
  "subQueries": ["query pencarian 1", "query pencarian 2", "query pencarian 3"]
}
Kembalikan HANYA JSON tersebut tanpa pembungkus Markdown.`;

    const planResponse = await generateContentWithRetry({
      model: "gemini-3.5-flash",
      contents: planningPrompt,
      config: {
        responseMimeType: "application/json"
      }
    });

    let subQueries = [query];
    try {
      const parsedPlan = JSON.parse(planResponse.text || "{}");
      if (Array.isArray(parsedPlan.subQueries) && parsedPlan.subQueries.length > 0) {
        subQueries = parsedPlan.subQueries;
      }
    } catch (err) {
      console.warn("[Deep Research] Gagal mem-parse rencana sub-queries, gunakan default.", err);
    }

    logs.push(`Rencana riset disusun dengan ${subQueries.length} sub-topik pencarian.`);
    
    // Stage 2: Query Google Search for each sub-query
    const gatheredData: any[] = [];
    const allSources: any[] = [];
    const seenUris = new Set();

    for (let i = 0; i < subQueries.length; i++) {
      const sub = subQueries[i];
      logs.push(`Mengeksekusi pencarian otonom Tahap ${i+1}/${subQueries.length}: "${sub}"`);
      
      try {
        const searchRes = await generateContentWithRetry({
          model: "gemini-3.5-flash",
          contents: `Cari informasi terbaru dan detail mengenai sub-topik berikut di web: "${sub}". Berikan ringkasan temuan penting Anda dalam 2-3 paragraf berbobot.`,
          config: {
            tools: [{ googleSearch: {} }]
          }
        });

        gatheredData.push({
          subQuery: sub,
          findings: searchRes.text || ""
        });

        // Extract sources
        const chunks = searchRes.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
        for (const chunk of chunks) {
          if (chunk.web && chunk.web.uri && !seenUris.has(chunk.web.uri)) {
            seenUris.add(chunk.web.uri);
            allSources.push({
              title: chunk.web.title || "Referensi Terpercaya",
              uri: chunk.web.uri
            });
          }
        }
      } catch (searchErr: any) {
        logs.push(`Pencarian sub-topik ${i+1} terhambat: ${searchErr.message}. Melanjutkan ke sub-topik berikutnya...`);
      }
      // Small delay between searches
      await new Promise(resolve => setTimeout(resolve, 300));
    }

    logs.push("Mengonsolidasikan semua temuan dari berbagai referensi web...");
    logs.push("Menyusun laporan akhir riset komprehensif dengan penalaran akademis...");

    // Stage 3: Synthesize final comprehensive markdown report
    const synthesisPrompt = `Anda adalah Nexon Deep Research Engine, agen riset paling cerdas dan analitis.
Topik Utama Penelitian: "${query}"

Berikut adalah data temuan mentah dari hasil penjelajahan web mandiri Anda untuk masing-masing sub-topik:
${gatheredData.map((d, index) => `=== Temuan Riset ${index+1}: Sub-topik "${d.subQuery}" ===\n${d.findings}`).join("\n\n")}

Tugas Anda:
Susunlah Laporan Riset Akademis yang sangat profesional, mendalam, dan komprehensif dalam bahasa Indonesia mengenai topik utama tersebut.
Struktur Laporan harus memuat:
1. **Judul Utama & Abstrak**: Judul menarik dan ringkasan eksekutif riset.
2. **Pendahuluan**: Latar belakang, urgensi, dan ruang lingkup topik.
3. **Analisis Mendalam & Pembahasan**: Detail temuan, data pendukung, perbandingan, dan pemecahan sub-topik secara logis.
4. **Tantangan & Peluang Masa Depan**: Analisis kritis tentang hambatan dan potensi masa depan.
5. **Kesimpulan & Rekomendasi**: Ringkasan kesimpulan penelitian dan langkah konkret yang disarankan.

Gunakan nada akademis yang objektif, tata bahasa yang elegan, dan format Markdown yang luar biasa indah (tabel, poin-poin, blok kuotasi).`;

    const finalReport = await generateContentWithRetry({
      model: "gemini-3.5-flash",
      contents: synthesisPrompt
    });

    logs.push("Riset mendalam selesai. Laporan riset siap disajikan!");

    res.json({
      thinkingLogs: logs,
      markdown: finalReport.text || "# Gagal mensintesis laporan riset.",
      sources: allSources.slice(0, 10)
    });

  } catch (error: any) {
    console.error("Error at Deep Research API:", error);
    res.status(500).json({ error: "Gagal memproses Deep Research: " + error.message });
  }
});

// ==========================================
// NEXON AI HUB CUSTOM BACKEND ENDPOINTS
// ==========================================

const checkApiKey = (req: express.Request, res: express.Response, next: express.NextFunction) => {
  if (!isAIAvailable()) {
    const path = req.path;
    if (path === "/api/generate") {
      const { message, mode } = req.body;
      let text = "";
      if (mode === "code") {
        text = `### 💻 Nexon AI Code Workspace (Mode Offline Simulasi)
Kunci API \`GEMINI_API_KEY\` atau \`OPENROUTER_API_KEY\` belum diatur di panel Secrets Anda. Nexon AI berjalan dalam mode simulasi cerdas untuk membantu kelancaran pengembangan visual Anda.

Berikut adalah contoh template kode untuk permintaan Anda:

\`\`\`javascript
// Nexon AI Code Offline Simulator
// Permintaan: "${message}"

function nexonApp() {
  const status = "Nexon Portal Workspace Active";
  console.log(\`[System] \${status}\`);
  return {
    success: true,
    message: "Konfigurasikan GEMINI_API_KEY atau OPENROUTER_API_KEY untuk hasil dinamis cerdas",
    timestamp: new Date().toISOString()
  };
}

nexonApp();
\`\`\`

#### Langkah Aktivasi Nexon AI Engine:
1. Buka menu **Settings** di kiri bawah.
2. Tambahkan variabel lingkungan **GEMINI_API_KEY** atau **OPENROUTER_API_KEY** dengan nilai kunci API Anda.
3. Restart server untuk mengaktifkan seluruh fungsionalitas asisten AI otonom secara real-time.`;
      } else {
        text = `### 🌌 Selamat datang di NexonAi Workspace (Mode Offline Simulasi)

Kunci API \`GEMINI_API_KEY\` atau \`OPENROUTER_API_KEY\` belum dikonfigurasi pada panel Secrets. Nexon AI saat ini berjalan dalam **mode simulator cerdas offline** untuk mendemonstrasikan kelancaran alur antarmuka workspace Anda.

Anda bertanya: *"${message}"*

#### Tanggapan Simulasi Nexon AI:
*Saya adalah asisten AI dari Ekosistem Nexon. Dalam mode offline ini, saya ingin mengonfirmasi bahwa seluruh sistem antarmuka NexonAi Anda, termasuk panel maksimalkan layar, beralih mode (Chat, Code, Canvas, Veo Video), panel kontrol riwayat sesi, dan pembersih workspace berfungsi 100% lancar.*

#### Cara Mengaktifkan Mode Live AI:
1. Masuk ke tab **Secrets / Settings** pada panel kontrol AI Studio.
2. Tambahkan kunci baru dengan nama \`GEMINI_API_KEY\` atau \`OPENROUTER_API_KEY\` dan isi dengan kunci API resmi Anda.
3. Nikmati asisten multi-mode live dengan Grounding Pencarian Google, Deep Research otonom, dan visualisasi canvas modern!`;
      }
      return res.json({
        text,
        sources: [
          { title: "Dokumentasi NexonPortal", url: "https://nexon.my.id" },
          { title: "Panduan Secrets API", url: "https://ai.studio/build" }
        ],
        modelUsed: "Nexon-AI-Offline-Simulator"
      });
    }
    
    if (path === "/api/canvas/generate") {
      const { prompt } = req.body;
      const fallbackUrl = `https://image.pollinations.ai/p/${encodeURIComponent(prompt || "futuristic high tech virtual workspace purple glowing neon")}?width=1024&height=1024&nologo=true&seed=${Math.floor(Math.random() * 1000000)}`;
      return fetch(fallbackUrl)
        .then(async (imageRes) => {
          if (!imageRes.ok) throw new Error("Fallback failed");
          const arrayBuffer = await imageRes.arrayBuffer();
          const buffer = Buffer.from(arrayBuffer);
          const base64Image = `data:image/png;base64,${buffer.toString("base64")}`;
          return res.json({
            imageUrl: base64Image,
            info: "Gambar berhasil digenerasikan oleh Mesin Gambar Nexon AI offline (Pollinations Fallback Engine).",
            modelUsed: "Nexon-AI-Image-Offline-Fallback",
          });
        })
        .catch((err) => {
          return res.json({
            imageUrl: "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 400' width='100%' height='100%'><rect width='100%' height='100%' fill='%230e0e11'/><text x='50%' y='45%' dominant-baseline='middle' text-anchor='middle' fill='%23a855f7' font-weight='bold' font-size='16'>Nexon Canvas Offline</text><text x='50%' y='55%' dominant-baseline='middle' text-anchor='middle' fill='%23666' font-size='11'>Konfigurasikan GEMINI_API_KEY atau OPENROUTER_API_KEY untuk hasil live</text></svg>",
            info: "Gagal menghasilkan gambar dalam mode offline.",
            modelUsed: "Nexon-AI-Image-Offline-Failed"
          });
        });
    }

    if (path === "/api/video/generate") {
      const fallbackOpName = `fallback-video-op-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
      fallbackVideoOperations.set(fallbackOpName, {
        prompt: req.body.prompt || "",
        modelUsed: "NexonAi-Video-Offline-Fallback",
        timestamp: Date.now(),
      });
      return res.json({
        operationName: fallbackOpName,
        modelUsed: "NexonAi-Video-Offline-Fallback",
      });
    }

    if (path === "/api/video/status") {
      return res.json({
        done: true,
        error: null,
      });
    }

    if (path === "/api/video/download") {
      const fallbackUrl = "https://vjs.zencdn.net/v/oceans.mp4";
      return fetch(fallbackUrl)
        .then(async (videoRes) => {
          if (!videoRes.ok || !videoRes.body) throw new Error("Fallback video download failed");
          res.setHeader("Content-Type", "video/mp4");
          // Stream it
          const reader = videoRes.body.getReader();
          const pump = async () => {
            const { done, value } = await reader.read();
            if (done) {
              res.end();
              return;
            }
            res.write(value);
            await pump();
          };
          return pump();
        })
        .catch(() => {
          return res.status(500).json({ error: "Gagal memuat video offline." });
        });
    }

    return res.status(500).json({
      error: "GEMINI_API_KEY is not set. Please configure it in your Secrets panel.",
    });
  }
  next();
};

const fallbackVideoOperations = new Map<string, { prompt: string; modelUsed: string; timestamp: number; mappedUrl?: string }>();

const getFallbackVideoUrl = (prompt: string): string => {
  const p = (prompt || "").toLowerCase();
  if (p.includes("space") || p.includes("star") || p.includes("galaxy") || p.includes("nebula") || p.includes("cosmic") || p.includes("sky") || p.includes("universe")) {
    return "https://media.w3.org/2010/05/sintel/trailer_hd.mp4";
  }
  if (p.includes("water") || p.includes("ocean") || p.includes("sea") || p.includes("wave") || p.includes("beach") || p.includes("river") || p.includes("rain") || p.includes("nature")) {
    return "https://vjs.zencdn.net/v/oceans.mp4";
  }
  if (p.includes("cyber") || p.includes("code") || p.includes("tech") || p.includes("computer") || p.includes("digital") || p.includes("circuit") || p.includes("ai") || p.includes("robot")) {
    return "https://media.w3.org/2010/05/sintel/trailer_hd.mp4";
  }
  if (p.includes("fire") || p.includes("smoke") || p.includes("lava") || p.includes("warm") || p.includes("abstract") || p.includes("color") || p.includes("art")) {
    return "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4";
  }
  return "https://media.w3.org/2010/05/bunny/trailer.mp4";
};

// API Endpoint: Text Generation (Chat & Code)
app.post("/api/generate", checkApiKey, async (req, res) => {
  try {
    const { message, history, mode, thinking, search, deepResearch, attachments } = req.body;
    const model = "gemini-3.5-flash";

    const tools: any[] = [];
    if (search || deepResearch) {
      tools.push({ googleSearch: {} });
    }

    let thinkingLevel = ThinkingLevel.LOW;
    if (thinking === "high") {
      thinkingLevel = ThinkingLevel.HIGH;
    } else if (thinking === "normal") {
      thinkingLevel = ThinkingLevel.LOW;
    } else if (thinking === "medium") {
      thinkingLevel = ThinkingLevel.LOW;
    }

    let systemInstruction = "You are Nexon AI, a highly intelligent, premium, and friendly AI assistant created by Nexon. Answer concisely and clearly.";
    if (mode === "code") {
      systemInstruction = "You are Nexon Code AI, an expert software engineering assistant created by Nexon. Provide clean, well-commented code, detect bugs, explain logic, and suggest optimizations. Focus strictly on programming.";
    } else if (deepResearch) {
      systemInstruction = "You are Nexon Deep Research AI. Perform a deep, thorough, and highly structured investigation of the user's query. Provide detailed findings with academic precision, cross-referencing sources where possible.";
    }

    const contents: any[] = [];
    if (history && Array.isArray(history)) {
      for (const h of history) {
        contents.push({
          role: h.role === "assistant" ? "model" : "user",
          parts: [{ text: h.text }],
        });
      }
    }

    const userParts: any[] = [{ text: message }];
    if (attachments && Array.isArray(attachments)) {
      for (const att of attachments) {
        if (att.mimeType && att.base64Data) {
          let cleanBase64 = att.base64Data;
          if (cleanBase64.includes(";base64,")) {
            cleanBase64 = cleanBase64.split(";base64,")[1];
          }
          userParts.push({
            inlineData: {
              mimeType: att.mimeType,
              data: cleanBase64,
            },
          });
        }
      }
    }

    contents.push({
      role: "user",
      parts: userParts,
    });

    const ai = getGeminiClient();
    const response = await ai.models.generateContent({
      model: model,
      contents: contents,
      config: {
        systemInstruction,
        tools: tools.length > 0 ? tools : undefined,
        thinkingConfig: {
          thinkingLevel,
        },
      },
    });

    const text = response.text || "";
    
    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    const webSources = groundingChunks
      .map((chunk: any) => {
        if (chunk.web) {
          return {
            title: chunk.web.title || "Web Source",
            url: chunk.web.uri,
          };
        }
        return null;
      })
      .filter((source: any) => source !== null);

    const uniqueSources = Array.from(new Map(webSources.map((s: any) => [s.url, s])).values());

    res.json({
      text,
      sources: uniqueSources,
      modelUsed: model,
    });
  } catch (error: any) {
    console.error("Error in /api/generate:", error);
    let errorMsg = error.message || "An error occurred during text generation.";
    const errorStr = typeof error === 'object' ? JSON.stringify(error) : String(error);
    if (
      errorMsg.includes("429") || 
      errorMsg.includes("quota") || 
      errorMsg.includes("RESOURCE_EXHAUSTED") || 
      errorStr.includes("429") ||
      errorStr.includes("RESOURCE_EXHAUSTED")
    ) {
      errorMsg = "Batas kuota gratis NexonAi telah tercapai (RESOURCE_EXHAUSTED). Silakan tunggu beberapa saat atau masukkan API Key pribadi Anda.";
    } else if (
      errorMsg.includes("503") ||
      errorMsg.includes("UNAVAILABLE") ||
      errorMsg.includes("demand") ||
      errorMsg.includes("temporary") ||
      errorStr.includes("503") ||
      errorStr.includes("UNAVAILABLE")
    ) {
      errorMsg = "Layanan NexonAi sedang mengalami lonjakan lalu lintas yang sangat tinggi (UNAVAILABLE 503). Silakan coba lagi.";
    }
    res.status(500).json({ error: errorMsg });
  }
});

// API Endpoint: Canvas (Image Generation)
app.post("/api/canvas/generate", checkApiKey, async (req, res) => {
  try {
    const { prompt, aspectRatio = "1:1", size = "1K", modelType = "nano-banana" } = req.body;
    const model = modelType === "nano-banana-pro" ? "gemini-3.1-flash-image" : "gemini-3.1-flash-lite-image";

    try {
      const ai = getGeminiClient();
      const response = await ai.models.generateContent({
        model: model,
        contents: {
          parts: [{ text: prompt }],
        },
        config: {
          imageConfig: {
            aspectRatio,
            imageSize: size,
          },
        },
      });

      let imageUrl = "";
      let textInfo = "";

      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            const base64Data = part.inlineData.data;
            imageUrl = `data:${part.inlineData.mimeType || "image/png"};base64,${base64Data}`;
          } else if (part.text) {
            textInfo += part.text;
          }
        }
      }

      if (!imageUrl) {
        throw new Error("No image data returned from Gemini model.");
      }

      return res.json({
        imageUrl,
        info: textInfo || "Gambar berhasil dibuat oleh model Nexon AI.",
        modelUsed: model,
      });
    } catch (geminiError: any) {
      console.log("Image generation falling back to backup engine. Enhancing prompt via AI...");
      
      let enhancedPrompt = prompt;
      let modelUsedInfo = "Nexon-AI-Image-Fallback";
      
      try {
        const enhancerResponse = await generateContentWithRetry({
          model: "google/gemini-2.5-flash",
          contents: `You are an expert AI visual designer. Expand this user's image request: "${prompt}" into an incredibly vivid, highly detailed, artistic description (in English, 2-3 sentences) suitable for a professional image generator. Append aesthetic styles like "cinematic lighting, ultra detailed, vibrant colors, masterpieces, award-winning illustration". Do not include any preambles, explanations, or quotes. Just output the final prompt directly.`,
          fastFail: true
        });
        if (enhancerResponse && enhancerResponse.text) {
          enhancedPrompt = enhancerResponse.text.trim();
          modelUsedInfo = "Nexon-AI-Image-OpenRouter-Enhanced";
          console.log(`[Canvas-OpenRouter] Successfully enhanced prompt to: "${enhancedPrompt}"`);
        }
      } catch (enhancerErr: any) {
        console.warn("[Canvas-OpenRouter] Prompt enhancer failed:", enhancerErr.message || enhancerErr);
      }

      const fallbackUrl = `https://image.pollinations.ai/p/${encodeURIComponent(enhancedPrompt)}?width=1024&height=1024&nologo=true&seed=${Math.floor(Math.random() * 1000000)}`;
      
      const imageRes = await fetch(fallbackUrl);
      if (!imageRes.ok) {
        throw new Error("Gagal mengambil gambar dari image engine cadangan.");
      }

      const arrayBuffer = await imageRes.arrayBuffer();
      const buffer = Buffer.from(arrayBuffer);
      const base64Image = `data:image/png;base64,${buffer.toString("base64")}`;

      return res.json({
        imageUrl: base64Image,
        info: "Menghasilkan gambar menggunakan asisten visual OpenRouter dan Mesin Render Nexon Canvas.",
        modelUsed: modelUsedInfo,
      });
    }
  } catch (error: any) {
    console.error("Error in /api/canvas/generate:", error);
    let errorMsg = error.message || "Gagal menghasilkan gambar.";
    const errorStr = typeof error === 'object' ? JSON.stringify(error) : String(error);
    if (
      errorMsg.includes("429") || 
      errorMsg.includes("quota") || 
      errorMsg.includes("RESOURCE_EXHAUSTED") || 
      errorStr.includes("429") ||
      errorStr.includes("RESOURCE_EXHAUSTED")
    ) {
      errorMsg = "Batas kuota gratis NexonAi untuk melukis telah tercapai (RESOURCE_EXHAUSTED). Silakan tunggu beberapa menit.";
    } else if (
      errorMsg.includes("503") ||
      errorMsg.includes("UNAVAILABLE") ||
      errorMsg.includes("demand") ||
      errorMsg.includes("temporary") ||
      errorStr.includes("503") ||
      errorStr.includes("UNAVAILABLE")
    ) {
      errorMsg = "Layanan melukis NexonAi sedang mengalami lonjakan lalu lintas yang tinggi (UNAVAILABLE 503). Silakan coba lagi.";
    }
    res.status(500).json({ error: errorMsg });
  }
});

// API Endpoint: Video Generation (Veo)
app.post("/api/video/generate", checkApiKey, async (req, res) => {
  try {
    const { prompt, resolution = "720p", aspectRatio = "16:9", modelType = "veo-lite" } = req.body;
    const model = modelType === "veo-pro" ? "veo-3.1-generate-preview" : "veo-3.1-lite-generate-preview";

    try {
      const ai = getGeminiClient();
      const operation = await ai.models.generateVideos({
        model: model,
        prompt: prompt,
        config: {
          numberOfVideos: 1,
          resolution: resolution,
          aspectRatio: aspectRatio,
        },
      });

      return res.json({
        operationName: operation.name,
        modelUsed: model,
      });
    } catch (veoError: any) {
      console.log("Video generation falling back to backup engine.");
      
      const fallbackOpName = `fallback-video-op-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
      
      let mappedUrl: string | undefined = undefined;
      let modelUsed = "NexonAi-Video-Fallback";
      
      if (isAIAvailable()) {
        try {
          console.log("[Video-OpenRouter] Attempting to classify prompt with AI model...");
          const classifierRes = await generateContentWithRetry({
            model: "google/gemini-2.5-flash",
            contents: `You are an AI Video Director. Analyze this user request for a video: "${prompt}".
Classify the request into one of the following high-quality cinematic stock video IDs:
- oceans (For water, ocean, sea, beach, underwater, marine life, waves)
- sintel (For fantasy, CGI, storytelling, action, green nature, adventure, character animations)
- tears (For sci-fi, futuristic, robots, holographic interfaces, high-tech labs, space-tech, coding)
- bunny (For cartoons, playful, animation, children, forest, animals, humor, lighthearted)
- blazes (For fires, warm glowing lights, explosions, energetic abstract art, active flames)
- street (For cars, speed, driving, roads, cities, fast motion, mountains, dynamic travels)
- flower (For flower blooming, macro nature, quiet, macro photography, beauty, garden)
- clouds (For skies, time-lapse clouds, flight, high altitude, wind, sunset, sunrise)

Return ONLY the selected ID as a single word in lowercase (e.g. "tears" or "oceans") with no other text, quotes, or punctuation.`,
            fastFail: true
          });
          
          if (classifierRes && classifierRes.text) {
            const videoId = classifierRes.text.trim().toLowerCase();
            console.log(`[Video-OpenRouter] Classified video ID: "${videoId}"`);
            
            const urls: Record<string, string> = {
              oceans: "https://vjs.zencdn.net/v/oceans.mp4",
              sintel: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
              tears: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
              bunny: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
              blazes: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
              street: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4",
              flower: "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4",
              clouds: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4"
            };
            
            if (urls[videoId]) {
              mappedUrl = urls[videoId];
              modelUsed = `NexonAi-Video-OpenRouter-Classified-${videoId}`;
              console.log(`[Video-OpenRouter] Successfully mapped to URL: ${mappedUrl}`);
            }
          }
        } catch (classifyErr: any) {
          console.warn("[Video-OpenRouter] Classifier failed, relying on keyword map:", classifyErr.message || classifyErr);
        }
      }

      fallbackVideoOperations.set(fallbackOpName, {
        prompt: prompt || "",
        modelUsed: modelUsed,
        timestamp: Date.now(),
        mappedUrl: mappedUrl,
      });

      return res.json({
        operationName: fallbackOpName,
        modelUsed: modelUsed,
      });
    }
  } catch (error: any) {
    console.error("Error in /api/video/generate:", error);
    let errorMsg = error.message || "An error occurred during video creation.";
    const errorStr = typeof error === 'object' ? JSON.stringify(error) : String(error);
    if (
      errorMsg.includes("429") || 
      errorMsg.includes("quota") || 
      errorMsg.includes("RESOURCE_EXHAUSTED") || 
      errorStr.includes("429") ||
      errorStr.includes("RESOURCE_EXHAUSTED")
    ) {
      errorMsg = "Batas kuota gratis NexonAi untuk video telah tercapai (RESOURCE_EXHAUSTED). Silakan coba beberapa saat lagi.";
    } else if (
      errorMsg.includes("503") ||
      errorMsg.includes("UNAVAILABLE") ||
      errorMsg.includes("demand") ||
      errorMsg.includes("temporary") ||
      errorStr.includes("503") ||
      errorStr.includes("UNAVAILABLE")
    ) {
      errorMsg = "Layanan pembuat video NexonAi sedang mengalami lonjakan lalu lintas yang tinggi (UNAVAILABLE 503). Silakan coba lagi.";
    }
    res.status(500).json({ error: errorMsg });
  }
});

// API Endpoint: Poll Status
app.post("/api/video/status", checkApiKey, async (req, res) => {
  try {
    const { operationName } = req.body;
    if (!operationName) {
      return res.status(400).json({ error: "operationName is required" });
    }

    if (operationName.startsWith("fallback-video-op-")) {
      return res.json({
        done: true,
        error: null,
      });
    }

    const { GenerateVideosOperation } = await import("@google/genai");
    const op = new GenerateVideosOperation();
    op.name = operationName;

    const ai = getGeminiClient();
    const updated = await ai.operations.getVideosOperation({ operation: op });

    res.json({
      done: updated.done,
      error: updated.error,
    });
  } catch (error: any) {
    console.error("Error in /api/video/status:", error);
    res.status(500).json({ error: error.message || "An error occurred while polling status." });
  }
});

// API Endpoint: Download & Stream Video
app.post("/api/video/download", checkApiKey, async (req, res) => {
  try {
    const { operationName } = req.body;
    if (!operationName) {
      return res.status(400).json({ error: "operationName is required" });
    }

    if (operationName.startsWith("fallback-video-op-")) {
      const opInfo = fallbackVideoOperations.get(operationName);
      const promptText = opInfo ? opInfo.prompt : "";
      const fallbackUrl = opInfo?.mappedUrl || getFallbackVideoUrl(promptText);

      console.log(`Streaming fallback stock video: ${fallbackUrl} for prompt: "${promptText}"`);
      
      let videoRes: Response | null = null;
      let lastError: any = null;
      
      const candidateUrls = [
        fallbackUrl,
        "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4",
        "https://www.w3schools.com/html/movie.mp4",
        "https://www.w3schools.com/html/mov_bbb.mp4"
      ];

      for (const url of candidateUrls) {
        try {
          console.log(`Trying to fetch fallback video from: ${url}`);
          const res = await fetch(url, {
            headers: {
              "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36"
            }
          });
          if (res.ok) {
            videoRes = res;
            break;
          } else {
            console.warn(`Failed to fetch from ${url}: Status ${res.status}`);
          }
        } catch (e: any) {
          lastError = e;
          console.warn(`Error fetching from ${url}:`, e.message || e);
        }
      }

      if (!videoRes) {
        throw new Error(`Gagal mengambil file video cadangan dari semua sumber. Error terakhir: ${lastError?.message || "Unknown error"}`);
      }

      res.setHeader("Content-Type", "video/mp4");
      if (videoRes.body) {
        const reader = videoRes.body.getReader();
        const pump = async () => {
          const { done, value } = await reader.read();
          if (done) {
            res.end();
            return;
          }
          res.write(value);
          await pump();
        };
        await pump();
      } else {
        throw new Error("Gagal membaca aliran data video cadangan.");
      }
      return;
    }

    const { GenerateVideosOperation } = await import("@google/genai");
    const op = new GenerateVideosOperation();
    op.name = operationName;

    const ai = getGeminiClient();
    const updated = await ai.operations.getVideosOperation({ operation: op });
    const video = updated.response?.generatedVideos?.[0]?.video;
    
    if (!video || !video.uri) {
      return res.status(404).json({ error: "Video uri not found or operation not completed yet." });
    }

    const videoRes = await fetch(video.uri, {
      headers: { "x-goog-api-key": getActiveGeminiKey() },
    });

    res.setHeader("Content-Type", "video/mp4");
    
    if (videoRes.body) {
      const reader = videoRes.body.getReader();
      const pump = async () => {
        const { done, value } = await reader.read();
        if (done) {
          res.end();
          return;
        }
        res.write(value);
        await pump();
      };
      await pump();
    } else {
      res.status(500).json({ error: "Failed to read the video source stream." });
    }
  } catch (error: any) {
    console.error("Error in /api/video/download:", error);
    res.status(500).json({ error: error.message || "An error occurred during downloading the video." });
  }
});

// Serve static compiled UI files in production, integrate Vite in dev
async function bootstrap() {
  if (process.env.NODE_ENV !== "production") {
    // Hide from Vercel's nft by using a dynamic string
    const viteModule = "vi" + "te";
    const { createServer: createViteServer } = await import(viteModule);
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath, {
      maxAge: "1d",
      etag: true,
      setHeaders: (res, filePath) => {
        if (filePath.endsWith('.js') || filePath.endsWith('.css') || filePath.endsWith('.png') || filePath.endsWith('.svg') || filePath.endsWith('.woff2')) {
          res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
        }
      }
    }));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  // Listen on server PORT
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`NexonAcademic Server is rapidly running on http://0.0.0.0:${PORT}`);
  });
}

if (!process.env.VERCEL) {
  bootstrap();
}

export default app;
