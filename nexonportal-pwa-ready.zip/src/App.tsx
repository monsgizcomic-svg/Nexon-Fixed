import { useState, useEffect } from "react";
import { 
  Bell, 
  X, 
  User, 
  Settings, 
  BookOpen, 
  Heart, 
  Code2, 
  FlaskConical, 
  Menu, 
  Clock, 
  Activity, 
  GraduationCap,
  ShieldAlert,
  FolderHeart,
  ArrowLeft,
  Sparkles,
  ExternalLink,
  Download,
  Share
} from "lucide-react";
import { User as FirebaseUser } from "firebase/auth";

import DianaChat from "./components/DianaChat";
import LianaCounsel from "./components/LianaCounsel";
import NexonCodeStudio from "./components/NexonCodeStudio";
import NexonLabSandbox from "./components/NexonLabSandbox";
import SmartReminder from "./components/SmartReminder";
import NexonShelf from "./components/NexonShelf";
import UserProfileEditor from "./components/UserProfileEditor";

interface ToastNotification {
  id: string;
  title: string;
  msg: string;
  timestamp: string;
}

type ActiveTab = "portal" | "academic" | "diana" | "liana" | "nexoncode" | "nexonlab" | "reminders";

export default function App() {
  const defaultGuestUser = {
    uid: "guest-nexon-user",
    email: "user@nexon.my.id",
    displayName: "User Nexon"
  } as unknown as FirebaseUser;

  const [currentUser] = useState<FirebaseUser | null>(defaultGuestUser);
  
  // User profile state loaded from local storage or default
  interface UserProfileType {
    name: string;
    role: string;
    grade: string;
    school: string;
    nexonAiUrl?: string;
  }

  const [userProfile, setUserProfile] = useState<UserProfileType>(() => {
    try {
      const saved = localStorage.getItem("nexon_user_profile");
      if (saved) return JSON.parse(saved);
    } catch (e) {
      // ignore
    }
    return {
      name: "User Nexon",
      role: "Member",
      grade: "Member",
      school: "-",
      nexonAiUrl: ""
    };
  });

  // Navigation states
  const [activeTab, setActiveTab] = useState<ActiveTab>("portal");
  const [viewingShelf, setViewingShelf] = useState(false);
  const [isProfileEditing, setIsProfileEditing] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Global toast system
  const [toasts, setToasts] = useState<ToastNotification[]>([]);

  // PWA install banner state
  const [installPromptEvent, setInstallPromptEvent] = useState<any>(null);
  const [showInstallBanner, setShowInstallBanner] = useState(false);
  const [isIosInstallHint, setIsIosInstallHint] = useState(false);

  // Deep-link entry point for PWA manifest shortcuts (long-press app icon)
  // and any external link that wants to land directly on a sub-app, e.g.
  // /?tab=diana or /?view=shelf. Runs once on mount, then cleans the URL.
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const tabParam = params.get("tab");
    const viewParam = params.get("view");
    const validTabs: ActiveTab[] = ["portal", "academic", "diana", "liana", "nexoncode", "nexonlab", "reminders"];

    let handled = false;
    if (viewParam === "shelf") {
      setViewingShelf(true);
      handled = true;
    } else if (tabParam && (validTabs as string[]).includes(tabParam)) {
      setActiveTab(tabParam as ActiveTab);
      handled = true;
    }

    if (handled) {
      window.history.replaceState({}, "", window.location.pathname);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // PWA install prompt — Chrome/Edge/Android fire `beforeinstallprompt` when
  // the manifest + service worker are valid, but they no longer show any
  // visible UI for it on their own (just a small icon in the address bar).
  // We capture the event and drive our own visible banner instead.
  useEffect(() => {
    const isStandalone =
      window.matchMedia("(display-mode: standalone)").matches ||
      (window.navigator as any).standalone === true;
    if (isStandalone) return; // already installed & running as an app

    if (localStorage.getItem("nexon_pwa_install_dismissed")) return;

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setInstallPromptEvent(e);
      setShowInstallBanner(true);
    };
    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt);

    const handleAppInstalled = () => {
      setShowInstallBanner(false);
      setInstallPromptEvent(null);
      localStorage.removeItem("nexon_pwa_install_dismissed");
    };
    window.addEventListener("appinstalled", handleAppInstalled);

    // iOS Safari never fires beforeinstallprompt at all — show manual steps instead.
    const ua = window.navigator.userAgent;
    const isIos = /iPad|iPhone|iPod/.test(ua) && !(window as any).MSStream;
    const isSafari = /Safari/.test(ua) && !/CriOS|FxiOS|EdgiOS/.test(ua);
    if (isIos && isSafari) {
      setIsIosInstallHint(true);
      setShowInstallBanner(true);
    }

    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
      window.removeEventListener("appinstalled", handleAppInstalled);
    };
  }, []);

  const handleInstallClick = async () => {
    if (!installPromptEvent) return;
    installPromptEvent.prompt();
    await installPromptEvent.userChoice;
    setInstallPromptEvent(null);
    setShowInstallBanner(false);
  };

  const dismissInstallBanner = () => {
    setShowInstallBanner(false);
    localStorage.setItem("nexon_pwa_install_dismissed", "1");
  };

  // Prevent compositor issues on background tab suspension
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden) {
        document.body.classList.add("app-bg-paused");
      } else {
        document.body.classList.remove("app-bg-paused");
      }
    };
    document.addEventListener("visibilitychange", handleVisibilityChange);
    return () => document.removeEventListener("visibilitychange", handleVisibilityChange);
  }, []);

  const handleAddToast = (title: string, msg: string) => {
    // Disabled entirely as per user request to remove notification feature fully (except for Reminders)
  };

  const handleReminderToast = (title: string, msg: string) => {
    const freshToast: ToastNotification = {
      id: "toast-" + Date.now(),
      title,
      msg,
      timestamp: new Date().toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" })
    };
    
    setToasts(prev => [freshToast, ...prev].slice(0, 5));

    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== freshToast.id));
    }, 6000);
  };

  // Loaded & Authenticated NexonShelf View (takes full-screen priority)
  if (viewingShelf) {
    return (
      <div className="w-full h-[100dvh] overflow-hidden bg-[#050508] text-white">
        <NexonShelf 
          userProfile={userProfile}
          onBackToPortal={() => {
            setViewingShelf(false);
            handleAddToast("Kembali ke Portal 🎓", "Menu utama portal akademik diaktifkan kembali.");
          }}
          onAddNotification={handleAddToast}
          currentUserId={currentUser.uid}
        />
      </div>
    );
  }

  const academicItems = [
    { id: "academic", label: "Overview Akademik", icon: GraduationCap, color: "text-indigo-400", desc: "Menu utama & modul NexonAcademic" },
    { id: "diana", label: "Diana (Academic AI)", icon: Sparkles, color: "text-indigo-400", desc: "Konsultasi materi, tugas & kuis" },
    { id: "liana", label: "Liana (Counseling BK)", icon: Heart, color: "text-rose-400", desc: "Ruang curhat aman & meditatif" },
    { id: "nexoncode", label: "NexonCode Studio", icon: Code2, color: "text-amber-400", desc: "Pembuat kode pemrograman AI" },
    { id: "nexonlab", label: "NexonLab Sandbox", icon: FlaskConical, color: "text-emerald-400", desc: "Eksplorasi tabel & reaksi kimia" },
    { id: "reminders", label: "Reminders & Alerts", icon: Bell, color: "text-blue-400", desc: "Pengingat jadwal & tugas mandiri" }
  ];

  const isAcademicTab = ["academic", "diana", "liana", "nexoncode", "nexonlab", "reminders"].includes(activeTab);

  return (
    <div className="min-h-[100dvh] h-[100dvh] w-full bg-[#030306] text-white flex flex-col font-sans overflow-hidden relative bg-liquid-grid">
      
      {/* Background liquid morphing ambient accents */}
      <div className="absolute top-[-5%] right-1/4 w-[45rem] h-[45rem] bg-indigo-600/10 rounded-full blur-[150px] animate-liquid-blob pointer-events-none -z-10"></div>
      <div className="absolute bottom-[-10%] left-10 w-[35rem] h-[35rem] bg-purple-600/10 rounded-full blur-[140px] animate-liquid-blob pointer-events-none -z-10"></div>
      
      {/* Upper bar */}
      <header className="bg-[#05050a]/75 backdrop-blur-2xl border-b border-white/10 h-16 flex items-center justify-between px-4 sm:px-6 shrink-0 z-40 shadow-2xl">
        <div className="flex items-center gap-3">
          {isAcademicTab && (
            <button 
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} 
              className="p-2 hover:bg-white/10 rounded-xl text-zinc-300 hover:text-white md:hidden transition-colors border border-white/10 liquid-pill"
            >
              <Menu className="w-5 h-5" />
            </button>
          )}
          
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl flex items-center justify-center text-white shadow-xl shadow-indigo-500/30 overflow-hidden">
              <img src="/favicon.svg" className="w-full h-full object-contain filter drop-shadow-[0_0_8px_rgba(168,85,247,0.5)]" alt="Nexon Logo" />
            </div>
            <div className="flex flex-col">
              <span className="font-extrabold tracking-widest text-white text-xs sm:text-sm font-mono leading-none">
                NEXONPORTAL
              </span>
              <span className="text-[9px] text-zinc-400 font-mono tracking-wider mt-0.5">HUB CENTER v3.0</span>
            </div>
          </div>
        </div>

        {/* User profile widget & actions */}
        <div className="flex items-center gap-2 sm:gap-4">
          <div className="hidden sm:flex flex-col text-right">
            <span className="text-xs font-bold text-zinc-100 truncate max-w-[160px]">{userProfile.name}</span>
            <span className="text-[10px] text-indigo-300 font-mono tracking-wide truncate max-w-[160px] font-semibold">
              {userProfile.role} &bull; {userProfile.school}
            </span>
          </div>

          <div className="flex items-center gap-1.5 liquid-pill p-1 rounded-2xl border border-white/15">
            {/* Profile configuration button */}
            <button
              onClick={() => setIsProfileEditing(true)}
              title="Atur Profil"
              className="p-2 hover:bg-white/10 text-zinc-300 hover:text-white rounded-xl transition-all cursor-pointer"
            >
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Main dashboard body */}
      <div className="flex-1 flex overflow-hidden w-full relative">
        
        {/* Left Sidebar on Desktop - Only shown for NexonAcademic Suite */}
        {isAcademicTab && (
          <aside className="hidden md:flex flex-col w-72 bg-[#08080c]/90 backdrop-blur-xl border-r border-white/10 shrink-0 p-4 justify-between overflow-y-auto">
            <div className="space-y-6">
              
              {/* Kembali ke Portal Hub button */}
              <button
                onClick={() => {
                  setActiveTab("portal");
                }}
                className="w-full text-left p-3.5 rounded-2xl flex items-center gap-3 bg-zinc-900/60 hover:bg-zinc-800/80 border border-white/10 hover:border-indigo-500/30 text-zinc-300 hover:text-indigo-300 transition-all cursor-pointer group shadow-sm"
              >
                <ArrowLeft className="w-4 h-4 shrink-0 text-indigo-400 group-hover:-translate-x-1 transition-transform" />
                <div className="min-w-0">
                  <div className="text-xs font-extrabold leading-tight">Kembali ke Portal Hub</div>
                  <div className="text-[10px] text-zinc-400 leading-tight mt-0.5">Keluar dari NexonAcademic</div>
                </div>
              </button>

              {/* Quick school card */}
              <div className="p-4 bg-zinc-900/80 border border-white/10 rounded-2xl shadow-sm">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 flex items-center justify-center shrink-0">
                    <User className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs font-bold text-white truncate">{userProfile.name}</div>
                    <div className="text-[10px] text-zinc-400 font-mono truncate">{userProfile.school}</div>
                  </div>
                </div>
                <div className="mt-3 pt-3 border-t border-white/5 flex items-center justify-between text-[10px]">
                  <span className="text-zinc-400 font-mono">Kelas / Tingkat:</span>
                  <span className="font-bold text-indigo-400 font-mono bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20">{userProfile.grade}</span>
                </div>
              </div>

              {/* Sidebar Tab Selector */}
              <div className="space-y-2">
                <div className="flex items-center gap-2 px-2 mb-2">
                  <span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse"></span>
                  <span className="text-[10px] text-indigo-400 font-extrabold font-mono uppercase tracking-widest block">NexonAcademic</span>
                </div>
                {academicItems.map((item) => {
                  const IconComp = item.icon;
                  const isSelected = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        setActiveTab(item.id as ActiveTab);
                        setIsMobileMenuOpen(false);
                      }}
                      className={`w-full text-left p-3.5 rounded-2xl flex items-start gap-3 transition-all cursor-pointer group ${
                        isSelected 
                          ? "bg-indigo-600/20 border border-indigo-500/40 text-white shadow-lg shadow-indigo-500/10" 
                          : "hover:bg-white/5 border border-transparent text-zinc-400 hover:text-white"
                      }`}
                    >
                      <IconComp className={`w-4 h-4 mt-0.5 shrink-0 ${isSelected ? "text-indigo-400 animate-pulse" : "text-zinc-500 group-hover:text-zinc-300"}`} />
                      <div className="min-w-0">
                        <div className="text-xs font-bold leading-tight">{item.label}</div>
                        <div className="text-[10px] text-zinc-400 leading-tight mt-1 truncate">{item.desc}</div>
                      </div>
                    </button>
                  );
                })}
              </div>

            </div>

            <div className="p-3 bg-zinc-900/50 border border-white/5 rounded-xl text-center">
              <span className="text-[9px] text-zinc-400 font-mono uppercase tracking-widest block">NexonAcademic Suite</span>
              <span className="text-[10px] text-zinc-300 font-mono block mt-1 font-semibold">Layanan Akademik Mandiri</span>
            </div>
          </aside>
        )}

        {/* Mobile menu drawer - Only shown for NexonAcademic Suite */}
        {isAcademicTab && isMobileMenuOpen && (
          <>
            <div 
              className="fixed inset-0 bg-black/80 z-30 md:hidden backdrop-blur-sm"
              onClick={() => setIsMobileMenuOpen(false)}
            />

            <aside className="fixed top-0 bottom-0 left-0 w-72 bg-[#08080c] border-r border-white/10 z-40 p-5 flex flex-col justify-between md:hidden shadow-2xl">
              <div className="space-y-6">
                <div className="flex items-center justify-between border-b border-white/10 pb-4">
                  <div className="flex items-center gap-2.5">
                    <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-indigo-500 to-purple-500 flex items-center justify-center text-white font-bold text-xs">
                      NP
                    </div>
                    <span className="font-extrabold text-xs text-white tracking-wider font-mono">NEXONACADEMIC</span>
                  </div>
                  <button 
                    onClick={() => setIsMobileMenuOpen(false)} 
                    className="p-1 hover:bg-white/10 rounded-full text-zinc-400 hover:text-white"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <button
                  onClick={() => {
                    setActiveTab("portal");
                    setIsMobileMenuOpen(false);
                  }}
                  className="w-full text-left p-3 rounded-xl flex items-center gap-3 bg-zinc-900 border border-white/10 text-zinc-200 hover:text-indigo-400 transition-all cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4 shrink-0 text-indigo-400" />
                  <div className="min-w-0">
                    <div className="text-xs font-bold leading-tight">Kembali ke Portal Hub</div>
                    <div className="text-[10px] text-zinc-400 leading-tight mt-0.5">Keluar dari NexonAcademic</div>
                  </div>
                </button>

                <div className="p-3 bg-zinc-900/80 border border-white/10 rounded-xl text-xs">
                  <div className="font-bold text-white truncate">{userProfile.name}</div>
                  <div className="text-[10px] text-zinc-400 truncate mt-0.5">{userProfile.school}</div>
                  <div className="mt-2 pt-2 border-t border-white/5 flex justify-between">
                    <span className="text-zinc-400 font-mono">Role:</span>
                    <span className="font-bold text-indigo-400 font-mono">{userProfile.role}</span>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <div className="text-[10px] text-indigo-400 font-extrabold font-mono uppercase tracking-widest block mb-2">Pilih Modul</div>
                  {academicItems.map((item) => {
                    const IconComp = item.icon;
                    const isSelected = activeTab === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => {
                          setActiveTab(item.id as ActiveTab);
                          setIsMobileMenuOpen(false);
                        }}
                        className={`w-full text-left p-3 rounded-xl flex items-start gap-3 transition-all cursor-pointer ${
                          isSelected 
                            ? "bg-indigo-600/20 text-white border border-indigo-500/30" 
                            : "hover:bg-white/5 text-zinc-400"
                        }`}
                      >
                        <IconComp className={`w-4 h-4 mt-0.5 shrink-0 ${isSelected ? "text-indigo-400" : "text-zinc-500"}`} />
                        <div className="min-w-0">
                          <div className="text-xs font-bold leading-tight">{item.label}</div>
                          <div className="text-[10px] text-zinc-400 leading-tight truncate mt-0.5">{item.desc}</div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="p-2 border-t border-white/5 text-[10px] text-zinc-500 font-mono text-center">
                NexonAcademic Suite v3.0
              </div>
            </aside>
          </>
        )}

        {/* Dynamic content screen area */}
        <main className="flex-1 p-4 sm:p-6 md:p-8 overflow-y-auto relative h-full">
          
          <div className="max-w-7xl mx-auto h-full flex flex-col">
            {activeTab === "portal" && (
              <div className="flex-1 space-y-10 animate-fadeIn pb-12" id="nexon_portal_dashboard">
                
                {/* Hero Welcome Banner */}
                <div className="relative overflow-hidden rounded-3xl liquid-glass p-8 sm:p-10 border border-white/20 shadow-2xl">
                  {/* Decorative ambient flares */}
                  <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-600/15 rounded-full blur-[100px] animate-liquid-blob pointer-events-none"></div>
                  <div className="absolute bottom-0 left-0 w-80 h-80 bg-purple-600/15 rounded-full blur-[100px] animate-liquid-blob pointer-events-none"></div>
                  
                  <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-8">
                    <div className="space-y-4">
                      <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-[10px] font-extrabold font-mono liquid-pill text-indigo-200 border border-white/20 uppercase tracking-widest shadow-md">
                        <Sparkles className="w-3.5 h-3.5 text-indigo-300" />
                        Nexon Ecosystem Portal v3.0
                      </div>
                      <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight leading-tight">
                        Selamat Datang Di <span className="text-liquid-gradient font-display">NexonPortal</span> 👋
                      </h1>
                      <p className="text-zinc-300 text-xs sm:text-sm max-w-2xl leading-relaxed font-normal">
                        Akses seluruh layanan kecerdasan buatan, bimbingan akademis, pengerjaan tugas mandiri, serta modul literatur digital terpadu dalam satu gerbang ekosistem terintegrasi.
                      </p>
                    </div>

                    <div className="shrink-0 flex items-center gap-4 liquid-glass p-4 rounded-2xl border border-white/20 shadow-xl lg:self-center">
                      <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 flex items-center justify-center shadow-md">
                        <Clock className="w-6 h-6 animate-pulse" />
                      </div>
                      <div>
                        <div className="text-[10px] text-zinc-400 font-mono uppercase tracking-wider font-extrabold">Waktu Sistem</div>
                        <div className="text-sm font-bold text-white font-mono mt-0.5">
                          {new Date().toLocaleDateString("id-ID", { weekday: "long", day: "numeric", month: "short" })}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* The Distinct Products Grid */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 max-w-7xl mx-auto">
                  
                  {/* CARD 1: NexonAcademic */}
                  <div className="group relative rounded-3xl liquid-glass-card p-7 flex flex-col justify-between border border-white/15 hover:border-indigo-400/50">
                    <div className="space-y-5">
                      <div className="flex items-center justify-between">
                        <div className="w-14 h-14 rounded-2xl bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 flex items-center justify-center shadow-lg shadow-indigo-500/20">
                          <GraduationCap className="w-7 h-7 group-hover:scale-110 transition-transform" />
                        </div>
                        <span className="text-[10px] text-indigo-200 font-extrabold font-mono uppercase tracking-widest px-3.5 py-1.5 rounded-full liquid-pill border border-indigo-500/30">
                          Academic AI
                        </span>
                      </div>

                      <div className="space-y-2">
                        <h2 className="text-2xl font-black text-white group-hover:text-indigo-300 transition-colors">
                          NexonAcademic
                        </h2>
                        <p className="text-zinc-300 text-xs leading-relaxed">
                          Sistem pendamping belajar & kesehatan mental terintegrasi yang dirancang khusus untuk siswa dan akademisi.
                        </p>
                      </div>

                      <div className="pt-2 space-y-2.5">
                        <div className="text-[10px] text-zinc-400 font-mono uppercase tracking-wider font-extrabold">Modul Akademik:</div>
                        <div className="grid grid-cols-1 gap-2">
                          {academicItems.filter(item => item.id !== "academic").map((item) => {
                            const IconC = item.icon;
                            return (
                              <button
                                key={item.id}
                                onClick={() => {
                                  setActiveTab(item.id as ActiveTab);
                                }}
                                className="flex items-center gap-3 p-3 rounded-2xl liquid-glass hover:bg-white/10 border border-white/10 hover:border-indigo-400/30 text-left transition-all cursor-pointer group/item"
                              >
                                <IconC className="w-4 h-4 text-indigo-400 group-hover/item:scale-110 transition-transform shrink-0" />
                                <div className="min-w-0">
                                  <div className="text-xs font-bold text-zinc-100 group-hover/item:text-white">{item.label}</div>
                                  <div className="text-[10px] text-zinc-400 truncate">{item.desc}</div>
                                </div>
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        setActiveTab("academic");
                      }}
                      className="mt-8 w-full py-4 px-4 rounded-2xl liquid-btn-primary text-white font-extrabold text-xs tracking-wider uppercase cursor-pointer text-center flex items-center justify-center gap-2"
                    >
                      <GraduationCap className="w-4 h-4" />
                      <span>Masuk NexonAcademic</span>
                    </button>
                  </div>

                  {/* CARD 2: NexonShelf */}
                  <div className="group relative rounded-3xl liquid-glass-card p-7 flex flex-col justify-between border border-white/15 hover:border-emerald-400/50">
                    <div className="space-y-5">
                      <div className="flex items-center justify-between">
                        <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 flex items-center justify-center shadow-lg shadow-emerald-500/20">
                          <BookOpen className="w-7 h-7 group-hover:scale-110 transition-transform" />
                        </div>
                        <span className="text-[10px] text-emerald-200 font-extrabold font-mono uppercase tracking-widest px-3.5 py-1.5 rounded-full liquid-pill border border-emerald-500/30">
                          Digital Library
                        </span>
                      </div>

                      <div className="space-y-2">
                        <h2 className="text-2xl font-black text-white group-hover:text-emerald-300 transition-colors">
                          NexonShelf
                        </h2>
                        <p className="text-zinc-300 text-xs leading-relaxed">
                          Pustaka komik cerdas, novel sains, buku pegangan kurikulum, dan dokumen belajar interaktif dalam satu rak buku digital.
                        </p>
                      </div>

                      <div className="pt-2 space-y-3">
                        <div className="text-[10px] text-zinc-400 font-mono uppercase tracking-wider font-extrabold">Keunggulan NexonShelf:</div>
                        <ul className="space-y-2.5 text-xs text-zinc-200">
                          <li className="flex items-start gap-2.5">
                            <span className="text-emerald-400 shrink-0 mt-0.5 font-bold">✓</span>
                            <span>Pembaca PDF berkecepatan tinggi dengan zoom responsif</span>
                          </li>
                          <li className="flex items-start gap-2.5">
                            <span className="text-emerald-400 shrink-0 mt-0.5 font-bold">✓</span>
                            <span>Manajemen koleksi komik edukasi & novel ilmiah</span>
                          </li>
                          <li className="flex items-start gap-2.5">
                            <span className="text-emerald-400 shrink-0 mt-0.5 font-bold">✓</span>
                            <span>Pengelompokkan dokumen berdasarkan folder materi</span>
                          </li>
                          <li className="flex items-start gap-2.5">
                            <span className="text-emerald-400 shrink-0 mt-0.5 font-bold">✓</span>
                            <span>Simpan bacaan favorit & riwayat aktivitas bacaan</span>
                          </li>
                        </ul>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        setViewingShelf(true);
                        handleAddToast("NexonShelf Terbuka 📚", "Selamat membaca di pustaka digital terintegrasi!");
                      }}
                      className="mt-8 w-full py-4 px-4 rounded-2xl liquid-btn-emerald text-white font-extrabold text-xs tracking-wider uppercase cursor-pointer text-center flex items-center justify-center gap-2"
                    >
                      <BookOpen className="w-4 h-4" />
                      <span>Buka Pustaka NexonShelf</span>
                    </button>
                  </div>

                  {/* CARD 3: NexAi Workspace (External Web) */}
                  <div className="group relative rounded-3xl liquid-glass-card p-7 flex flex-col justify-between border border-white/15 hover:border-purple-400/50">
                    <div className="space-y-5">
                      <div className="flex items-center justify-between">
                        <div className="w-14 h-14 rounded-2xl bg-purple-500/20 border border-purple-400/30 text-purple-300 flex items-center justify-center shadow-lg shadow-purple-500/20">
                          <Sparkles className="w-7 h-7 group-hover:scale-110 transition-transform" />
                        </div>
                        <span className="text-[10px] text-purple-200 font-extrabold font-mono uppercase tracking-widest px-3.5 py-1.5 rounded-full liquid-pill border border-purple-500/30">
                          External App
                        </span>
                      </div>

                      <div className="space-y-2">
                        <h2 className="text-2xl font-black text-white group-hover:text-purple-300 transition-colors flex items-center gap-2">
                          NexAi
                          <span className="text-[10px] bg-purple-500/30 text-purple-200 px-2.5 py-0.5 rounded-full font-mono border border-purple-400/40">ai.nexon.my.id</span>
                        </h2>
                        <p className="text-zinc-300 text-xs leading-relaxed">
                          Platform AI mandiri terpisah khusus untuk percakapan kecerdasan buatan multi-mode, pembuatan gambar canvas, dan deep research.
                        </p>
                      </div>

                      <div className="pt-2 space-y-3">
                        <div className="text-[10px] text-zinc-400 font-mono uppercase tracking-wider font-extrabold">Akses Langsung NexAi:</div>
                        <ul className="space-y-2.5 text-xs text-zinc-200">
                          <li className="flex items-start gap-2.5">
                            <span className="text-purple-400 shrink-0 mt-0.5">🌐</span>
                            <span>Domain Resmi: <strong className="text-purple-300">ai.nexon.my.id</strong></span>
                          </li>
                          <li className="flex items-start gap-2.5">
                            <span className="text-purple-400 shrink-0 mt-0.5">🔑</span>
                            <span>Sistem Akun Terhubung (SAML / Shared Auth)</span>
                          </li>
                          <li className="flex items-start gap-2.5">
                            <span className="text-purple-400 shrink-0 mt-0.5">⚡</span>
                            <span>Berjalan sebagai web independen berkecepatan tinggi</span>
                          </li>
                        </ul>
                      </div>
                    </div>

                    <a
                      href="https://ai.nexon.my.id"
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={() => {
                        handleAddToast("Membuka NexAi 🌌", "Mengarahkan ke https://ai.nexon.my.id");
                      }}
                      className="mt-8 w-full py-4 px-4 rounded-2xl liquid-btn-purple text-white font-extrabold text-xs tracking-wider uppercase cursor-pointer text-center flex items-center justify-center gap-2"
                    >
                      <span>Buka ai.nexon.my.id</span>
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  </div>

                </div>
              </div>
            )}

            {activeTab === "academic" && (
              <div className="flex-1 space-y-8 animate-fadeIn pb-12">
                {/* Academic Header Banner */}
                <div className="relative overflow-hidden rounded-3xl liquid-glass p-8 border border-white/20 shadow-2xl">
                  <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-600/15 rounded-full blur-[100px] animate-liquid-blob pointer-events-none"></div>
                  
                  <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
                    <div className="space-y-3">
                      <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-[10px] font-extrabold font-mono liquid-pill text-indigo-200 border border-white/20 uppercase tracking-widest">
                        <GraduationCap className="w-4 h-4 text-indigo-300" />
                        NexonAcademic Suite v2.6
                      </div>
                      <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                        Pusat Layanan Akademik & Eksplorasi
                      </h1>
                      <p className="text-zinc-300 text-xs sm:text-sm max-w-2xl leading-relaxed">
                        Pilih modul pendamping belajar yang Anda butuhkan di bawah ini. Akses asisten cerdas, ruang curhat konseling, editor kode AI, laboratorium kimia, atau pengingat tugas.
                      </p>
                    </div>

                    <div className="shrink-0 flex items-center gap-3 liquid-glass p-3.5 rounded-2xl border border-white/15">
                      <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-300 flex items-center justify-center font-bold text-lg">
                        🎓
                      </div>
                      <div className="text-left">
                        <div className="text-xs font-bold text-white">{userProfile.name}</div>
                        <div className="text-[10px] text-zinc-400 font-mono">{userProfile.school} &bull; {userProfile.grade}</div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Module Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {academicItems.filter(item => item.id !== "academic").map((item) => {
                    const IconC = item.icon;
                    return (
                      <div 
                        key={item.id}
                        className="group rounded-3xl liquid-glass-card p-6 border border-white/15 flex flex-col justify-between hover:border-indigo-400/50 transition-all"
                      >
                        <div className="space-y-4">
                          <div className="flex items-center justify-between">
                            <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 flex items-center justify-center shadow-lg shadow-indigo-500/10">
                              <IconC className="w-6 h-6 group-hover:scale-110 transition-transform" />
                            </div>
                            <span className="text-[9px] text-indigo-200 font-mono font-extrabold uppercase tracking-widest px-2.5 py-1 rounded-full liquid-pill border border-indigo-500/30">
                              MODUL
                            </span>
                          </div>

                          <div className="space-y-1.5">
                            <h3 className="text-lg font-bold text-white group-hover:text-indigo-300 transition-colors">
                              {item.label}
                            </h3>
                            <p className="text-xs text-zinc-300 leading-relaxed">
                              {item.desc}
                            </p>
                          </div>
                        </div>

                        <button
                          onClick={() => setActiveTab(item.id as ActiveTab)}
                          className="mt-6 w-full py-3 px-4 rounded-xl liquid-btn-primary text-white font-extrabold text-xs tracking-wider uppercase cursor-pointer text-center flex items-center justify-center gap-2"
                        >
                          <span>Buka {item.label.split(" ")[0]}</span>
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {activeTab === "diana" && (
              <div className="flex-1">
                <DianaChat onAddNotification={handleAddToast} />
              </div>
            )}

            {activeTab === "liana" && (
              <div className="flex-1">
                <LianaCounsel onAddNotification={handleAddToast} />
              </div>
            )}

            {activeTab === "nexoncode" && (
              <div className="flex-1">
                <NexonCodeStudio onAddNotification={handleAddToast} />
              </div>
            )}

            {activeTab === "nexonlab" && (
              <div className="flex-1">
                <NexonLabSandbox onAddNotification={handleAddToast} />
              </div>
            )}

            {activeTab === "reminders" && (
              <div className="flex-1">
                <SmartReminder onAddNotification={handleReminderToast} />
              </div>
            )}
          </div>

          {/* Site footer — real, visible copy for users & search engines */}
          <footer className="mt-12 pt-8 border-t border-white/10 text-center space-y-3 pb-2">
            <p className="text-xs text-zinc-400 leading-relaxed max-w-2xl mx-auto px-4">
              <strong className="text-zinc-200">NexonPortal</strong> adalah gerbang utama Ekosistem Nexon di{" "}
              <a href="https://nexon.my.id" className="text-purple-300 hover:text-purple-200 underline decoration-purple-400/30 underline-offset-2">nexon.my.id</a>
              , menghubungkan NexonAcademy, NexonShelf, dan NexAi dalam satu platform AI terpadu untuk pelajar dan mahasiswa Indonesia.
            </p>
            <p className="text-[10px] text-zinc-500 font-mono tracking-wide">
              © {new Date().getFullYear()} NexonPortal · nexon.my.id
            </p>
          </footer>

        </main>
      </div>

      {/* PWA Install Banner */}
      {showInstallBanner && (
        <div className="fixed bottom-3 left-3 right-3 sm:left-auto sm:right-4 sm:bottom-4 sm:max-w-sm z-50 animate-slideIn">
          <div className="p-4 liquid-glass rounded-2xl shadow-2xl border border-white/20 flex items-start gap-3">
            <div className="p-2.5 bg-purple-500/20 border border-purple-400/30 rounded-xl text-purple-300 shrink-0">
              {isIosInstallHint ? <Share className="w-5 h-5" /> : <Download className="w-5 h-5" />}
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-extrabold text-xs text-white">Install NexonPortal</div>
              {isIosInstallHint ? (
                <p className="text-[11px] text-zinc-300 leading-relaxed mt-1">
                  Tap ikon <strong className="text-white">Bagikan</strong> di Safari, lalu pilih{" "}
                  <strong className="text-white">"Tambah ke Layar Utama"</strong> untuk memasang NexonPortal seperti aplikasi.
                </p>
              ) : (
                <p className="text-[11px] text-zinc-300 leading-relaxed mt-1">
                  Pasang NexonPortal ke perangkatmu untuk akses lebih cepat & bisa dibuka tanpa browser.
                </p>
              )}
              {!isIosInstallHint && (
                <button
                  onClick={handleInstallClick}
                  className="mt-3 w-full py-2.5 rounded-xl liquid-btn-purple text-white font-extrabold text-[11px] tracking-wider uppercase cursor-pointer"
                >
                  Install Sekarang
                </button>
              )}
            </div>
            <button
              onClick={dismissInstallBanner}
              className="p-1 text-zinc-400 hover:text-white rounded-full cursor-pointer transition-colors shrink-0"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Floating Toast Notification Popups */}
      <div className="fixed top-3 left-3 right-3 sm:top-auto sm:left-auto sm:bottom-4 sm:right-4 z-50 space-y-2 sm:max-w-sm sm:w-full font-sans pointer-events-none">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className="p-4 liquid-glass text-white rounded-2xl shadow-2xl flex items-start gap-3 border-l-4 border-l-indigo-400 border border-white/20 pointer-events-auto animate-slideIn"
          >
            <div className="p-2 bg-indigo-500/20 border border-indigo-400/30 rounded-xl text-indigo-300 shrink-0 mt-0.5">
              <Bell className="w-4 h-4 animate-pulse" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-1">
                <span className="font-extrabold text-xs text-white truncate">{toast.title}</span>
                <span className="text-[9px] text-white/50 font-mono shrink-0">{toast.timestamp}</span>
              </div>
              <p className="text-[11px] text-zinc-300 leading-relaxed mt-1 whitespace-pre-line">{toast.msg}</p>
            </div>
            <button
              onClick={() => setToasts(prev => prev.filter(t => t.id !== toast.id))}
              className="p-1 text-zinc-400 hover:text-white rounded-full cursor-pointer transition-colors shrink-0"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        ))}
      </div>

      {/* Profile Modification Dialog */}
      {isProfileEditing && currentUser && (
        <UserProfileEditor 
          user={currentUser}
          onClose={() => setIsProfileEditing(false)}
          onSaveSuccess={(updated) => setUserProfile(updated)}
          onAddNotification={handleAddToast}
        />
      )}

    </div>
  );
}
