import { useState, useRef, useEffect, useCallback } from "react";
import { Message } from "../types";
import { renderFormattedText } from "./DianaChat";
import { 
  Send, 
  RefreshCw, 
  Heart, 
  Wind, 
  ShieldCheck, 
  Sparkles,
  Info,
  Maximize2,
  Minimize2
} from "lucide-react";

interface LianaCounselProps {
  onAddNotification: (title: string, msg: string) => void;
}

const INITIAL_LIANA_MESSAGE: Message = {
  id: "init-liana",
  sender: "ai",
  text: "Halo sayang... Selamat datang di ruang BK virtual yang hangat dan aman ini. Saya **Liana**, konselor (guru BK) pribadimu di **NexonAcademic** ❤️.\n\nDi sini, kamu bisa menumpahkan segala keluh kesahmu tanpa perlu merasa takut, sungkan, atau dinilai negatif. Entah itu stres tumpukan modul belajar, cemas menjelang ujian, masalah pertemanan di sekolah, atau sekadar lelah secara emosional.\n\nIngat ya, kesehatan mentalmu jauh lebih berharga daripada angka di lembar kertas ujian. Ceritakan apa saja yang sedang berkecamuk di dalam hatimu sekarang. Liana siap mendengarkan...",
  timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
};

export default function LianaCounsel({ onAddNotification }: LianaCounselProps) {
  // Persisted chat history, same pattern as Diana's room storage, so a
  // refresh or revisit doesn't wipe out a student's counseling conversation.
  const [messages, setMessages] = useState<Message[]>(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("liana_chat_history");
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed) && parsed.length > 0) return parsed;
        } catch (e) {
          console.warn("Failed to parse Liana chat history");
        }
      }
    }
    return [INITIAL_LIANA_MESSAGE];
  });

  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem("liana_chat_history", JSON.stringify(messages));
    }
  }, [messages]);

  const [inputText, setInputText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  
  // Breathing animation states
  const [breathPhase, setBreathPhase] = useState<"tarik" | "tahan" | "hembuskan">("tarik");
  const [breathCounter, setBreathCounter] = useState(4);
  const [isBreathingActive, setIsBreathingActive] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Breathing timer loop
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isBreathingActive) {
      interval = setInterval(() => {
        setBreathCounter((prev) => {
          if (prev <= 1) {
            // Shift phases
            if (breathPhase === "tarik") {
              setBreathPhase("tahan");
              return 4; // hold for 4s
            } else if (breathPhase === "tahan") {
              setBreathPhase("hembuskan");
              return 5; // exhale for 5s
            } else {
              setBreathPhase("tarik");
              return 4; // inhale for 4s
            }
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      setBreathCounter(4);
      setBreathPhase("tarik");
    }

    return () => clearInterval(interval);
  }, [isBreathingActive, breathPhase]);

  const messagesContainerRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = useCallback(() => {
    if (messagesContainerRef.current) {
      messagesContainerRef.current.scrollTo({
        top: messagesContainerRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading, scrollToBottom]);

  const sampleBkPrompts = [
    { label: "Stres Belajar", text: "Saya merasa sangat penat belajar tapi materi pelajaran rasanya tidak ada yang masuk ke otak..." },
    { label: "Cemas Nilai", text: "Saya terus-menerus cemas luar biasa nilai ujian saya jelek dan mengecewakan orang tua." },
    { label: "Pertemanan", text: "Saya merasa sangat diasingkan di lingkungan sekolah dan tidak memiliki teman akrab." },
    { label: "Krisis Tenang", text: "Beri saya tips relaksasi kilat ketika tiba-tiba terkena serangan panik saat ujian berlangsung." }
  ];

  const handleSendMessage = async (customText?: string) => {
    const finalQuery = customText || inputText;
    if (!finalQuery.trim()) return;

    const userMsgId = Date.now().toString();
    const newUserMessage: Message = {
      id: userMsgId,
      sender: "user",
      text: finalQuery,
      timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages(prev => [...prev, newUserMessage]);
    setInputText("");
    setIsLoading(true);

    setTimeout(scrollToBottom, 50);

    try {
      const response = await fetch("/api/counsel", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...messages, newUserMessage].slice(-10) // Limit context
        })
      });

      if (!response.ok) {
        let errMsg = `Server Error (Status: ${response.status})`;
        try {
          const text = await response.text();
          try {
            const errData = JSON.parse(text);
            if (errData && errData.error) {
              errMsg = errData.error;
            } else if (errData && errData.message) {
              errMsg = errData.message;
            }
          } catch {
            if (text) {
              const cleanText = text.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
              errMsg = cleanText.substring(0, 150) || errMsg;
            }
          }
        } catch {}
        throw new Error(errMsg);
      }

      const data = await response.json();
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        sender: "ai",
        text: data.text,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
      }]);

    } catch (err: any) {
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        sender: "ai",
        text: `**Liana:** Saya mendengar suaramu, tapi ada gangguan jaringan di sini. Tarik napas sejenak, saya selalu di sini untuk bersamamu... (Error: ${err.message})`,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
      }]);
    } finally {
      setIsLoading(false);
      setTimeout(scrollToBottom, 50);
    }
  };

  const handleResetChat = () => {
    if (confirm("Hapus seluruh catatan curhat kali ini untuk memulai dari awal?")) {
      setMessages([INITIAL_LIANA_MESSAGE]);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-5" id="liana_counseling_wrapper">
      
      {/* 1. Breathing Exercise and Safety Panel on Left (Mobile-proofed) */}
      <div className="lg:col-span-4 flex flex-col gap-4">
        {/* Breathing Assist Card */}
        <div className="bg-[#131316] border border-white/[0.06] rounded-2xl p-5 shadow-xl text-center flex flex-col items-center justify-between min-h-[320px]">
          <div>
            <div className="flex items-center justify-center gap-1.5 text-rose-300 font-semibold mb-1">
              <Wind className="w-4.5 h-4.5 text-rose-400" />
              <span className="text-sm">Meditasi Pernapasan</span>
            </div>
            <p className="text-xs text-white/50 leading-relaxed font-sans">
              Jika kamu merasa cemas, panik, atau detak jantung kencang, mari gunakan bantuan ritme napas di bawah ini.
            </p>
          </div>

          {/* Animated Circle Stage */}
          <div className="my-6 relative flex items-center justify-center">
            {/* Pulsing Breathing Background circles */}
            <div className={`absolute rounded-full bg-rose-500/10 transition-all duration-1000 ${
              isBreathingActive && breathPhase === "tarik" ? "w-36 h-36 scale-120 opacity-80" : 
              isBreathingActive && breathPhase === "tahan" ? "w-36 h-36 scale-120 opacity-100" :
              "w-24 h-24 scale-100 opacity-40"
            }`}></div>
            
            <div className={`w-28 h-28 rounded-full flex flex-col items-center justify-center text-white font-bold transition-all duration-1000 shadow-xl relative z-10 select-none border border-rose-500/30 ${
              isBreathingActive && breathPhase === "tarik" ? "bg-rose-500 hover:bg-rose-600 scale-110" : 
              isBreathingActive && breathPhase === "tahan" ? "bg-amber-600 hover:bg-amber-700 scale-110" : 
              "bg-rose-950/80 hover:bg-rose-900/80 text-rose-100 scale-100"
            }`}>
              <span className="text-xs tracking-wide uppercase font-mono">
                {!isBreathingActive ? "Tenang" : breathPhase}
              </span>
              <span className="text-2xl mt-0.5 animate-pulse">
                {!isBreathingActive ? "🧘‍♀️" : breathCounter}
              </span>
            </div>
          </div>

          <div className="w-full">
            {isBreathingActive ? (
              <div className="space-y-2">
                <p className="text-xs font-semibold text-rose-300 animate-pulse min-h-[16px] font-mono">
                  {breathPhase === "tarik" && "Tarik napas dalam-dalam secara perlahan..."}
                  {breathPhase === "tahan" && "Tahan napas Anda sejenak... Rasakan kedamaian."}
                  {breathPhase === "hembuskan" && "Hembuskan perlahan lewat mulut secara santai..."}
                </p>
                <button
                  type="button"
                  onClick={() => setIsBreathingActive(false)}
                  className="w-full py-2 bg-rose-950/40 text-rose-300 hover:bg-rose-900/40 hover:text-white border border-rose-500/30 rounded-xl text-xs cursor-pointer transition-colors"
                >
                  Hentikan Latihan
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => {
                  setIsBreathingActive(true);
                  setBreathPhase("tarik");
                  setBreathCounter(4);
                  onAddNotification("Mulai Relaksasi", "Latihan pernapasan 4-4-5 diaktifkan untuk menenangkan pikiranmu.");
                }}
                className="w-full py-2.5 bg-rose-500 hover:bg-rose-600 text-white font-medium rounded-lg text-sm cursor-pointer transition-colors"
              >
                Mulai Tarik Napas Tenang
              </button>
            )}
          </div>
        </div>

        {/* Security & Confidentiality Badges */}
        <div className="bg-[#131316] border border-white/[0.06] rounded-2xl p-4 text-xs space-y-2 shadow-xl">
          <div className="flex items-center gap-2 text-white/70 font-semibold">
            <ShieldCheck className="w-4 h-4 text-emerald-450 shrink-0" />
            <span>Privasi Terjaga</span>
          </div>
          <p className="text-white/45 leading-relaxed font-sans">
            Sesi konseling di NexonAcademic ini dijamin kerahasiaannya. Seluruh obrolan bersifat personal antara kamu dan Liana.
          </p>
          <div className="bg-white/[0.04] p-2.5 rounded-lg border border-white/[0.06] flex items-start gap-2 mt-1">
            <Info className="w-3.5 h-3.5 text-white/30 shrink-0 mt-0.5" />
            <p className="text-[10px] text-white/30 font-sans">
              Liana adalah asisten pendukung BK bertenaga AI. Silakan konsultasikan masalah kritis serius dengan konselor sekolah sesungguhnya.
            </p>
          </div>
        </div>
      </div>
       {/* 2. Counselor Chat Panel on Right */}
      <div 
        className={`flex flex-col bg-[#0a0a0c] transition-all duration-300 ease-out ${
          isExpanded 
            ? "fixed inset-0 z-[100] m-0 rounded-none w-screen h-screen" 
            : "lg:col-span-8 h-[calc(100vh-10rem)] md:h-[calc(100vh-6rem)] rounded-2xl border border-white/[0.06] overflow-hidden"
        }`}
      >
        
        {/* BK Hub Header — flat, no gradient banner */}
        <div className="border-b border-white/[0.06] px-4 py-3 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-full bg-rose-500/15 flex items-center justify-center shrink-0">
              <Heart className="w-3.5 h-3.5 fill-current text-rose-400" />
            </div>
            <div className="min-w-0">
              <div className="font-semibold text-sm text-white/90 leading-tight truncate flex items-center gap-2">
                <span>Liana</span>
                <span className="text-[9px] font-mono font-bold px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30 uppercase tracking-wide">
                  Nexon Core
                </span>
              </div>
              <div className="text-[11px] text-white/35 leading-tight truncate">Guru BK · Ruang Curhat Aman</div>
            </div>
          </div>
          <div className="flex items-center gap-0.5 shrink-0">
            <button 
              type="button"
              onClick={handleResetChat} 
              title="Mulai Ulang Curhat" 
              className="p-2 hover:bg-white/[0.06] rounded-lg text-white/40 hover:text-white/80 transition-colors cursor-pointer flex items-center justify-center"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
            <button 
              type="button"
              onClick={() => setIsExpanded(!isExpanded)} 
              title={isExpanded ? "Kecilkan Layar" : "Perbesar Layar"} 
              className="p-2 hover:bg-white/[0.06] rounded-lg text-white/40 hover:text-white/80 transition-colors cursor-pointer flex items-center justify-center"
            >
              {isExpanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Chat Stage */}
        <div ref={messagesContainerRef} className="flex-1 overflow-y-auto">
          <div className="max-w-3xl mx-auto px-4 py-6 space-y-6">
            {messages.map((msg) => (
              <div 
                key={msg.id}
                className={`flex gap-3 ${msg.sender === "user" ? "flex-row-reverse" : ""}`}
              >
                <div className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 mt-0.5 ${
                  msg.sender === "user" ? "bg-white/10 text-white/70" : "bg-rose-500/15 text-rose-400"
                }`}>
                  {msg.sender === "user" ? null : <Heart className="w-3.5 h-3.5 fill-current" />}
                </div>
                
                <div className={`flex flex-col gap-1 min-w-0 ${msg.sender === "user" ? "items-end max-w-[85%]" : "items-start max-w-[88%]"}`}>
                  <div className={`leading-relaxed text-[14.5px] ${
                    msg.sender === "user" 
                      ? "px-4 py-2.5 rounded-2xl bg-white/[0.07] text-white/95" 
                      : "text-white/90"
                  }`}>
                    {renderFormattedText(msg.text, "liana")}
                  </div>
                  <span className="text-[10px] text-white/25 px-1">{msg.timestamp}</span>
                </div>
              </div>
            ))}

            {isLoading && (
              <div className="flex gap-3">
                <div className="w-7 h-7 rounded-full bg-rose-500/15 text-rose-400 flex items-center justify-center shrink-0 mt-0.5">
                  <Heart className="w-3.5 h-3.5 fill-current" />
                </div>
                <div className="flex items-center gap-1.5 py-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-white/40 animate-bounce [animation-delay:-0.3s]"></span>
                  <span className="w-1.5 h-1.5 rounded-full bg-white/40 animate-bounce [animation-delay:-0.15s]"></span>
                  <span className="w-1.5 h-1.5 rounded-full bg-white/40 animate-bounce"></span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Suggested BK Questions on Initial State */}
        {messages.length === 1 && (
          <div className="px-4 pb-3 shrink-0">
            <div className="max-w-3xl mx-auto grid grid-cols-2 gap-2">
              {sampleBkPrompts.map((p, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setInputText(p.text)}
                  className="p-2.5 text-left bg-white/[0.04] hover:bg-white/[0.07] border border-white/[0.06] rounded-xl text-xs transition-colors cursor-pointer"
                >
                  <div className="font-medium text-white/80 mb-0.5 flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-rose-400" /> {p.label}
                  </div>
                  <div className="text-white/35 truncate text-[10px]">{p.text}</div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Input box — single rounded composer */}
        <div className="px-4 pb-4 pt-2 shrink-0">
          <div className="max-w-3xl mx-auto">
            <div className="flex items-end gap-2 bg-white/[0.05] border border-white/10 rounded-2xl p-1.5 focus-within:border-rose-500/40 transition-colors">
              <textarea
                rows={1}
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                placeholder="Ceritakan apa yang kamu rasakan..."
                className="flex-1 self-center px-3 py-2 bg-transparent outline-none text-[14.5px] text-white/90 placeholder-white/30 resize-none font-sans max-h-32"
              />
              <button
                type="button"
                disabled={!inputText.trim()}
                onClick={() => handleSendMessage()}
                className="p-2.5 bg-white/90 hover:bg-white text-black rounded-xl transition-all cursor-pointer flex items-center justify-center disabled:opacity-30 disabled:cursor-not-allowed shrink-0"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
            <div className="mt-1.5 text-[10px] text-white/25 text-center">
              Liana adalah pendamping AI, bukan pengganti konselor profesional.
            </div>
          </div>
        </div>
      </div>

    </div>
  );
}
