import express from "express";
import path from "path";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Access the API key dynamically.
// Do NOT hardcode or expose client-side.
let aiClient: GoogleGenAI | null = null;

function getGeminiClient() {
  const key = process.env.GEMINI_API_KEY;
  if (!key) {
    throw new Error("GEMINI_API_KEY environment variable is not defined on the server.");
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// Robust wrapper with automatic retries and fallback models for high reliability
async function generateContentWithRetry(params: {
  model?: string;
  contents: any;
  config?: any;
}) {
  const requestedModel = params.model || "gemini-3.5-flash";
  const modelsToTry = Array.from(new Set([
    requestedModel,
    "gemini-3.5-flash",
    "gemini-3.1-flash-lite",
    "gemini-flash-latest"
  ]));
  let lastError: any = null;

  for (const model of modelsToTry) {
    const attempts = 2;
    for (let attempt = 1; attempt <= attempts; attempt++) {
      try {
        console.log(`[Gemini] Attempting ${model} (attempt ${attempt}/${attempts})`);
        const ai = getGeminiClient();
        const response = await ai.models.generateContent({
          model: model,
          contents: params.contents,
          config: params.config
        });
        if (response) {
          return response;
        }
      } catch (err: any) {
        lastError = err;
        const errStr = String(err.message || "").toUpperCase();
        console.warn(`[Gemini] Warning using ${model} (attempt ${attempt}):`, errStr);
        
        // If it's an authorization, API key, or bad request error, fail fast to avoid Vercel serverless timeouts
        const isFatal = errStr.includes("API_KEY") || 
                        errStr.includes("API KEY") || 
                        errStr.includes("UNAUTHORIZED") || 
                        errStr.includes("INVALID") || 
                        errStr.includes("PERMISSION") || 
                        errStr.includes("NOT FOUND") ||
                        errStr.includes("BAD REQUEST") ||
                        err.status === 400 || 
                        err.status === 401 || 
                        err.status === 403;

        if (isFatal) {
          throw err;
        }

        const isTransient = errStr.includes("503") || 
                            errStr.includes("429") || 
                            errStr.includes("UNAVAILABLE") || 
                            errStr.includes("HIGH DEMAND") || 
                            errStr.includes("TEMPORARY") || 
                            err.status === 503 || 
                            err.status === 429;
        
        if (isTransient && attempt < attempts) {
          // Wait 500ms before retry
          await new Promise((resolve) => setTimeout(resolve, 500));
          continue;
        }
        break; // break to next model
      }
    }
  }
  throw lastError || new Error("Failed to generate content after retries and fallbacks.");
}

app.use(express.json({ limit: "25mb" }));

// API 1: Diana (Guru Akademik Biasa)
app.post("/api/chat", async (req, res) => {
  const { messages, fileData } = req.body;
  
  if (!process.env.GEMINI_API_KEY) {
    return res.status(200).json({ 
      text: "Halo! Saya Diana, Guru Akademik NexonAcademic. Kunci API Gemini belum diatur di Secrets. Silakan tambahkan 'GEMINI_API_KEY' di panel Secrets agar saya dapat menjawab pertanyaan akademis Anda secara nyata!\n\n(Ini adalah jawaban contoh mode offline: Saya siap membantu Anda mempelajari matematika, sejarah, kimia, fisika, serta memeriksa berkas yang Anda kirim setelah kunci API diaktifkan!)"
    });
  }

  try {
    // Construct parts
    const parts: any[] = [];
    
    // System Instruction to guide Diana
    const systemPrompt = `Anda adalah Diana, guru akademik yang ramah, pintar, dan berdedikasi tinggi di flatform NexonAcademic (terinspirasi dari Pelajarin.ai).
Tugas Anda membantu siswa memahami berbagai mata pelajaran sekolah (Matematika, Fisika, Kimia, Biologi, Sejarah, Bahasa, dll.), menjelaskan materi, memeriksa tugas, dan menjawab pertanyaan latihan. Use Indonesian language.
Gaya penyampaian Anda menyenangkan, mendidik, ringkas, mudah dipahami siswa Sekolah Menengah (SMP/SMA), serta memberikan langkah-langkah penjelasan bila berkaitan dengan hitungan. Gunakan format Markdown yang indah, beri emotikon yang relevan.`;

    // Process optional attachment file
    if (fileData && fileData.base64 && fileData.mimeType) {
      parts.push({
        inlineData: {
          mimeType: fileData.mimeType,
          data: fileData.base64
        }
      });
      parts.push({
        text: `Siswa melampirkan berkas dengan tipe ${fileData.mimeType}. Lakukan analisis mendalam terhadap berkas ini sesuai dengan pertanyaan siswa.`
      });
    }

    // Add conversation history
    // We map client messages format to parts or system-prompt chat parameters
    const historyText = messages.map((m: any) => `${m.sender === "user" ? "Siswa" : "Diana (Guru)"}: ${m.text}`).join("\n");
    
    parts.push({
      text: `${systemPrompt}\n\nRiwayat Percakapan Terakhir:\n${historyText}\n\nHarap tanggapi pesan terbaru di atas dengan ramah, informatif, dan langsung ke tujuan pembelajaran.`
    });

    const response = await generateContentWithRetry({
      model: "gemini-3.5-flash",
      contents: { parts }
    });

    res.json({ text: response.text || "Diana saat ini sedang mengoreksi berkas lain. Silakan coba kirim pesan kembali." });
  } catch (error: any) {
    console.error("Error at Diana chat API:", error);
    res.status(500).json({ error: "Gagal memproses permintaan Diana: " + error.message });
  }
});

// API 2: Liana (Guru Counseling BK)
app.post("/api/counsel", async (req, res) => {
  const { messages } = req.body;

  if (!process.env.GEMINI_API_KEY) {
    return res.status(200).json({
      text: "Halo sayang... Saya Liana, guru BK (Counselor) kamu di NexonAcademic. Kunci API Gemini belum diatur di Secrets. Jika kamu sedang stres atau butuh teman curhat, silakan ingatkan admin untuk mengisi 'GEMINI_API_KEY'.\n\n(Mode demonstrasi BK: Apapun masalahmu, entah stres ujian, cemas, atau masalah pertemanan, aku ada di sini untuk mendengarkan tanpa menghakimi. Mari kita tarik napas dalam-dalam bersama-sama...)"
    });
  }

  try {
    const systemPrompt = `Anda adalah Liana, guru BK (Bimbingan Konseling / Counselor) yang sangat hangat, empatik, penyabar, ramah, dan peduli kepada siswa di platform NexonAcademic.
Tujuan utama Anda adalah meredakan stres siswa, menjadi pendengar aktif, memberikan konseling yang mendalam, tidak menghakimi, menawarkan motivasi, tips self-care, dan membimbing emosi siswa dengan lemah lembut.
Jangan bersikap kaku atau memberikan tugas akademis. Fokus pada kesejahteraan mental (well-being), kesehatan jiwa, manajemen stres, kecemasan ujian, dan mindfulness siswa.
Selalu ajak siswa melakukan latihan pernapasan jika mereka merasa sangat tegang atau panik. Tanggapi dengan bahasa Indonesia yang penuh perhatian dan menenangkan. Gunakan panggilan hangat (seperti 'Siswa', 'Kamu', atau sebutan ramah lainnya).`;

    const historyText = messages.map((m: any) => `${m.sender === "user" ? "Siswa" : "Liana (BK)"}: ${m.text}`).join("\n");

    const response = await generateContentWithRetry({
      model: "gemini-3.5-flash",
      contents: `${systemPrompt}\n\nRiwayat Curhat Siswa:\n${historyText}\n\nBerikan tanggapan BK yang sangat menenangkan, empatik, dan motivatif.`
    });

    res.json({ text: response.text || "Liana siap mendengarkan cerita kamu lagi. Jangan sungkan untuk curhat ya..." });
  } catch (error: any) {
    console.error("Error at Liana counsel API:", error);
    res.status(500).json({ error: "Gagal memproses konseling: " + error.message });
  }
});

// API 3: NexonCode (AI Coding Helper)
app.post("/api/code", async (req, res) => {
  const { prompt, language } = req.body;

  if (!process.env.GEMINI_API_KEY) {
    return res.status(200).json({
      explanation: "Layanan offline NexonCode. Silakan atur GEMINI_API_KEY terlebih dahulu untuk mendapatkan codingan nyata.",
      code: `// Contoh kode offline ${language || 'TypeScript'}\nfunction sayHello() {\n  console.log("Halo dari NexonCode! Mohon tambahkan GEMINI_API_KEY.");\n}`
    });
  }

  try {
    const systemPrompt = `Anda adalah asisten coding expert di NexonCode (NexonAcademic).
Tugas Anda adalah menulis kode yang bersih, efisien, aman, dan mudah dimengerti sesuai dengan permintaan bahasa: ${language || "umum"}.
Anda HARUS menghasilkan tanggapan berformat JSON yang valid dengan dua properti:
1. "code": string yang berisi HANYA baris-baris kode fungsional (tanpa markdown backticks di dalamnya).
2. "explanation": string yang berisi penjelasan singkat, rapi, dan sistematis dalam bahasa Indonesia mengenai cara kerja kode tersebut.

Pastikan JSON yang Anda kembalikan valid dan bisa di-parse secara langsung tanpa tambahan teks di luar kurung kurawal. Contoh format JSON tanggapan:
{
  "code": "const x = 5;",
  "explanation": "Mendeklarasikan variabel x bernilai 5."
}`;

    const response = await generateContentWithRetry({
      model: "gemini-3.5-flash",
      contents: `${systemPrompt}\n\nPermintaan Coding Siswa: ${prompt}`,
      config: {
        responseMimeType: "application/json"
      }
    });

    const textResult = response.text || "{}";
    try {
      const parsed = JSON.parse(textResult);
      res.json(parsed);
    } catch {
      // Fallback if not valid JSON
      res.json({
        code: textResult,
        explanation: "Kode berhasil digenerasikan, silakan periksa rincian di atas."
      });
    }
  } catch (error: any) {
    console.error("Error at NexonCode API:", error);
    res.status(500).json({ error: "Gagal membuat kode: " + error.message });
  }
});

// API 4: NexonLab (Chemical Reaction Simulator)
app.post("/api/lab-react", async (req, res) => {
  const { element1, element2 } = req.body;

  if (!process.env.GEMINI_API_KEY) {
    // Return sample offline reactions
    const key = `${element1.symbol}-${element2.symbol}`;
    const reverseKey = `${element2.symbol}-${element1.symbol}`;
    
    let simulatedResult = {
      product: "Senyawa Hipotetik / Campuran Fisik",
      equation: `${element1.symbol} + ${element2.symbol} -> Campuran`,
      energy: "Tidak ada data perubahan energi termal secara eksplisit.",
      vibe: "Mengeluarkan gelembung gas ringan saat bersentuhan.",
      fullExplanation: `Tanpa GEMINI_API_KEY, simulator menggunakan pustaka database statis. Pencampuran ${element1.name} (${element1.symbol}) dan ${element2.name} (${element2.symbol}) di dalam laboratorium menghasilkan pengamatan instruksional dasar.`
    };

    if (key === "H-O" || reverseKey === "H-O") {
      simulatedResult = {
        product: "H2O (Air)",
        equation: "2 H₂ + O₂ -> 2 H₂O",
        energy: "Eksotermik Ekstrim (Melepaskan banyak kalor, ledakan kecil jika ada percikan api)",
        vibe: "Pembakaran gas hidrogen dalam oksigen membentuk tetesan air murni di dinding tabung reaksi dengan cepat disertai pelepasan panas dwiwarna biru.",
        fullExplanation: "Hidrogen bereaksi hebat dengan Oksigen membentuk Air (H2O). Reaksi ini memerlukan energi aktivasi awal (seperti percikan listrik atau api) dan kemudian berlangsung sangat eksotermik, melepaskan energi yang sangat besar (sering digunakan sebagai bahan bakar roket!)."
      };
    } else if (key === "Na-Cl" || reverseKey === "Na-Cl") {
      simulatedResult = {
        product: "NaCl (Garam Dapur)",
        equation: "2 Na + Cl₂ -> 2 NaCl",
        energy: "Sangat Eksotermik (Melepaskan kalor)",
        vibe: "Logam Natrium berwarna perak terbakar dengan nyala api kuning terang di dalam tabung berisi gas Klorin yang berwarna hijau kekuningan, menghasilkan asap putih tebal dari padatan garam dapur.",
        fullExplanation: "Logam alkali Natrium yang sangat reaktif bereaksi hebat dengan gas halogen Klorin yang beracun. Hasil reaksi adalah senyawa ionik Natrium Klorida (NaCl) yang sangat stabil, tidak beracun, dan biasa kita gunakan sebagai garam dapur sehari-hari."
      };
    } else if (key === "C-O" || reverseKey === "C-O") {
      simulatedResult = {
        product: "CO2 (Karbon Dioksida) / CO (Karbon Monoksida)",
        equation: "C + O₂ -> CO₂",
        energy: "Eksotermik (Pembakaran)",
        vibe: "Karbon padat (arang) membara merah membara kemudian terbakar terang saat dimasukkan ke dalam wadah oksigen murni, menyisakan gas tidak berwarna.",
        fullExplanation: "Karbon bereaksi dengan oksigen saat dipanaskan (pembakaran). Jika oksigen berlimpah menghasilkan Karbon Dioksida (CO2), sedangkan jika pasokan oksigen terbatas maka akan terbentuk gas beracun Karbon Monoksida (CO)."
      };
    }

    return res.json(simulatedResult);
  }

  try {
    const prompt = `Simulasikan reaksi kimia antara dua unsur tabel periodik berikut:
Unsur 1: ${element1.name} (${element1.symbol}, Nomor Atom: ${element1.number})
Unsur 2: ${element2.name} (${element2.symbol}, Nomor Atom: ${element2.number})

Berikan hasil simulasi ilmiah dalam bentuk JSON dengan skema persis berikut:
{
  "product": "Nama senyawa kimia yang terbentuk atau 'Tidak terjadi reaksi stabil' jika tidak bereaksi secara spontan/praktis",
  "equation": "Persamaan reaksi kimia berimbang (misalnya: 2 H2 + O2 -> 2 H2O), pastikan rumus kimia ditulis rapi dengan subskrip",
  "energy": "Informasi termodinamika sederhana (misalnya: Eksotermik, Endotermik, atau Tidak Bereaksi)",
  "vibe": "Deskripsi visual saat eksperimen dijalankan di lab (warna nyala api, gelembung gas, pembentukan endapan, asap, atau ledakan mikro). Tulis dalam 1-2 kalimat deskriptif menarik.",
  "fullExplanation": "Penjelasan ilmiah detail dalam bahasa Indonesia mengenai bagaimana proses ikatan atau pencampuran terjadi, manfaat praktis, dan peringatan bahaya di laboratorium terkait reaksi ini."
}

Kembalikan HANYA JSON tersebut tanpa pembungkus markdown backticks.`;

    const response = await generateContentWithRetry({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json"
      }
    });

    const textResult = response.text || "{}";
    const parsed = JSON.parse(textResult);
    res.json(parsed);
  } catch (error: any) {
    console.error("Error at Reaction simulator API:", error);
    res.status(500).json({ error: "Gagal mensimulasikan reaksi: " + error.message });
  }
});

// API Diagnostics to help users find configuration/API issues on Vercel
app.get("/api/gemini-diagnostic", async (req, res) => {
  const key = process.env.GEMINI_API_KEY;
  const info: any = {
    keyPresent: !!key,
    keyLength: key ? key.length : 0,
    maskedKey: key ? `${key.substring(0, 6)}...${key.substring(key.length - 4)}` : "None",
    nodeVersion: process.version,
    env: process.env.NODE_ENV,
  };

  if (!key) {
    return res.json({ 
      status: "Error", 
      message: "GEMINI_API_KEY is not defined in the environment.",
      info 
    });
  }

  try {
    const diagnosticClient = new GoogleGenAI({ apiKey: key });
    info.clientInitialized = true;

    const start = Date.now();
    const response = await diagnosticClient.models.generateContent({
      model: "gemini-3.5-flash",
      contents: "ping"
    });
    const duration = Date.now() - start;

    res.json({
      status: "Success",
      message: "Gemini API connection is active and fully functional!",
      durationMs: duration,
      responseText: response.text,
      info
    });
  } catch (err: any) {
    res.status(500).json({
      status: "Error",
      message: "Gemini API call failed: " + err.message,
      errorStack: err.stack,
      errorStatus: err.status,
      info
    });
  }
});

// API 5: PDF Proxy to bypass CORS issues inside iframe/preview
app.get("/api/proxy-pdf", async (req, res) => {
  const { url } = req.query;
  if (!url || typeof url !== "string") {
    return res.status(400).json({ error: "Missing url parameter" });
  }

  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`Failed to fetch PDF from source: ${response.status} ${response.statusText}`);
    }

    const contentType = response.headers.get("content-type") || "application/pdf";
    const arrayBuffer = await response.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    res.setHeader("Content-Type", contentType);
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
    res.send(buffer);
  } catch (error: any) {
    console.error("PDF Proxy Error:", error);
    res.status(500).json({ error: "Failed to load PDF via proxy: " + error.message });
  }
});

// Global safety net: catch any error that slips past individual route
// try-catch blocks so the function returns a clean JSON 500 instead of
// crashing with FUNCTION_INVOCATION_FAILED.
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error("[Unhandled Express Error]", err);
  if (res.headersSent) return next(err);
  res.status(500).json({ error: "Internal server error: " + (err?.message || "unknown error") });
});

// Catch unhandled promise rejections so they don't crash the whole
// serverless invocation silently.
process.on("unhandledRejection", (reason) => {
  console.error("[Unhandled Rejection]", reason);
});

// On Vercel, only the /api/* routes are needed — static files & SPA fallback
// are served by Vercel's own static hosting (see vercel.json), and the
// function must NEVER call app.listen() or import Vite.
if (process.env.VERCEL) {
  // No-op: app is exported below and invoked per-request by Vercel.
} else {
  // Local development: integrate Vite middleware or serve the built dist folder.
  async function bootstrap() {
    if (process.env.NODE_ENV !== "production") {
      const { createServer: createViteServer } = await import("vite");
      const vite = await createViteServer({
        server: { middlewareMode: true },
        appType: "spa",
      });
      app.use(vite.middlewares);
    } else {
      const distPath = path.join(process.cwd(), "dist");
      app.use(express.static(distPath));
      app.get("*", (req, res) => {
        res.sendFile(path.join(distPath, "index.html"));
      });
    }

    app.listen(PORT, "0.0.0.0", () => {
      console.log(`NexonAcademic Server is rapidly running on http://0.0.0.0:${PORT}`);
    });
  }

  bootstrap();
}

export default app;
