import { useState } from "react";
import { renderFormattedText } from "./DianaChat";
import { ELEMENTS_DATA } from "../data/elements";
import { ElementInfo } from "../types";
import { 
  FlaskConical, 
  Atom, 
  Info, 
  Compass, 
  Flame, 
  Dna, 
  Sparkles, 
  RefreshCw,
  AlertTriangle,
  Bookmark
} from "lucide-react";

interface NexonLabSandboxProps {
  onAddNotification: (title: string, msg: string) => void;
}

export default function NexonLabSandbox({ onAddNotification }: NexonLabSandboxProps) {
  const [labTab, setLabTab] = useState<"explorer" | "simulator">("explorer");
  
  // Tab 1: Selected Explorer element
  const [selectedElement, setSelectedElement] = useState<ElementInfo>(ELEMENTS_DATA[0]);

  // Tab 2: Reactant selections
  const [reactant1, setReactant1] = useState<ElementInfo | null>(null);
  const [reactant2, setReactant2] = useState<ElementInfo | null>(null);
  const [isReacting, setIsReacting] = useState(false);
  const [reactionResult, setReactionResult] = useState<{
    product: string;
    equation: string;
    energy: string;
    vibe: string;
    fullExplanation: string;
  } | null>(null);

  // Helper colors for classification
  const getCategoryColor = (category: string) => {
    switch (category) {
      case "alkali": return "bg-red-500 hover:bg-red-650 text-white";
      case "alkaline-earth": return "bg-orange-400 hover:bg-orange-500 text-white";
      case "transition": return "bg-amber-300 hover:bg-amber-400 text-slate-800";
      case "post-transition": return "bg-emerald-300 hover:bg-emerald-400 text-emerald-950";
      case "metalloid": return "bg-teal-400 hover:bg-teal-500 text-slate-900";
      case "nonmetal": return "bg-blue-400 hover:bg-blue-500 text-white";
      case "halogen": return "bg-indigo-400 hover:bg-indigo-500 text-white";
      case "noble": return "bg-purple-400 hover:bg-purple-500 text-white";
      case "lanthanide": return "bg-pink-400 hover:bg-pink-500 text-slate-950";
      case "actinide": return "bg-rose-400 hover:bg-rose-500 text-white";
      default: return "bg-slate-400 hover:bg-slate-500 text-white";
    }
  };

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case "alkali": return "Logam Alkali";
      case "alkaline-earth": return "Logam Alkali Tanah";
      case "transition": return "Logam Transisi";
      case "post-transition": return "Logam Pasca Transisi";
      case "metalloid": return "Metaloid";
      case "nonmetal": return "Nonlogam Reaktif";
      case "halogen": return "Halogen";
      case "noble": return "Gas Mulia";
      case "lanthanide": return "Lantanida";
      case "actinide": return "Aktinida";
      default: return "Lainnya";
    }
  };

  // Click handler inside Reaction tab
  const handleSelectReactant = (element: ElementInfo) => {
    if (reactant1 && reactant1.number === element.number) {
      // De-select reactant 1
      setReactant1(null);
      setReactionResult(null);
      return;
    }
    if (reactant2 && reactant2.number === element.number) {
      // De-select reactant 2
      setReactant2(null);
      setReactionResult(null);
      return;
    }

    if (!reactant1) {
      setReactant1(element);
      setReactionResult(null);
    } else if (!reactant2) {
      setReactant2(element);
      setReactionResult(null);
      onAddNotification("Unsur Terpilih", `${element.name} diset sebagai reaktan kedua.`);
    } else {
      // Override reactant 2
      setReactant2(element);
      setReactionResult(null);
    }
  };

  const handleRunReaction = async () => {
    if (!reactant1 || !reactant2) return;

    setIsReacting(true);
    try {
      const response = await fetch("/api/lab-react", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          element1: reactant1,
          element2: reactant2
        })
      });

      if (!response.ok) {
        let errMsg = `Server Error (Status: ${response.status})`;
        try {
          const text = await response.text();
          try {
            const errData = JSON.parse(text);
            if (errData && errData.error) {
              errMsg = errData.error;
            } else if (errData && errData.message) {
              errMsg = errData.message;
            }
          } catch {
            if (text) {
              const cleanText = text.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
              errMsg = cleanText.substring(0, 150) || errMsg;
            }
          }
        } catch {}
        throw new Error(errMsg);
      }

      const result = await response.json();
      setReactionResult(result);
      onAddNotification("Reaksi Selesai!", `Terbentuk: ${result.product}`);
    } catch (err: any) {
      console.error("Gagal simulasikan reaksi:", err);
      setReactionResult({
        product: "Error pencampuran",
        equation: `${reactant1.symbol} + ${reactant2.symbol} -> ?`,
        energy: "Gagal memproses",
        vibe: "Mengeluarkan uap kegagalan karena jaringan lab putus.",
        fullExplanation: `Pastikan koneksi internet ke API Gemini murni aktif dan normal untuk melakukan pencampuran reaktan. (Detail Error: ${err.message})`
      });
    } finally {
      setIsReacting(false);
    }
  };

  const handleClearReactants = () => {
    setReactant1(null);
    setReactant2(null);
    setReactionResult(null);
  };

  return (
    <div className="space-y-5" id="nexonlab_sandbox_container">
      
      {/* 1. Sub-tab headers with fully responsive interface */}
      <div className="flex bg-[#0d0f17] p-1 rounded-xl max-w-md border border-white/5 shadow-inner">
        <button
          onClick={() => {
            setLabTab("explorer");
            setSelectedElement(ELEMENTS_DATA[0]);
          }}
          className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            labTab === "explorer" ? "bg-teal-500/10 text-teal-400 border border-teal-500/30 shadow-sm" : "text-white/40 hover:text-white/85"
          }`}
        >
          <Compass className="w-4 h-4 text-teal-400" />
          <span>Explorer Unsur</span>
        </button>
        <button
          onClick={() => {
            setLabTab("simulator");
            handleClearReactants();
          }}
          className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            labTab === "simulator" ? "bg-teal-500/10 text-teal-400 border border-teal-500/30 shadow-sm" : "text-white/40 hover:text-white/85"
          }`}
        >
          <FlaskConical className="w-4 h-4 text-emerald-400" />
          <span>Simulator Reaksi</span>
        </button>
      </div>

      {/* Grid containing periodic map and card summary panels */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        
        {/* Periodic Map Grid taking largest chunk */}
        <div className="lg:col-span-8 bg-[#0d0f17] border border-white/5 rounded-2xl p-4 shadow-2xl overflow-x-auto">
          <div className="flex items-center justify-between mb-4 border-b border-white/5 pb-2">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-1.5 font-mono">
                <Atom className="w-4.5 h-4.5 text-teal-400 animate-spin" />
                <span>Peta Interaktif Tabel Periodik Unsur</span>
              </h3>
              <p className="text-[11px] text-white/50">
                {labTab === "explorer" 
                  ? "Klik untuk melihat analisis instan atom unsur di panel inspektur" 
                  : "Klik Unsur Pertama lalu Unsur Kedua untuk mereaksikan bahan kimia!"}
              </p>
            </div>

            {/* Quick indicators of reactant selections */}
            {labTab === "simulator" && (reactant1 || reactant2) && (
              <button
                onClick={handleClearReactants}
                className="py-1.5 px-3 bg-[#12141c] hover:bg-rose-500/10 text-white/70 hover:text-white rounded-lg text-[10px] font-mono border border-white/10 hover:border-rose-500/30 flex items-center gap-1 cursor-pointer transition-colors"
              >
                <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Bersihkan Reaktan
              </button>
            )}
          </div>

          {/* Real chemical shape representation layout via CSS grid */}
          <div className="min-w-[840px] grid gap-1 p-1" style={{ gridTemplateColumns: "repeat(18, minmax(0, 1fr))" }}>
            {ELEMENTS_DATA.map((element) => {
              // Determine active highlights
              let highlightBorder = "border-transparent";
              let animationPulse = "";

              if (labTab === "explorer") {
                if (selectedElement.number === element.number) {
                  highlightBorder = "border-white ring-2 ring-teal-450 scale-103 shadow-md";
                }
              } else {
                if (reactant1?.number === element.number) {
                  highlightBorder = "border-green-400 ring-2 ring-green-500 scale-103 shadow-md";
                  animationPulse = "animate-pulse";
                } else if (reactant2?.number === element.number) {
                  highlightBorder = "border-amber-400 ring-2 ring-amber-500 scale-103 shadow-md";
                  animationPulse = "animate-pulse";
                }
              }

              return (
                <button
                  key={element.number}
                  type="button"
                  style={{ 
                    gridColumnStart: element.col, 
                    gridRowStart: element.row 
                  }}
                  onClick={() => {
                    if (labTab === "explorer") {
                      setSelectedElement(element);
                    } else {
                      handleSelectReactant(element);
                    }
                  }}
                  className={`p-1.5 rounded-lg text-center border font-sans select-none flex flex-col justify-between items-center transition-all cursor-pointer aspect-square ${getCategoryColor(element.category)} ${highlightBorder} ${animationPulse}`}
                >
                  <div className="w-full flex justify-between text-[7px] font-bold font-mono opacity-80 leading-none">
                    <span>{element.number}</span>
                    <span className="capitalize">{element.phase?.[0]}</span>
                  </div>
                  <span className="text-xs md:text-sm font-black tracking-tight leading-none my-auto">{element.symbol}</span>
                  <span className="text-[6.5px] truncate max-w-full leading-none font-bold block">{element.name}</span>
                </button>
              );
            })}
          </div>

          {/* Color Key Guide bar */}
          <div className="mt-4 flex flex-wrap gap-2 text-[9px] font-semibold text-white/40 border-t border-white/5 pt-3 font-mono">
            <span className="bg-white/5 px-1.5 py-0.5 rounded text-white/60">Warna Unsur:</span>
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded bg-red-500 inline-block pointer-events-none"></span> Alkali</span>
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded bg-orange-400 inline-block pointer-events-none"></span> Alkali Tanah</span>
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded bg-amber-300 inline-block pointer-events-none text-slate-800"></span> Logam Transisi</span>
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded bg-emerald-300 inline-block pointer-events-none"></span> Pasca Transisi</span>
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded bg-teal-400 inline-block pointer-events-none"></span> Metaloid</span>
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded bg-blue-400 inline-block pointer-events-none"></span> Nonlogam</span>
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded bg-indigo-400 inline-block pointer-events-none"></span> Halogen</span>
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded bg-purple-400 inline-block pointer-events-none"></span> Gas Mulia</span>
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded bg-pink-400 inline-block pointer-events-none"></span> Lantanida</span>
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded bg-rose-400 inline-block pointer-events-none"></span> Aktinida</span>
          </div>
        </div>

        {/* 2. TAB 1: Inspector element on right */}
        {labTab === "explorer" && (
          <div className="lg:col-span-4 bg-[#0d0f17] border border-white/5 rounded-2xl p-5 shadow-2xl space-y-4">
            <div className="flex items-center gap-2 border-b border-white/5 pb-3">
              <div className="p-2 bg-teal-500/10 text-teal-400 rounded-lg shrink-0 border border-teal-500/30">
                <Info className="w-4.5 h-4.5" />
              </div>
              <div>
                <h4 className="font-bold text-white text-sm font-sans">Inspektur Unsur</h4>
                <p className="text-[10px] text-teal-400 font-mono">Detail Spesifikasi Kimia</p>
              </div>
            </div>

            {/* Giant Element Card display */}
            <div className="bg-[#12141c] border border-white/10 rounded-2xl p-5 flex flex-col items-center justify-center text-center shadow-inner relative overflow-hidden">
              <div className="absolute top-2 right-3 font-mono text-[9px] text-teal-400 font-semibold uppercase bg-teal-950/40 border border-teal-900/30 px-1.5 py-0.5 rounded">
                {getCategoryLabel(selectedElement.category)}
              </div>
              
              <span className="text-white/40 text-[10px] font-bold font-mono">No. Atom: {selectedElement.number}</span>
              <span className="text-4xl font-extrabold text-white my-1 tracking-tight">{selectedElement.symbol}</span>
              <span className="text-base font-bold text-white/90">{selectedElement.name}</span>
              <span className="text-xs text-teal-300 font-mono mt-0.5">Berat Atom: {selectedElement.mass} u</span>
            </div>

            {/* Scientific Properties */}
            <div className="space-y-4 text-xs font-sans">
              <div className="flex justify-between py-1.5 border-b border-white/5 text-white/60">
                <span className="font-semibold text-white/40">Periode / Golongan</span>
                <span className="font-mono font-bold text-white/85">{selectedElement.period} / {selectedElement.group}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-white/5 text-white/60">
                <span className="font-semibold text-white/40">Wujud Alami (25°C)</span>
                <span className="font-bold text-white/85 capitalize">{selectedElement.phase || "solid"}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-white/5 text-white/60">
                <span className="font-semibold text-white/40">Kerapatan / Kepadatan</span>
                <span className="font-mono text-white/85">{selectedElement.density || "Tidak ada data"}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-white/5 text-white/60">
                <span className="font-semibold text-white/40">Penemu Pertama</span>
                <span className="text-white/85 font-medium">{selectedElement.discoverer || "Zaman Kuno"}</span>
              </div>
            </div>

            <div className="bg-teal-950/20 p-3.5 rounded-xl border border-teal-900/30 text-xs leading-relaxed text-teal-200 font-sans">
              <span className="font-bold text-teal-300 block mb-1 flex items-center gap-0.5 font-mono"><Dna className="w-3.5 h-3.5" /> Hubungan & Karakteristik:</span>
              {selectedElement.summary}
            </div>
          </div>
        )}

        {/* 3. TAB 2: Reaction Console simulator on right */}
        {labTab === "simulator" && (
          <div className="lg:col-span-4 bg-[#0d0f17] border border-white/5 rounded-2xl p-5 shadow-2xl space-y-4 flex flex-col justify-between font-sans">
            <div className="space-y-4">
              <div className="flex items-center gap-2 border-b border-white/5 pb-3">
                <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-lg shrink-0 border border-emerald-500/30">
                  <Flame className="w-4.5 h-4.5 animate-pulse" />
                </div>
                <div>
                  <h4 className="font-bold text-white text-sm font-sans">Konsol Pencampuran</h4>
                  <p className="text-[10px] text-emerald-400 font-mono">Reaksi Tabung Eksperimen</p>
                </div>
              </div>

              {/* Reaktan slots display */}
              <div className="grid grid-cols-2 gap-2">
                <div className="bg-emerald-950/20 border border-emerald-500/20 rounded-xl p-3 text-center">
                  <span className="text-[9px] font-bold text-emerald-400 block mb-1 uppercase tracking-wider font-mono">Reaktan A</span>
                  {reactant1 ? (
                    <div className="space-y-0.5 animate-fadeIn">
                      <span className="text-xl font-extrabold text-white block">{reactant1.symbol}</span>
                      <span className="text-[11px] font-semibold text-emerald-300 truncate block">{reactant1.name}</span>
                    </div>
                  ) : (
                    <span className="text-xs text-white/30 font-medium block py-2.5">Pilih di tabel periodik</span>
                  )}
                </div>
                
                <div className="bg-amber-950/20 border border-amber-500/20 rounded-xl p-3 text-center">
                  <span className="text-[9px] font-bold text-amber-400 block mb-1 uppercase tracking-wider font-mono">Reaktan B</span>
                  {reactant2 ? (
                    <div className="space-y-0.5 animate-fadeIn">
                      <span className="text-xl font-extrabold text-white block">{reactant2.symbol}</span>
                      <span className="text-[11px] font-semibold text-amber-300 truncate block">{reactant2.name}</span>
                    </div>
                  ) : (
                    <span className="text-xs text-white/30 font-medium block py-2.5">Pilih di tabel periodik</span>
                  )}
                </div>
              </div>

              {/* Run reaction trigger */}
              <button
                type="button"
                disabled={!reactant1 || !reactant2 || isReacting}
                onClick={handleRunReaction}
                className="w-full py-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold rounded-xl text-xs uppercase tracking-wider transition-all disabled:opacity-40 disabled:cursor-not-allowed shadow-md cursor-pointer flex items-center justify-center gap-1.5"
              >
                {isReacting ? (
                  <>
                    <svg className="animate-spin h-4.5 w-4.5 text-white" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                    </svg>
                    <span className="font-mono">Tabung sedang direaksikan...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-white animate-pulse" />
                    <span>Reaksikan! (Mulai Selesai)</span>
                  </>
                )}
              </button>
            </div>

            {/* Results Panel */}
            {reactionResult ? (
              <div className="mt-4 p-4 bg-[#12141c] text-[#e2e8f0] rounded-xl border border-white/5 space-y-3 shadow-2xl animate-fadeIn">
                <div>
                  <span className="text-[9px] font-bold text-emerald-400 font-mono tracking-wider block uppercase mb-1">Hasil Reaksi Kimia</span>
                  <div className="text-sm font-extrabold text-white">{reactionResult.product}</div>
                  <div className="text-xs font-mono font-bold text-amber-400 mt-1">{reactionResult.equation}</div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[10px] border-t border-white/5 pt-2 font-mono">
                  <div>
                    <span className="text-white/40 block text-[9px] uppercase font-semibold">Energi Reaksi:</span>
                    <span className="text-rose-400 font-bold">{reactionResult.energy}</span>
                  </div>
                  <div>
                    <span className="text-white/40 block text-[9px] uppercase font-semibold">Fenomena Lab:</span>
                    <span className="text-teal-300 font-bold leading-tight">{reactionResult.vibe}</span>
                  </div>
                </div>

                <div className="text-[11.5px] text-white/80 leading-relaxed border-t border-white/5 pt-2 font-sans">
                  {renderFormattedText(reactionResult.fullExplanation, "diana")}
                </div>
              </div>
            ) : reactant1 && reactant2 ? (
              <div className="mt-4 p-3.5 bg-[#12141c] border border-white/5 rounded-xl text-center text-xs text-white/50 leading-relaxed flex flex-col items-center">
                <span className="text-lg">🧪</span>
                <span className="font-semibold text-emerald-400 mt-1 font-mono">Bahan Siap!</span>
                Klik tombol "Reaksikan!" di atas untuk mensimulasikan pencampuran senyawa logam/non-logam di laboratorium NexonLab.
              </div>
            ) : (
              <div className="mt-4 p-3.5 bg-[#12141c] border border-white/5 rounded-xl text-center text-xs text-white/40 leading-relaxed flex flex-col items-center">
                <AlertTriangle className="w-5 h-5 text-amber-500 mb-1 animate-pulse" />
                Silakan pilih dua unsur terlebih dahulu dari peta tabel periodik interaktif di kiri.
              </div>
            )}
          </div>
        )}

      </div>

    </div>
  );
}
