import express from "express";
import path from "path";
import { GoogleGenAI, ThinkingLevel } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Access the API key dynamically.
// Do NOT hardcode or expose client-side.
let aiClient: GoogleGenAI | null = null;

function getGeminiClient() {
  const key = process.env.GEMINI_API_KEY;
  if (!key) {
    throw new Error("GEMINI_API_KEY environment variable is not defined on the server.");
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// Robust wrapper with automatic retries and fallback models for high reliability
async function generateContentWithRetry(params: {
  model?: string;
  contents: any;
  config?: any;
  fastFail?: boolean; // trims retries for latency-sensitive interactive chat
}) {
  const requestedModel = params.model || "gemini-3.5-flash";
  const fullChain = Array.from(new Set([
    requestedModel,
    "gemini-3.5-flash",
    "gemini-3.1-flash-lite",
    "gemini-flash-latest"
  ]));
  const modelsToTry = params.fastFail ? fullChain.slice(0, 2) : fullChain;
  const attemptsPerModel = params.fastFail ? 1 : 2;
  let lastError: any = null;

  for (const model of modelsToTry) {
    const attempts = attemptsPerModel;
    for (let attempt = 1; attempt <= attempts; attempt++) {
      try {
        console.log(`[Gemini] Attempting ${model} (attempt ${attempt}/${attempts})`);
        const ai = getGeminiClient();
        const response = await ai.models.generateContent({
          model: model,
          contents: params.contents,
          config: params.config
        });
        if (response) {
          return response;
        }
      } catch (err: any) {
        lastError = err;
        const errStr = String(err.message || "").toUpperCase();
        console.warn(`[Gemini] Warning using ${model} (attempt ${attempt}):`, errStr);
        
        // If it's an authorization, API key, or bad request error, fail fast to avoid Vercel serverless timeouts
        const isFatal = errStr.includes("API_KEY") || 
                        errStr.includes("API KEY") || 
                        errStr.includes("UNAUTHORIZED") || 
                        errStr.includes("INVALID") || 
                        errStr.includes("PERMISSION") || 
                        errStr.includes("NOT FOUND") ||
                        errStr.includes("BAD REQUEST") ||
                        err.status === 400 || 
                        err.status === 401 || 
                        err.status === 403;

        if (isFatal) {
          throw err;
        }

        const isTransient = errStr.includes("503") || 
                            errStr.includes("429") || 
                            errStr.includes("UNAVAILABLE") || 
                            errStr.includes("HIGH DEMAND") || 
                            errStr.includes("TEMPORARY") || 
                            err.status === 503 || 
                            err.status === 429;
        
        if (isTransient && attempt < attempts) {
          // Wait 500ms before retry
          await new Promise((resolve) => setTimeout(resolve, 500));
          continue;
        }
        break; // break to next model
      }
    }
  }
  throw lastError || new Error("Failed to generate content after retries and fallbacks.");
}

app.use(express.json({ limit: "25mb" }));

// API 1: Nexon AI Chat (General AI Assistant with File Support)
app.post("/api/chat", async (req, res) => {
  const { messages, fileData } = req.body;
  
  if (!process.env.GEMINI_API_KEY) {
    return res.status(200).json({ 
      text: "Halo! Saya Nexon AI, asisten virtual serbaguna Anda. Saat ini saya berjalan dalam mode offline karena kunci API Gemini belum diatur di Secrets. Silakan tambahkan 'GEMINI_API_KEY' di panel Secrets agar saya dapat membantu Anda secara maksimal!\n\n(Ini adalah balasan contoh mode offline. Saya siap membantu menjawab pertanyaan, menerjemahkan, merangkum, dan menulis setelah kunci API diaktifkan!)"
    });
  }

  try {
    const parts: any[] = [];
    const systemPrompt = `Anda adalah Nexon AI, asisten kecerdasan buatan serbaguna yang sangat cerdas, profesional, ramah, dan berwawasan luas yang dikembangkan oleh Nexon.
Tugas utama Anda:
1. Membantu produktivitas, kreativitas, penulisan, ide, penerjemahan, perangkuman, dan aktivitas sehari-hari pengguna.
2. Memberikan penjelasan yang berbobot, akurat, dan komprehensif.
3. Gunakan bahasa Indonesia yang sopan, ramah, profesional, dan menyenangkan.
4. Gunakan format Markdown yang indah (tabel, list, cetak tebal) untuk keterbacaan yang sempurna, disertai emotikon yang relevan.`;

    // Process optional attachment file
    if (fileData && fileData.base64 && fileData.mimeType) {
      parts.push({
        inlineData: {
          mimeType: fileData.mimeType,
          data: fileData.base64
        }
      });
      parts.push({
        text: `Pengguna melampirkan berkas dengan tipe ${fileData.mimeType}. Lakukan analisis mendalam terhadap berkas ini sesuai dengan pertanyaan pengguna.`
      });
    }

    // Map conversation history
    const historyText = messages.map((m: any) => `${m.sender === "user" ? "User" : "Nexon AI"}: ${m.text}`).join("\n");
    
    parts.push({
      text: `${systemPrompt}\n\nRiwayat Percakapan:\n${historyText}\n\nTanggapi pesan terakhir pengguna dengan jawaban yang sangat cerdas, ramah, dan terstruktur.`
    });

    const response = await generateContentWithRetry({
      model: "gemini-3.5-flash",
      contents: { parts }
    });

    res.json({ text: response.text || "Mohon maaf, terjadi kendala saat memproses jawaban. Silakan coba kembali." });
  } catch (error: any) {
    console.error("Error at Nexon AI Chat API:", error);
    res.status(500).json({ error: "Gagal memproses obrolan Nexon AI: " + error.message });
  }
});

// API 2: Nexon AI Code (Specialized Developer Assistant)
app.post("/api/code", async (req, res) => {
  const { messages, language } = req.body;

  if (!process.env.GEMINI_API_KEY) {
    return res.status(200).json({
      text: "Layanan Nexon AI Code sedang offline. Mohon tambahkan kunci 'GEMINI_API_KEY' di panel Secrets untuk mengaktifkan AI programmer nyata.\n\nContoh kode:\n```javascript\nfunction sayHello() {\n  console.log('Halo dari Nexon AI Code!');\n}\n```"
    });
  }

  try {
    const systemPrompt = `Anda adalah Nexon AI Code, pakar pemrograman profesional yang dirancang khusus untuk membantu developer menulis, memperbaiki, menjelaskan, mengoptimalkan, dan mempelajari berbagai bahasa pemrograman (${language || "bahasa yang relevan"}).
Karakteristik Anda:
1. Selalu sertakan blok kode lengkap, bersih, siap-jalan, dan terstruktur dengan sintaks modern dan penanganan edge-case (seperti input kosong, validasi).
2. Jelaskan cara kerja kode secara terperinci menggunakan bahasa Indonesia yang ringkas, terarah, dan mudah dipahami.
3. Berikan saran performa, keamanan, atau alternatif yang lebih baik jika diperlukan.
4. Tanggapi dengan format Markdown lengkap yang sangat profesional.`;

    const historyText = messages.map((m: any) => `${m.sender === "user" ? "User" : "Nexon AI Code"}: ${m.text}`).join("\n");

    const response = await generateContentWithRetry({
      model: "gemini-3.5-flash", // gemini-3.5-flash handles programming tasks beautifully
      contents: `${systemPrompt}\n\nRiwayat Percakapan Coding:\n${historyText}\n\nTolong bantu pengguna dengan kode berkualitas tinggi dan penjelasan terstruktur.`
    });

    res.json({ text: response.text || "Gagal menghasilkan kode pemrograman." });
  } catch (error: any) {
    console.error("Error at Nexon AI Code API:", error);
    res.status(500).json({ error: "Gagal memproses kode pemrograman: " + error.message });
  }
});

// API 3: Nexon AI Canvas (Image Generation with Robust SVG Fallback)
app.post("/api/canvas", async (req, res) => {
  const { prompt, aspectRatio = "1:1" } = req.body;

  if (!process.env.GEMINI_API_KEY) {
    return res.status(200).json({
      isFallback: true,
      mimeType: "image/svg+xml",
      data: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="100%" height="100%"><rect width="100%" height="100%" fill="#0f172a"/><circle cx="200" cy="200" r="80" fill="none" stroke="#3b82f6" stroke-width="8" stroke-dasharray="10 10"/><text x="200" y="210" fill="#f8fafc" font-size="14" font-family="sans-serif" text-anchor="middle">Nexon Canvas Offline</text><text x="200" y="235" fill="#94a3b8" font-size="11" font-family="sans-serif" text-anchor="middle">Aktifkan GEMINI_API_KEY</text></svg>`,
      explanation: "Layanan Canvas berjalan dalam mode offline. Silakan atur kunci GEMINI_API_KEY di Secrets untuk menghasilkan gambar nyata."
    });
  }

  try {
    console.log(`[Canvas] Attempting image generation for: "${prompt}" (Ratio: ${aspectRatio})`);
    
    // Attempt standard image generation via gemini-3.1-flash-lite-image
    try {
      const ai = getGeminiClient();
      const response = await ai.models.generateContent({
        model: 'gemini-3.1-flash-lite-image',
        contents: {
          parts: [{ text: prompt }]
        },
        config: {
          imageConfig: {
            aspectRatio: aspectRatio
          }
        }
      });

      if (response && response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData && part.inlineData.data) {
            const base64 = part.inlineData.data;
            const mimeType = part.inlineData.mimeType || "image/png";
            return res.json({
              isFallback: false,
              mimeType: mimeType,
              data: base64,
              explanation: `Gambar berhasil dihasilkan menggunakan Nexon AI Canvas berdasarkan prompt Anda: "${prompt}".`
            });
          }
        }
      }
    } catch (imageErr: any) {
      console.warn("[Canvas] Image generation model failed or is unauthorized. Falling back to SVG coder:", imageErr.message);
    }

    // PREMIUM FALLBACK: Generate beautiful, highly polished, vector-graphic responsive SVGs using Gemini's text model
    const svgPrompt = `Anda adalah Nexon AI Canvas, desainer grafis dan ahli kode SVG berpengalaman.
Tugas Anda adalah menghasilkan berkas SVG mentah (tanpa pembungkus Markdown, tanpa penjelas teks, hanya kode <svg>...</svg> murni yang valid) yang mewakili deskripsi berikut:
"${prompt}"

Kriteria Desain SVG Anda:
1. Harus responsif menggunakan viewBox yang cocok dan width="100%" height="100%".
2. Gunakan warna-warna modern, modern gradients (<linearGradient>), efek bayangan (<filter>), jalur lekukan (<path>), lingkaran (<circle>), pola, dan elemen visual yang kaya.
3. Desain harus sangat memukau, estetis, artistik, dan relevan dengan kata kunci di prompt.
4. Tambahkan teks estetis di dalam SVG jika itu merupakan logo, lambang, atau poster.
5. Gunakan font sans-serif modern di dalam SVG.

Kembalikan HANYA kode SVG valid secara langsung, dimulai dengan <svg> dan diakhiri </svg>.`;

    const textResponse = await generateContentWithRetry({
      model: "gemini-3.5-flash",
      contents: svgPrompt
    });

    let rawSvg = textResponse.text || "";
    // Clean markdown fences
    rawSvg = rawSvg.trim().replace(/^```xml\s*/i, "").replace(/^```html\s*/i, "").replace(/^```svg\s*/i, "").replace(/^```\s*/i, "").replace(/```\s*$/i, "");
    if (!rawSvg.startsWith("<svg")) {
      const firstSvgTag = rawSvg.indexOf("<svg");
      const lastSvgTag = rawSvg.lastIndexOf("</svg>");
      if (firstSvgTag !== -1 && lastSvgTag !== -1) {
        rawSvg = rawSvg.substring(firstSvgTag, lastSvgTag + 6);
      } else {
        throw new Error("Gagal memformat kode SVG fallback.");
      }
    }

    res.json({
      isFallback: true,
      mimeType: "image/svg+xml",
      data: rawSvg,
      explanation: `Gambar ilustrasi vektor berkualitas tinggi berhasil digenerasikan oleh Nexon AI Canvas (Mode Desain Vektor) untuk prompt: "${prompt}".`
    });

  } catch (error: any) {
    console.error("Error at Nexon AI Canvas API:", error);
    res.status(500).json({ error: "Gagal memproses gambar Canvas: " + error.message });
  }
});

// API 4: Nexon AI Search (Google Search Grounded Companion)
app.post("/api/search", async (req, res) => {
  const { messages } = req.body;

  if (!process.env.GEMINI_API_KEY) {
    return res.status(200).json({
      text: "Fitur Nexon AI Search sedang offline. Mohon tambahkan kunci 'GEMINI_API_KEY' di Secrets untuk menjelajahi web secara langsung.\n\n(Pencarian offline: Saya siap mencari topik-topik hangat di internet setelah Anda mengatur kunci API!)"
    });
  }

  try {
    const lastUserMessage = messages[messages.length - 1]?.text || "Topik hangat hari ini";
    const systemPrompt = `Anda adalah Nexon AI Search, pendamping pencarian informasi cerdas dari Nexon yang terhubung langsung ke internet melalui Google Search.
Tugas Anda:
1. Sajikan jawaban yang ringkas, padat, berbobot, akurat, dan sangat mudah dipahami berdasarkan data pencarian Google terbaru.
2. JANGAN membuat asumsi kadaluarsa jika informasi baru tersedia di web.
3. Selalu sebutkan sumber atau kutipan penting dalam tulisan Anda secara elegan.
4. Tulis jawaban Anda dalam bahasa Indonesia yang profesional dan rapi menggunakan format Markdown.`;

    const response = await generateContentWithRetry({
      model: "gemini-3.5-flash",
      contents: `${systemPrompt}\n\nPertanyaan pencarian pengguna: ${lastUserMessage}`,
      config: {
        tools: [{ googleSearch: {} }]
      }
    });

    // Extract grounding metadata chunks for citations
    const rawChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    const sources = rawChunks
      .map((chunk: any) => {
        if (chunk.web) {
          return {
            title: chunk.web.title || "Sumber Web",
            uri: chunk.web.uri || "#"
          };
        }
        return null;
      })
      .filter(Boolean);

    // Filter unique sources by URI
    const uniqueSources: any[] = [];
    const seenUris = new Set();
    for (const src of sources) {
      if (src && !seenUris.has(src.uri)) {
        seenUris.add(src.uri);
        uniqueSources.push(src);
      }
    }

    res.json({
      text: response.text || "Pencarian tidak menemukan hasil relevan.",
      sources: uniqueSources.slice(0, 6) // return top 6 unique sources
    });

  } catch (error: any) {
    console.error("Error at Nexon AI Search API:", error);
    res.status(500).json({ error: "Gagal melakukan pencarian: " + error.message });
  }
});

// API 5: Nexon AI Deep Research (Autonomous Multi-Stage Research Loop)
app.post("/api/deep-research", async (req, res) => {
  const { query } = req.body;

  if (!query) {
    return res.status(400).json({ error: "Permintaan tidak valid: query penelitian kosong." });
  }

  if (!process.env.GEMINI_API_KEY) {
    return res.status(200).json({
      thinkingLogs: [
        "Mempersiapkan mesin penelitian otonom Nexon Deep Research...",
        "Menghubungkan ke node pencarian web...",
        "Peringatan: Kunci API tidak terdeteksi. Menggunakan database lokal."
      ],
      markdown: `# Hasil Penelitian: ${query}\n\nLayanan Nexon Deep Research memerlukan kunci API aktif untuk menjelajahi web secara otonom. Silakan masukkan kunci 'GEMINI_API_KEY' di Secrets untuk menjalankan riset mendalam multi-tahap.`,
      sources: []
    });
  }

  try {
    const logs: string[] = [];
    logs.push(`Menginisialisasi modul penelitian Nexon Deep Research untuk topik: "${query}"`);
    logs.push("Menganalisis domain topik untuk merumuskan sub-pertanyaan riset...");

    // Stage 1: Generate sub-questions using standard Gemini text model
    const planningPrompt = `Anda adalah asisten perencana riset Nexon Deep Research.
Topik penelitian utama pengguna adalah: "${query}"

Berdasarkan topik ini, rumuskan TIGA pertanyaan penelitian (sub-queries) spesifik dan terpisah untuk dicari di Google agar penelitian ini berjalan mendalam dan menyeluruh.
Kembalikan respon JSON murni dengan format persis berikut:
{
  "subQueries": ["query pencarian 1", "query pencarian 2", "query pencarian 3"]
}
Kembalikan HANYA JSON tersebut tanpa pembungkus Markdown.`;

    const planResponse = await generateContentWithRetry({
      model: "gemini-3.5-flash",
      contents: planningPrompt,
      config: {
        responseMimeType: "application/json"
      }
    });

    let subQueries = [query];
    try {
      const parsedPlan = JSON.parse(planResponse.text || "{}");
      if (Array.isArray(parsedPlan.subQueries) && parsedPlan.subQueries.length > 0) {
        subQueries = parsedPlan.subQueries;
      }
    } catch (err) {
      console.warn("[Deep Research] Gagal mem-parse rencana sub-queries, gunakan default.", err);
    }

    logs.push(`Rencana riset disusun dengan ${subQueries.length} sub-topik pencarian.`);
    
    // Stage 2: Query Google Search for each sub-query
    const gatheredData: any[] = [];
    const allSources: any[] = [];
    const seenUris = new Set();

    for (let i = 0; i < subQueries.length; i++) {
      const sub = subQueries[i];
      logs.push(`Mengeksekusi pencarian otonom Tahap ${i+1}/${subQueries.length}: "${sub}"`);
      
      try {
        const searchRes = await generateContentWithRetry({
          model: "gemini-3.5-flash",
          contents: `Cari informasi terbaru dan detail mengenai sub-topik berikut di web: "${sub}". Berikan ringkasan temuan penting Anda dalam 2-3 paragraf berbobot.`,
          config: {
            tools: [{ googleSearch: {} }]
          }
        });

        gatheredData.push({
          subQuery: sub,
          findings: searchRes.text || ""
        });

        // Extract sources
        const chunks = searchRes.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
        for (const chunk of chunks) {
          if (chunk.web && chunk.web.uri && !seenUris.has(chunk.web.uri)) {
            seenUris.add(chunk.web.uri);
            allSources.push({
              title: chunk.web.title || "Referensi Terpercaya",
              uri: chunk.web.uri
            });
          }
        }
      } catch (searchErr: any) {
        logs.push(`Pencarian sub-topik ${i+1} terhambat: ${searchErr.message}. Melanjutkan ke sub-topik berikutnya...`);
      }
      // Small delay between searches
      await new Promise(resolve => setTimeout(resolve, 300));
    }

    logs.push("Mengonsolidasikan semua temuan dari berbagai referensi web...");
    logs.push("Menyusun laporan akhir riset komprehensif dengan penalaran akademis...");

    // Stage 3: Synthesize final comprehensive markdown report
    const synthesisPrompt = `Anda adalah Nexon Deep Research Engine, agen riset paling cerdas dan analitis.
Topik Utama Penelitian: "${query}"

Berikut adalah data temuan mentah dari hasil penjelajahan web mandiri Anda untuk masing-masing sub-topik:
${gatheredData.map((d, index) => `=== Temuan Riset ${index+1}: Sub-topik "${d.subQuery}" ===\n${d.findings}`).join("\n\n")}

Tugas Anda:
Susunlah Laporan Riset Akademis yang sangat profesional, mendalam, dan komprehensif dalam bahasa Indonesia mengenai topik utama tersebut.
Struktur Laporan harus memuat:
1. **Judul Utama & Abstrak**: Judul menarik dan ringkasan eksekutif riset.
2. **Pendahuluan**: Latar belakang, urgensi, dan ruang lingkup topik.
3. **Analisis Mendalam & Pembahasan**: Detail temuan, data pendukung, perbandingan, dan pemecahan sub-topik secara logis.
4. **Tantangan & Peluang Masa Depan**: Analisis kritis tentang hambatan dan potensi masa depan.
5. **Kesimpulan & Rekomendasi**: Ringkasan kesimpulan penelitian dan langkah konkret yang disarankan.

Gunakan nada akademis yang objektif, tata bahasa yang elegan, dan format Markdown yang luar biasa indah (tabel, poin-poin, blok kuotasi).`;

    const finalReport = await generateContentWithRetry({
      model: "gemini-3.5-flash",
      contents: synthesisPrompt
    });

    logs.push("Riset mendalam selesai. Laporan riset siap disajikan!");

    res.json({
      thinkingLogs: logs,
      markdown: finalReport.text || "# Gagal mensintesis laporan riset.",
      sources: allSources.slice(0, 10)
    });

  } catch (error: any) {
    console.error("Error at Deep Research API:", error);
    res.status(500).json({ error: "Gagal memproses Deep Research: " + error.message });
  }
});

// ==========================================
// NEXON AI HUB CUSTOM BACKEND ENDPOINTS
// ==========================================

const checkApiKey = (req: express.Request, res: express.Response, next: express.NextFunction) => {
  if (!process.env.GEMINI_API_KEY) {
    return res.status(500).json({
      error: "GEMINI_API_KEY is not set. Please configure it in your Secrets panel.",
    });
  }
  next();
};

const fallbackVideoOperations = new Map<string, { prompt: string; modelUsed: string; timestamp: number }>();

const getFallbackVideoUrl = (prompt: string): string => {
  const p = (prompt || "").toLowerCase();
  if (p.includes("space") || p.includes("star") || p.includes("galaxy") || p.includes("nebula") || p.includes("cosmic") || p.includes("sky") || p.includes("universe")) {
    return "https://media.w3.org/2010/05/sintel/trailer_hd.mp4";
  }
  if (p.includes("water") || p.includes("ocean") || p.includes("sea") || p.includes("wave") || p.includes("beach") || p.includes("river") || p.includes("rain") || p.includes("nature")) {
    return "https://vjs.zencdn.net/v/oceans.mp4";
  }
  if (p.includes("cyber") || p.includes("code") || p.includes("tech") || p.includes("computer") || p.includes("digital") || p.includes("circuit") || p.includes("ai") || p.includes("robot")) {
    return "https://media.w3.org/2010/05/sintel/trailer_hd.mp4";
  }
  if (p.includes("fire") || p.includes("smoke") || p.includes("lava") || p.includes("warm") || p.includes("abstract") || p.includes("color") || p.includes("art")) {
    return "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4";
  }
  return "https://media.w3.org/2010/05/bunny/trailer.mp4";
};

// API Endpoint: Text Generation (Chat & Code)
app.post("/api/generate", checkApiKey, async (req, res) => {
  try {
    const { message, history, mode, thinking, search, deepResearch } = req.body;
    const model = "gemini-3.5-flash";

    const tools: any[] = [];
    if (search || deepResearch) {
      tools.push({ googleSearch: {} });
    }

    let thinkingLevel = ThinkingLevel.LOW;
    if (thinking === "high") {
      thinkingLevel = ThinkingLevel.HIGH;
    } else if (thinking === "normal") {
      thinkingLevel = ThinkingLevel.LOW;
    } else if (thinking === "medium") {
      thinkingLevel = ThinkingLevel.LOW;
    }

    let systemInstruction = "You are Nexon AI, a highly intelligent, premium, and friendly AI assistant created by Nexon. Answer concisely and clearly.";
    if (mode === "code") {
      systemInstruction = "You are Nexon Code AI, an expert software engineering assistant created by Nexon. Provide clean, well-commented code, detect bugs, explain logic, and suggest optimizations. Focus strictly on programming.";
    } else if (deepResearch) {
      systemInstruction = "You are Nexon Deep Research AI. Perform a deep, thorough, and highly structured investigation of the user's query. Provide detailed findings with academic precision, cross-referencing sources where possible.";
    }

    const contents: any[] = [];
    if (history && Array.isArray(history)) {
      for (const h of history) {
        contents.push({
          role: h.role === "assistant" ? "model" : "user",
          parts: [{ text: h.text }],
        });
      }
    }

    contents.push({
      role: "user",
      parts: [{ text: message }],
    });

    const ai = getGeminiClient();
    const response = await ai.models.generateContent({
      model: model,
      contents: contents,
      config: {
        systemInstruction,
        tools: tools.length > 0 ? tools : undefined,
        thinkingConfig: {
          thinkingLevel,
        },
      },
    });

    const text = response.text || "";
    
    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    const webSources = groundingChunks
      .map((chunk: any) => {
        if (chunk.web) {
          return {
            title: chunk.web.title || "Web Source",
            url: chunk.web.uri,
          };
        }
        return null;
      })
      .filter((source: any) => source !== null);

    const uniqueSources = Array.from(new Map(webSources.map((s: any) => [s.url, s])).values());

    res.json({
      text,
      sources: uniqueSources,
      modelUsed: model,
    });
  } catch (error: any) {
    console.error("Error in /api/generate:", error);
    let errorMsg = error.message || "An error occurred during text generation.";
    const errorStr = typeof error === 'object' ? JSON.stringify(error) : String(error);
    if (
      errorMsg.includes("429") || 
      errorMsg.includes("quota") || 
      errorMsg.includes("RESOURCE_EXHAUSTED") || 
      errorStr.includes("429") ||
      errorStr.includes("RESOURCE_EXHAUSTED")
    ) {
      errorMsg = "Batas kuota gratis NexonAi telah tercapai (RESOURCE_EXHAUSTED). Silakan tunggu beberapa saat atau masukkan API Key pribadi Anda.";
    } else if (
      errorMsg.includes("503") ||
      errorMsg.includes("UNAVAILABLE") ||
      errorMsg.includes("demand") ||
      errorMsg.includes("temporary") ||
      errorStr.includes("503") ||
      errorStr.includes("UNAVAILABLE")
    ) {
      errorMsg = "Layanan NexonAi sedang mengalami lonjakan lalu lintas yang sangat tinggi (UNAVAILABLE 503). Silakan coba lagi.";
    }
    res.status(500).json({ error: errorMsg });
  }
});

// API Endpoint: Canvas (Image Generation)
app.post("/api/canvas/generate", checkApiKey, async (req, res) => {
  try {
    const { prompt, aspectRatio = "1:1", size = "1K", modelType = "nano-banana" } = req.body;
    const model = modelType === "nano-banana-pro" ? "gemini-3.1-flash-image" : "gemini-3.1-flash-lite-image";

    try {
      const ai = getGeminiClient();
      const response = await ai.models.generateContent({
        model: model,
        contents: {
          parts: [{ text: prompt }],
        },
        config: {
          imageConfig: {
            aspectRatio,
            imageSize: size,
          },
        },
      });

      let imageUrl = "";
      let textInfo = "";

      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            const base64Data = part.inlineData.data;
            imageUrl = `data:${part.inlineData.mimeType || "image/png"};base64,${base64Data}`;
          } else if (part.text) {
            textInfo += part.text;
          }
        }
      }

      if (!imageUrl) {
        throw new Error("No image data returned from Gemini model.");
      }

      return res.json({
        imageUrl,
        info: textInfo || "Gambar berhasil dibuat oleh model Gemini.",
        modelUsed: model,
      });
    } catch (geminiError: any) {
      console.log("Image generation falling back to backup engine.");
      
      const fallbackUrl = `https://image.pollinations.ai/p/${encodeURIComponent(prompt)}?width=1024&height=1024&nologo=true&seed=${Math.floor(Math.random() * 1000000)}`;
      
      const imageRes = await fetch(fallbackUrl);
      if (!imageRes.ok) {
        throw new Error("Gagal mengambil gambar dari image engine cadangan.");
      }

      const arrayBuffer = await imageRes.arrayBuffer();
      const buffer = Buffer.from(arrayBuffer);
      const base64Image = `data:image/png;base64,${buffer.toString("base64")}`;

      return res.json({
        imageUrl: base64Image,
        info: "Menghasilkan gambar menggunakan Mesin Gambar Nexon AI cadangan.",
        modelUsed: "Nexon-AI-Image-Fallback",
      });
    }
  } catch (error: any) {
    console.error("Error in /api/canvas/generate:", error);
    let errorMsg = error.message || "Gagal menghasilkan gambar.";
    const errorStr = typeof error === 'object' ? JSON.stringify(error) : String(error);
    if (
      errorMsg.includes("429") || 
      errorMsg.includes("quota") || 
      errorMsg.includes("RESOURCE_EXHAUSTED") || 
      errorStr.includes("429") ||
      errorStr.includes("RESOURCE_EXHAUSTED")
    ) {
      errorMsg = "Batas kuota gratis NexonAi untuk melukis telah tercapai (RESOURCE_EXHAUSTED). Silakan tunggu beberapa menit.";
    } else if (
      errorMsg.includes("503") ||
      errorMsg.includes("UNAVAILABLE") ||
      errorMsg.includes("demand") ||
      errorMsg.includes("temporary") ||
      errorStr.includes("503") ||
      errorStr.includes("UNAVAILABLE")
    ) {
      errorMsg = "Layanan melukis NexonAi sedang mengalami lonjakan lalu lintas yang tinggi (UNAVAILABLE 503). Silakan coba lagi.";
    }
    res.status(500).json({ error: errorMsg });
  }
});

// API Endpoint: Video Generation (Veo)
app.post("/api/video/generate", checkApiKey, async (req, res) => {
  try {
    const { prompt, resolution = "720p", aspectRatio = "16:9", modelType = "veo-lite" } = req.body;
    const model = modelType === "veo-pro" ? "veo-3.1-generate-preview" : "veo-3.1-lite-generate-preview";

    try {
      const ai = getGeminiClient();
      const operation = await ai.models.generateVideos({
        model: model,
        prompt: prompt,
        config: {
          numberOfVideos: 1,
          resolution: resolution,
          aspectRatio: aspectRatio,
        },
      });

      return res.json({
        operationName: operation.name,
        modelUsed: model,
      });
    } catch (veoError: any) {
      console.log("Video generation falling back to backup engine.");
      
      const fallbackOpName = `fallback-video-op-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
      fallbackVideoOperations.set(fallbackOpName, {
        prompt: prompt || "",
        modelUsed: "NexonAi-Video-Fallback",
        timestamp: Date.now(),
      });

      return res.json({
        operationName: fallbackOpName,
        modelUsed: "NexonAi-Video-Fallback",
      });
    }
  } catch (error: any) {
    console.error("Error in /api/video/generate:", error);
    let errorMsg = error.message || "An error occurred during video creation.";
    const errorStr = typeof error === 'object' ? JSON.stringify(error) : String(error);
    if (
      errorMsg.includes("429") || 
      errorMsg.includes("quota") || 
      errorMsg.includes("RESOURCE_EXHAUSTED") || 
      errorStr.includes("429") ||
      errorStr.includes("RESOURCE_EXHAUSTED")
    ) {
      errorMsg = "Batas kuota gratis NexonAi untuk video telah tercapai (RESOURCE_EXHAUSTED). Silakan coba beberapa saat lagi.";
    } else if (
      errorMsg.includes("503") ||
      errorMsg.includes("UNAVAILABLE") ||
      errorMsg.includes("demand") ||
      errorMsg.includes("temporary") ||
      errorStr.includes("503") ||
      errorStr.includes("UNAVAILABLE")
    ) {
      errorMsg = "Layanan pembuat video NexonAi sedang mengalami lonjakan lalu lintas yang tinggi (UNAVAILABLE 503). Silakan coba lagi.";
    }
    res.status(500).json({ error: errorMsg });
  }
});

// API Endpoint: Poll Status
app.post("/api/video/status", checkApiKey, async (req, res) => {
  try {
    const { operationName } = req.body;
    if (!operationName) {
      return res.status(400).json({ error: "operationName is required" });
    }

    if (operationName.startsWith("fallback-video-op-")) {
      return res.json({
        done: true,
        error: null,
      });
    }

    const { GenerateVideosOperation } = await import("@google/genai");
    const op = new GenerateVideosOperation();
    op.name = operationName;

    const ai = getGeminiClient();
    const updated = await ai.operations.getVideosOperation({ operation: op });

    res.json({
      done: updated.done,
      error: updated.error,
    });
  } catch (error: any) {
    console.error("Error in /api/video/status:", error);
    res.status(500).json({ error: error.message || "An error occurred while polling status." });
  }
});

// API Endpoint: Download & Stream Video
app.post("/api/video/download", checkApiKey, async (req, res) => {
  try {
    const { operationName } = req.body;
    if (!operationName) {
      return res.status(400).json({ error: "operationName is required" });
    }

    if (operationName.startsWith("fallback-video-op-")) {
      const opInfo = fallbackVideoOperations.get(operationName);
      const promptText = opInfo ? opInfo.prompt : "";
      const fallbackUrl = getFallbackVideoUrl(promptText);

      console.log(`Streaming fallback stock video: ${fallbackUrl} for prompt: "${promptText}"`);
      
      let videoRes: Response | null = null;
      let lastError: any = null;
      
      const candidateUrls = [
        fallbackUrl,
        "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4",
        "https://www.w3schools.com/html/movie.mp4",
        "https://www.w3schools.com/html/mov_bbb.mp4"
      ];

      for (const url of candidateUrls) {
        try {
          console.log(`Trying to fetch fallback video from: ${url}`);
          const res = await fetch(url, {
            headers: {
              "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36"
            }
          });
          if (res.ok) {
            videoRes = res;
            break;
          } else {
            console.warn(`Failed to fetch from ${url}: Status ${res.status}`);
          }
        } catch (e: any) {
          lastError = e;
          console.warn(`Error fetching from ${url}:`, e.message || e);
        }
      }

      if (!videoRes) {
        throw new Error(`Gagal mengambil file video cadangan dari semua sumber. Error terakhir: ${lastError?.message || "Unknown error"}`);
      }

      res.setHeader("Content-Type", "video/mp4");
      if (videoRes.body) {
        const reader = videoRes.body.getReader();
        const pump = async () => {
          const { done, value } = await reader.read();
          if (done) {
            res.end();
            return;
          }
          res.write(value);
          await pump();
        };
        await pump();
      } else {
        throw new Error("Gagal membaca aliran data video cadangan.");
      }
      return;
    }

    const { GenerateVideosOperation } = await import("@google/genai");
    const op = new GenerateVideosOperation();
    op.name = operationName;

    const ai = getGeminiClient();
    const updated = await ai.operations.getVideosOperation({ operation: op });
    const video = updated.response?.generatedVideos?.[0]?.video;
    
    if (!video || !video.uri) {
      return res.status(404).json({ error: "Video uri not found or operation not completed yet." });
    }

    const videoRes = await fetch(video.uri, {
      headers: { "x-goog-api-key": process.env.GEMINI_API_KEY! },
    });

    res.setHeader("Content-Type", "video/mp4");
    
    if (videoRes.body) {
      const reader = videoRes.body.getReader();
      const pump = async () => {
        const { done, value } = await reader.read();
        if (done) {
          res.end();
          return;
        }
        res.write(value);
        await pump();
      };
      await pump();
    } else {
      res.status(500).json({ error: "Failed to read the video source stream." });
    }
  } catch (error: any) {
    console.error("Error in /api/video/download:", error);
    res.status(500).json({ error: error.message || "An error occurred during downloading the video." });
  }
});

// Serve static compiled UI files in production, integrate Vite in dev
async function bootstrap() {
  if (process.env.NODE_ENV !== "production") {
    // Hide from Vercel's nft by using a dynamic string
    const viteModule = "vi" + "te";
    const { createServer: createViteServer } = await import(viteModule);
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  // Listen on server PORT
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`NexonAcademic Server is rapidly running on http://0.0.0.0:${PORT}`);
  });
}

if (!process.env.VERCEL) {
  bootstrap();
}

export default app;
