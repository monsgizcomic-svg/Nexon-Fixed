export interface Message {
  id: string;
  sender: "user" | "ai";
  text: string;
  timestamp: string;
  fileName?: string;
  fileType?: string;
}

// Used by NexonCode's chat history: each AI turn is a generated code block
// plus an explanation, instead of plain prose text.
export interface CodeMessage extends Message {
  code?: string;
  language?: string;
  explanation?: string;
}

export interface Reminder {
  id: string;
  title: string;
  time: string; // "HH:MM" 24h
  days: string[]; // e.g., ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"] or date string
  active: boolean;
  notes?: string;
  triggeredToday?: boolean;
}

export interface ElementInfo {
  number: number;
  symbol: string;
  name: string;
  mass: number;
  category: "alkali" | "alkaline-earth" | "transition" | "post-transition" | "metalloid" | "nonmetal" | "halogen" | "noble" | "lanthanide" | "actinide";
  period: number;
  group: number;
  row: number;
  col: number; // grid columns 1-18
  phase?: "gas" | "liquid" | "solid" | "synthetic";
  density?: string;
  discoverer?: string;
  summary: string;
}

export type UserRole = "student" | "teacher";

export interface AcademicUser {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  school: string;
  grade?: string;
  nisn?: string;
  nip?: string;
  subject?: string;
}

export interface AcademicAnnouncement {
  id: string;
  title: string;
  content: string;
  authorName: string;
  timestamp: string;
  vibrate?: boolean;
}

