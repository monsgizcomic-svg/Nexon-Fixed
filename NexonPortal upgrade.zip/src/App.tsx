import { useState, useEffect } from "react";
import { 
  Bell, 
  X, 
  LogOut, 
  User, 
  Settings, 
  BookOpen, 
  Sparkles, 
  Heart, 
  Code2, 
  FlaskConical, 
  Menu, 
  Clock, 
  Activity, 
  GraduationCap,
  ShieldAlert,
  FolderHeart
} from "lucide-react";
import { auth, db } from "./lib/firebase";
import { onAuthStateChanged, signOut, User as FirebaseUser } from "firebase/auth";
import { doc, getDoc, setDoc } from "firebase/firestore";

import FirebaseAuth from "./components/FirebaseAuth";
import DianaChat from "./components/DianaChat";
import LianaCounsel from "./components/LianaCounsel";
import NexonCodeStudio from "./components/NexonCodeStudio";
import NexonLabSandbox from "./components/NexonLabSandbox";
import SmartReminder from "./components/SmartReminder";
import NexonShelf from "./components/NexonShelf";
import UserProfileEditor from "./components/UserProfileEditor";
import NexonAIHub from "./components/NexonAIHub";

interface ToastNotification {
  id: string;
  title: string;
  msg: string;
  timestamp: string;
}

type ActiveTab = "diana" | "liana" | "nexoncode" | "nexonlab" | "reminders" | "nexonai";

export default function App() {
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [isAuthChecking, setIsAuthChecking] = useState(true);
  
  // User profile state loaded from Firestore
  interface UserProfileType {
    name: string;
    role: string;
    grade: string;
    school: string;
    nexonAiUrl?: string;
  }

  const [userProfile, setUserProfile] = useState<UserProfileType>({
    name: "User Nexon",
    role: "Member",
    grade: "Member",
    school: "-",
    nexonAiUrl: ""
  });

  // Navigation states
  const [activeTab, setActiveTab] = useState<ActiveTab>("diana");
  const [viewingShelf, setViewingShelf] = useState(false);
  const [isProfileEditing, setIsProfileEditing] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Global toast system
  const [toasts, setToasts] = useState<ToastNotification[]>([]);

  // Prevent compositor issues on background tab suspension
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden) {
        document.body.classList.add("app-bg-paused");
      } else {
        document.body.classList.remove("app-bg-paused");
      }
    };
    document.addEventListener("visibilitychange", handleVisibilityChange);
    return () => document.removeEventListener("visibilitychange", handleVisibilityChange);
  }, []);

  const handleAddToast = (title: string, msg: string) => {
    const freshToast: ToastNotification = {
      id: "toast-" + Date.now(),
      title,
      msg,
      timestamp: new Date().toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" })
    };
    
    setToasts(prev => [freshToast, ...prev].slice(0, 5));

    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== freshToast.id));
    }, 6000);
  };

  // Auth synchronization & Firestore profile loading
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        try {
          const docRef = doc(db, "users", user.uid);
          const docSnap = await getDoc(docRef);
          if (docSnap && docSnap.exists()) {
            const data = docSnap.data();
            setUserProfile({
              name: data.name || user.displayName || user.email?.split("@")[0] || "User Nexon",
              role: data.role || "Member",
              grade: data.grade || "Member",
              school: data.school || "-",
              nexonAiUrl: data.nexonAiUrl || ""
            });
          } else {
            const defaultName = user.displayName || user.email?.split("@")[0] || "User Nexon";
            await setDoc(docRef, {
              name: defaultName,
              role: "Member",
              grade: "Member",
              school: "-",
              nexonAiUrl: ""
            });
            setUserProfile({
              name: defaultName,
              role: "Member",
              grade: "Member",
              school: "-",
              nexonAiUrl: ""
            });
          }
        } catch (err) {
          console.warn("Profil tidak dapat dimuat, menggunakan profil default:", err);
          const defaultName = user.displayName || user.email?.split("@")[0] || "User Nexon";
          setUserProfile({
            name: defaultName,
            role: "Member",
            grade: "Member",
            school: "-",
            nexonAiUrl: ""
          });
        }
        handleAddToast("Portal Terbuka 🎓", "Selamat datang kembali di NexonPortal, lingkungan akademik cerdas Anda!");
      } else {
        setUserProfile({
          name: "Guest",
          role: "Member",
          grade: "Member",
          school: "-",
          nexonAiUrl: ""
        });
      }
      setIsAuthChecking(false);
    });

    return () => unsubscribe();
  }, []);

  const handleLogout = async () => {
    try {
      await signOut(auth);
      setViewingShelf(false);
      handleAddToast("Log Out Berhasil 🔒", "Sesi Anda telah ditutup dengan aman dari NexonPortal.");
    } catch (err: any) {
      console.error(err);
      handleAddToast("Logout Gagal", err.message);
    }
  };

  if (isAuthChecking) {
    return (
      <div className="min-h-screen bg-[#070709] text-white/95 flex flex-col items-center justify-center font-sans">
        <div className="w-10 h-10 border-4 border-indigo-500/10 border-t-indigo-500 rounded-full animate-spin mb-4"></div>
        <p className="text-[10px] text-white/40 tracking-widest font-mono uppercase animate-pulse">[ MEMPERSIAPKAN NEXON PORTAL... ]</p>
      </div>
    );
  }

  // Not Authenticated Layout
  if (!currentUser) {
    return (
      <div className="min-h-screen bg-[#070709] text-white/90 flex flex-col font-sans relative overflow-hidden" id="nexon_login_hub">
        
        {/* Ambient background glows */}
        <div className="absolute top-0 left-1/4 w-[40rem] h-[40rem] bg-indigo-600/[0.04] rounded-full blur-[100px] pointer-events-none -z-10"></div>
        <div className="absolute bottom-0 right-1/4 w-[30rem] h-[30rem] bg-purple-600/[0.02] rounded-full blur-[80px] pointer-events-none -z-10"></div>

        {/* Global Header */}
        <header className="bg-[#0c0c0f]/80 backdrop-blur-md border-b border-white/[0.05] h-16 flex items-center justify-between px-4 sm:px-6 sticky top-0 z-40">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-indigo-600 to-indigo-500 flex items-center justify-center text-white font-extrabold text-sm shadow-md">
              NP
            </div>
            <span className="font-extrabold tracking-widest text-white/90 text-sm font-mono">
              NEXONPORTAL
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 inline-block animate-pulse"></span>
            <span className="text-[10px] text-white/50 font-mono uppercase tracking-wider">Akses Terkunci</span>
          </div>
        </header>

        {/* Main login Area */}
        <main className="flex-1 max-w-lg w-full mx-auto px-4 py-12 flex flex-col justify-center items-center">
          
          <div className="text-center space-y-3 mb-8 w-full">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold font-mono bg-indigo-500/10 text-indigo-400 border border-indigo-500/10 uppercase tracking-wider">
              Lingkungan Akademik Cerdas
            </span>
            <h1 className="text-3xl font-extrabold text-white tracking-tight leading-tight">
              Selamat Datang di <span className="text-indigo-400 font-display">NexonPortal</span>
            </h1>
            <p className="text-white/50 text-xs leading-relaxed max-w-sm mx-auto">
              Satu portal terpadu untuk asisten Diana AI, bimbingan BK Liana, NexonCode, visualisasi kimia NexonLab, dan manajemen pengingat cerdas.
            </p>
          </div>

          <div className="w-full bg-[#0c0c0f] border border-white/[0.06] p-6 rounded-2xl shadow-xl">
            <FirebaseAuth onAddNotification={handleAddToast} />
          </div>

        </main>

        <footer className="h-14 border-t border-white/[0.05] flex items-center justify-center px-4 bg-[#0a0a0d] text-[9px] text-white/30 font-mono tracking-widest uppercase">
          NexonPortal &copy; 2026 &bull; Secured with Firebase
        </footer>

        {/* Floating Toast Notification Popups */}
        <div className="fixed top-3 left-3 right-3 sm:top-auto sm:left-auto sm:bottom-4 sm:right-4 z-50 space-y-2 sm:max-w-sm sm:w-full font-sans pointer-events-none">
          {toasts.map((toast) => (
            <div
              key={toast.id}
              className="p-3.5 bg-[#0c0c0f] border border-white/[0.1] text-white rounded-2xl shadow-xl flex items-start gap-3 border-l-4 border-l-indigo-500 pointer-events-auto"
            >
              <div className="p-1.5 bg-indigo-500/10 rounded-lg text-indigo-300 shrink-0 mt-0.5">
                <Bell className="w-4 h-4" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-1">
                  <span className="font-bold text-xs text-white truncate">{toast.title}</span>
                  <span className="text-[9px] text-white/35 font-mono shrink-0">{toast.timestamp}</span>
                </div>
                <p className="text-[11px] text-white/60 leading-relaxed mt-1 whitespace-pre-line">{toast.msg}</p>
              </div>
              <button
                onClick={() => setToasts(prev => prev.filter(t => t.id !== toast.id))}
                className="p-1 text-white/30 hover:text-white rounded-full cursor-pointer transition-colors shrink-0"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>

      </div>
    );
  }

  // Loaded & Authenticated NexonShelf View (takes full-screen priority)
  if (viewingShelf) {
    return (
      <div className="w-full h-screen overflow-hidden bg-[#070709] text-white/90">
        <NexonShelf 
          userProfile={userProfile}
          onBackToPortal={() => {
            setViewingShelf(false);
            handleAddToast("Kembali ke Portal 🎓", "Menu utama portal akademik diaktifkan kembali.");
          }}
          onAddNotification={handleAddToast}
          currentUserId={currentUser.uid}
        />

        {/* Floating Toast Notification Popups */}
        <div className="fixed top-3 left-3 right-3 sm:top-auto sm:left-auto sm:bottom-4 sm:right-4 z-50 space-y-2 sm:max-w-sm sm:w-full font-sans pointer-events-none">
          {toasts.map((toast) => (
            <div
              key={toast.id}
              className="p-3.5 bg-[#0c0c0f] border border-white/[0.1] text-white rounded-2xl shadow-xl flex items-start gap-3 border-l-4 border-l-indigo-500 pointer-events-auto animate-slideIn"
            >
              <div className="p-1.5 bg-indigo-500/10 rounded-lg text-indigo-300 shrink-0 mt-0.5">
                <Bell className="w-4 h-4" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-1">
                  <span className="font-bold text-xs text-white truncate">{toast.title}</span>
                  <span className="text-[9px] text-white/35 font-mono shrink-0">{toast.timestamp}</span>
                </div>
                <p className="text-[11px] text-white/60 leading-relaxed mt-1 whitespace-pre-line">{toast.msg}</p>
              </div>
              <button
                onClick={() => setToasts(prev => prev.filter(t => t.id !== toast.id))}
                className="p-1 text-white/30 hover:text-white rounded-full cursor-pointer transition-colors shrink-0"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </div>
    );
  }

  const navItems = [
    { id: "diana", label: "Diana (Academic AI)", icon: GraduationCap, color: "text-indigo-400", desc: "Konsultasi materi, tugas & kuis" },
    { id: "liana", label: "Liana (Counseling BK)", icon: Heart, color: "text-rose-400", desc: "Ruang curhat aman & meditatif" },
    { id: "nexoncode", label: "NexonCode Studio", icon: Code2, color: "text-amber-400", desc: "Pembuat kode pemrograman AI" },
    { id: "nexonlab", label: "NexonLab Sandbox", icon: FlaskConical, color: "text-emerald-400", desc: "Eksplorasi tabel & reaksi kimia" },
    { id: "reminders", label: "Reminders & Alerts", icon: Bell, color: "text-blue-400", desc: "Pengingat jadwal & tugas mandiri" },
    { id: "nexonai", label: "Nexon AI Hub", icon: Sparkles, color: "text-purple-400", desc: "Kecerdasan Buatan Terpadu (Web)" }
  ];

  return (
    <div className="min-h-screen bg-[#070709] text-white/90 flex flex-col font-sans overflow-hidden h-screen relative">
      
      {/* Background visual accents */}
      <div className="absolute top-0 right-1/4 w-[35rem] h-[35rem] bg-indigo-600/[0.03] rounded-full blur-[120px] pointer-events-none -z-10"></div>
      
      {/* Upper bar */}
      <header className="bg-[#0c0c0f]/80 backdrop-blur-md border-b border-white/[0.05] h-16 flex items-center justify-between px-4 sm:px-6 shrink-0 z-40">
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} 
            className="p-2 hover:bg-white/[0.05] rounded-lg text-white/60 hover:text-white md:hidden transition-colors"
          >
            <Menu className="w-5 h-5" />
          </button>
          
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-indigo-600 flex items-center justify-center text-white font-extrabold text-sm shadow-md">
              N
            </div>
            <span className="font-extrabold tracking-widest text-white/90 text-xs sm:text-sm font-mono">
              NEXONPORTAL
            </span>
          </div>
        </div>

        {/* User profile widget & actions */}
        <div className="flex items-center gap-2 sm:gap-4">
          <div className="hidden sm:flex flex-col text-right">
            <span className="text-xs font-bold text-white/90 truncate max-w-[150px]">{userProfile.name}</span>
            <span className="text-[10px] text-white/40 font-mono tracking-wide truncate max-w-[150px]">
              {userProfile.role} &bull; {userProfile.school}
            </span>
          </div>

          <div className="flex items-center gap-1 bg-white/[0.02] border border-white/[0.05] p-1 rounded-xl">
            {/* NexonShelf Comic & PDF Launcher */}
            <button
              onClick={() => {
                setViewingShelf(true);
                handleAddToast("Membuka NexonShelf 📚", "Menghubungkan ke pustaka komik dan dokumen akademik.");
              }}
              title="Buka NexonShelf Library"
              className="p-2 hover:bg-white/[0.06] text-indigo-400 hover:text-indigo-300 rounded-lg transition-all cursor-pointer flex items-center gap-1.5"
            >
              <BookOpen className="w-4 h-4" />
              <span className="hidden lg:inline text-xs font-bold">NexonShelf</span>
            </button>

            {/* Profile configuration button */}
            <button
              onClick={() => setIsProfileEditing(true)}
              title="Atur Profil"
              className="p-2 hover:bg-white/[0.06] text-white/60 hover:text-white rounded-lg transition-colors cursor-pointer"
            >
              <Settings className="w-4 h-4" />
            </button>

            {/* Logout button */}
            <button
              onClick={handleLogout}
              title="Log Out"
              className="p-2 hover:bg-white/[0.06] text-rose-400/85 hover:text-rose-400 rounded-lg transition-colors cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Main dashboard body */}
      <div className="flex-1 flex overflow-hidden w-full relative">
        
        {/* Left Sidebar on Desktop */}
        <aside className="hidden md:flex flex-col w-72 bg-[#0a0a0d] border-r border-white/[0.05] shrink-0 p-4 justify-between overflow-y-auto">
          <div className="space-y-6">
            
            {/* Quick school card */}
            <div className="p-3.5 bg-white/[0.02] border border-white/[0.05] rounded-2xl">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-indigo-500/10 text-indigo-400 flex items-center justify-center shrink-0">
                  <User className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <div className="text-xs font-bold text-white/90 truncate">{userProfile.name}</div>
                  <div className="text-[10px] text-white/40 font-mono truncate">{userProfile.school}</div>
                </div>
              </div>
              <div className="mt-2.5 pt-2.5 border-t border-white/[0.04] flex items-center justify-between text-[10px]">
                <span className="text-white/40 font-mono">Kelas / Tingkat:</span>
                <span className="font-bold text-indigo-400 font-mono">{userProfile.grade}</span>
              </div>
            </div>

            {/* Sidebar Tab Selector */}
            <div className="space-y-1">
              <span className="text-[10px] text-white/30 font-mono uppercase tracking-widest pl-2 block mb-2">Workspace</span>
              {navItems.map((item) => {
                const IconComp = item.icon;
                const isSelected = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id as ActiveTab);
                      setIsMobileMenuOpen(false);
                    }}
                    className={`w-full text-left p-3 rounded-xl flex items-start gap-3 transition-all cursor-pointer group ${
                      isSelected 
                        ? "bg-indigo-600/15 border border-indigo-500/20 text-white" 
                        : "hover:bg-white/[0.03] border border-transparent text-white/60 hover:text-white"
                    }`}
                  >
                    <IconComp className={`w-4 h-4 mt-0.5 shrink-0 ${isSelected ? "text-indigo-400 animate-pulse" : "text-white/45 group-hover:text-white/85"}`} />
                    <div className="min-w-0">
                      <div className="text-xs font-bold leading-tight">{item.label}</div>
                      <div className="text-[10px] text-white/35 leading-tight mt-0.5 truncate">{item.desc}</div>
                    </div>
                  </button>
                );
              })}
            </div>

          </div>

          <div className="p-3 bg-white/[0.01] border border-white/[0.04] rounded-xl text-center">
            <span className="text-[9px] text-white/20 font-mono uppercase tracking-widest block">NexonPortal Ecosystem</span>
            <span className="text-[10px] text-white/40 font-mono block mt-1">2026 Academic Hub</span>
          </div>
        </aside>

        {/* Mobile menu modal backdrop */}
        {isMobileMenuOpen && (
          <div 
            className="fixed inset-0 bg-black/60 z-30 md:hidden backdrop-blur-xs"
            onClick={() => setIsMobileMenuOpen(false)}
          />
        )}

        {/* Mobile menu drawer */}
        <aside className={`fixed top-0 bottom-0 left-0 w-64 bg-[#0a0a0d] border-r border-white/[0.08] z-40 p-4 flex flex-col justify-between transform transition-transform duration-300 md:hidden ${isMobileMenuOpen ? "translate-x-0" : "-translate-x-full"}`}>
          <div className="space-y-5">
            <div className="flex items-center justify-between border-b border-white/[0.05] pb-3">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded bg-indigo-600 flex items-center justify-center text-white font-black text-xs">
                  N
                </div>
                <span className="font-extrabold text-xs text-white/95 tracking-wider font-mono">NEXONPORTAL</span>
              </div>
              <button 
                onClick={() => setIsMobileMenuOpen(false)} 
                className="p-1 hover:bg-white/[0.05] rounded-full text-white/40 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Quick Profile Mobile Card */}
            <div className="p-3 bg-white/[0.02] border border-white/[0.05] rounded-xl text-[11px]">
              <div className="font-bold text-white truncate">{userProfile.name}</div>
              <div className="text-[10px] text-white/40 truncate mt-0.5">{userProfile.school}</div>
              <div className="mt-2 pt-2 border-t border-white/[0.04] flex justify-between">
                <span className="text-white/40 font-mono">Role:</span>
                <span className="font-bold text-indigo-400 font-mono">{userProfile.role}</span>
              </div>
            </div>

            {/* Mobile Tab Selectors */}
            <div className="space-y-1">
              <span className="text-[9px] text-white/30 font-mono uppercase tracking-widest pl-1 block mb-1">Menu Portal</span>
              {navItems.map((item) => {
                const IconComp = item.icon;
                const isSelected = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id as ActiveTab);
                      setIsMobileMenuOpen(false);
                    }}
                    className={`w-full text-left p-2.5 rounded-xl flex items-start gap-2.5 transition-all cursor-pointer ${
                      isSelected 
                        ? "bg-indigo-600/15 text-white border border-indigo-500/10" 
                        : "hover:bg-white/[0.02] text-white/60"
                    }`}
                  >
                    <IconComp className={`w-3.5 h-3.5 mt-0.5 shrink-0 ${isSelected ? "text-indigo-400" : "text-white/40"}`} />
                    <div className="min-w-0">
                      <div className="text-xs font-bold leading-tight">{item.label}</div>
                      <div className="text-[9px] text-white/35 leading-tight truncate mt-0.5">{item.desc}</div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="p-2 border-t border-white/[0.04] text-[9px] text-white/20 font-mono text-center">
            NexonPortal v2.6.2
          </div>
        </aside>

        {/* Dynamic content screen area */}
        <main className="flex-1 p-3 sm:p-4 md:p-6 overflow-y-auto relative h-full">
          
          <div className="max-w-7xl mx-auto h-full flex flex-col">
            {activeTab === "diana" && (
              <div className="flex-1">
                <DianaChat onAddNotification={handleAddToast} />
              </div>
            )}

            {activeTab === "liana" && (
              <div className="flex-1">
                <LianaCounsel onAddNotification={handleAddToast} />
              </div>
            )}

            {activeTab === "nexoncode" && (
              <div className="flex-1">
                <NexonCodeStudio onAddNotification={handleAddToast} />
              </div>
            )}

            {activeTab === "nexonlab" && (
              <div className="flex-1">
                <NexonLabSandbox onAddNotification={handleAddToast} />
              </div>
            )}

            {activeTab === "reminders" && (
              <div className="flex-1">
                <SmartReminder onAddNotification={handleAddToast} />
              </div>
            )}

            {activeTab === "nexonai" && currentUser && (
              <div className="flex-1">
                <NexonAIHub 
                  userProfile={userProfile}
                  onSaveProfile={setUserProfile}
                  onAddNotification={handleAddToast}
                  userId={currentUser.uid}
                />
              </div>
            )}
          </div>

        </main>
      </div>

      {/* Floating Toast Notification Popups */}
      <div className="fixed top-3 left-3 right-3 sm:top-auto sm:left-auto sm:bottom-4 sm:right-4 z-50 space-y-2 sm:max-w-sm sm:w-full font-sans pointer-events-none">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className="p-3.5 bg-[#0c0c0f] border border-white/[0.1] text-white rounded-2xl shadow-xl flex items-start gap-3 border-l-4 border-l-indigo-500 pointer-events-auto animate-slideIn"
          >
            <div className="p-1.5 bg-indigo-500/10 rounded-lg text-indigo-300 shrink-0 mt-0.5">
              <Bell className="w-4 h-4 animate-pulse" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-1">
                <span className="font-bold text-xs text-white truncate">{toast.title}</span>
                <span className="text-[9px] text-white/35 font-mono shrink-0">{toast.timestamp}</span>
              </div>
              <p className="text-[11px] text-white/60 leading-relaxed mt-1 whitespace-pre-line">{toast.msg}</p>
            </div>
            <button
              onClick={() => setToasts(prev => prev.filter(t => t.id !== toast.id))}
              className="p-1 text-white/30 hover:text-white rounded-full cursor-pointer transition-colors shrink-0"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        ))}
      </div>

      {/* Profile Modification Dialog */}
      {isProfileEditing && currentUser && (
        <UserProfileEditor 
          user={currentUser}
          onClose={() => setIsProfileEditing(false)}
          onSaveSuccess={(updated) => setUserProfile(updated)}
          onAddNotification={handleAddToast}
        />
      )}

    </div>
  );
}
