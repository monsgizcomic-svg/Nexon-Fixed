/**
 * Minimal, dependency-free syntax highlighter.
 *
 * This intentionally avoids pulling in a library like Prism/Shiki — NexonCode
 * only needs "good enough" visual structure (keywords / strings / comments /
 * numbers) to stop looking like a flat textarea, not full language-accurate
 * tokenization. Keeping it regex-based means zero new dependencies and zero
 * new build-time failure points.
 */

const KEYWORDS = [
  "function", "return", "const", "let", "var", "if", "else", "for", "while",
  "class", "import", "export", "from", "default", "new", "this", "async",
  "await", "try", "catch", "finally", "throw", "switch", "case", "break",
  "continue", "extends", "implements", "interface", "type", "public",
  "private", "protected", "static", "void", "null", "undefined", "true",
  "false", "def", "elif", "pass", "lambda", "yield", "with", "as", "is",
  "not", "and", "or", "in", "print", "self", "None", "True", "False",
  "int", "float", "str", "bool", "list", "dict", "tuple", "struct", "enum",
  "package", "namespace", "using", "include", "select", "insert", "update",
  "delete", "where", "join", "table", "create", "drop", "alter", "values",
];

const KEYWORD_PATTERN = new RegExp(`\\b(${KEYWORDS.join("|")})\\b`, "g");

interface Token {
  text: string;
  type: "keyword" | "string" | "comment" | "number" | "plain";
}

function tokenizeLine(line: string): Token[] {
  const tokens: Token[] = [];
  // Order matters: comments and strings should "consume" their full span
  // before keyword/number matching runs on the remainder.
  const masterPattern = /(\/\/.*$|#.*$)|("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'|`(?:[^`\\]|\\.)*`)|(\b\d+\.?\d*\b)/g;

  let lastIndex = 0;
  let match: RegExpExecArray | null;

  const pushPlainWithKeywords = (segment: string) => {
    if (!segment) return;
    let idx = 0;
    let kwMatch: RegExpExecArray | null;
    KEYWORD_PATTERN.lastIndex = 0;
    while ((kwMatch = KEYWORD_PATTERN.exec(segment)) !== null) {
      if (kwMatch.index > idx) {
        tokens.push({ text: segment.slice(idx, kwMatch.index), type: "plain" });
      }
      tokens.push({ text: kwMatch[0], type: "keyword" });
      idx = kwMatch.index + kwMatch[0].length;
    }
    if (idx < segment.length) {
      tokens.push({ text: segment.slice(idx), type: "plain" });
    }
  };

  while ((match = masterPattern.exec(line)) !== null) {
    if (match.index > lastIndex) {
      pushPlainWithKeywords(line.slice(lastIndex, match.index));
    }
    if (match[1] !== undefined) {
      tokens.push({ text: match[1], type: "comment" });
    } else if (match[2] !== undefined) {
      tokens.push({ text: match[2], type: "string" });
    } else if (match[3] !== undefined) {
      tokens.push({ text: match[3], type: "number" });
    }
    lastIndex = match.index + match[0].length;
  }
  if (lastIndex < line.length) {
    pushPlainWithKeywords(line.slice(lastIndex));
  }

  return tokens;
}

const TOKEN_CLASSES: Record<Token["type"], string> = {
  keyword: "text-indigo-400 font-medium",
  string: "text-emerald-400",
  comment: "text-white/30 italic",
  number: "text-amber-400",
  plain: "text-white/85",
};

export default function CodeBlock({ code }: { code: string }) {
  const lines = code.split("\n");
  return (
    <pre className="whitespace-pre overflow-x-auto">
      {lines.map((line, i) => (
        <div key={i} className="table-row">
          <span className="table-cell select-none pr-4 text-right text-white/20 text-[11px] align-top">
            {i + 1}
          </span>
          <span className="table-cell">
            {tokenizeLine(line).map((tok, j) => (
              <span key={j} className={TOKEN_CLASSES[tok.type]}>{tok.text}</span>
            ))}
            {line.length === 0 && "\u00A0"}
          </span>
        </div>
      ))}
    </pre>
  );
}
