import React, { useState, useEffect, useRef } from "react";
import { 
  MessageSquare, 
  Code, 
  Image, 
  Search, 
  Brain, 
  Plus, 
  Trash2, 
  Settings, 
  Send, 
  Paperclip, 
  Globe, 
  FileText, 
  Check, 
  Loader2, 
  ExternalLink, 
  Download, 
  Maximize2, 
  ChevronDown, 
  ChevronUp, 
  Copy, 
  Bot, 
  User as UserIcon, 
  X, 
  LogOut,
  Sparkles,
  ArrowRight,
  Menu
} from "lucide-react";
import { auth, db } from "../lib/firebase";
import { 
  collection, 
  addDoc, 
  getDocs, 
  updateDoc, 
  deleteDoc, 
  doc, 
  query, 
  orderBy,
  serverTimestamp
} from "firebase/firestore";

interface Message {
  sender: "user" | "ai";
  text: string;
  isFallback?: boolean;
  data?: string; // base64 or raw SVG code
  mimeType?: string;
  sources?: { title: string; uri: string }[];
  thinkingLogs?: string[];
  timestamp?: string;
}

interface ChatSession {
  id: string;
  title: string;
  mode: "chat" | "code" | "canvas" | "search" | "deep-research";
  messages: Message[];
  createdAt: any;
  updatedAt: any;
}

interface NexonAIProps {
  onAddNotification: (title: string, msg: string) => void;
  userProfile: {
    name: string;
    role: string;
    grade: string;
    school: string;
  };
  onSaveProfile: (updated: { name: string; role: string; grade: string; school: string }) => void;
  onLogout: () => void;
}

export default function NexonAI({ onAddNotification, userProfile, onSaveProfile, onLogout }: NexonAIProps) {
  const [activeMode, setActiveMode] = useState<"chat" | "code" | "canvas" | "search" | "deep-research">("chat");
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);

  // Canvas Settings
  const [aspectRatio, setAspectRatio] = useState<string>("1:1");
  const [zoomedSvg, setZoomedSvg] = useState<string | null>(null);

  // Code Settings
  const [selectedLanguage, setSelectedLanguage] = useState<string>("Javascript");

  // Deep Research States
  const [currentThinkingLogs, setCurrentThinkingLogs] = useState<string[]>([]);
  const [isThinkingLogsExpanded, setIsThinkingLogsExpanded] = useState<boolean>(true);

  // File upload indicator state
  const [attachedFile, setAttachedFile] = useState<{
    name: string;
    mimeType: string;
    size: number;
    base64: string;
  } | null>(null);

  // Edit Profile States
  const [editName, setEditName] = useState(userProfile.name);
  const [editRole, setEditRole] = useState(userProfile.role);
  const [editGrade, setEditGrade] = useState(userProfile.grade);
  const [editSchool, setEditSchool] = useState(userProfile.school);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Load chat sessions from Firestore
  const loadSessions = async () => {
    const user = auth.currentUser;
    if (!user) return;
    try {
      const q = query(
        collection(db, "users", user.uid, "chats"),
        orderBy("updatedAt", "desc")
      );
      const querySnapshot = await getDocs(q);
      const loaded: ChatSession[] = [];
      querySnapshot.forEach((docSnap) => {
        const data = docSnap.data();
        loaded.push({
          id: docSnap.id,
          title: data.title || "Obrolan Baru",
          mode: data.mode || "chat",
          messages: data.messages || [],
          createdAt: data.createdAt,
          updatedAt: data.updatedAt
        });
      });
      setSessions(loaded);
    } catch (err) {
      console.warn("Gagal memuat sesi chat dari Firestore:", err);
    }
  };

  useEffect(() => {
    loadSessions();
  }, []);

  // Scroll to bottom on messages update
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, currentThinkingLogs, isGenerating]);

  // Handle active session changes
  const selectSession = (id: string) => {
    const sess = sessions.find((s) => s.id === id);
    if (sess) {
      setActiveSessionId(id);
      setActiveMode(sess.mode);
      setMessages(sess.messages);
      setAttachedFile(null);
      setCurrentThinkingLogs([]);
      // Close sidebar on mobile
      if (window.innerWidth < 768) {
        setIsSidebarOpen(false);
      }
    }
  };

  const startNewSession = (mode: typeof activeMode) => {
    setActiveSessionId(null);
    setActiveMode(mode);
    setMessages([]);
    setAttachedFile(null);
    setCurrentThinkingLogs([]);
    if (window.innerWidth < 768) {
      setIsSidebarOpen(false);
    }
  };

  // File attachment conversion
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 8 * 1024 * 1024) {
      onAddNotification("Berkas Terlalu Besar", "Batas maksimal berkas di Nexon AI adalah 8MB.");
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const base64String = (reader.result as string).split(",")[1];
      setAttachedFile({
        name: file.name,
        mimeType: file.type,
        size: file.size,
        base64: base64String
      });
      onAddNotification("Berkas Dilampirkan 📎", `${file.name} siap dikirim.`);
    };
    reader.readAsDataURL(file);
  };

  const removeAttachedFile = () => {
    setAttachedFile(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  // Submit main user prompt
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() && !attachedFile) return;

    const user = auth.currentUser;
    if (!user) {
      onAddNotification("Error Akses", "Silakan login terlebih dahulu.");
      return;
    }

    const userPrompt = input.trim();
    setInput("");
    setIsGenerating(true);

    const userMsg: Message = {
      sender: "user",
      text: userPrompt || `Mengunggah berkas: ${attachedFile?.name}`,
      timestamp: new Date().toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" })
    };

    const updatedMessages = [...messages, userMsg];
    setMessages(updatedMessages);

    // If starting a fresh unsaved session, provision title based on prompt
    let currentId = activeSessionId;
    let currentTitle = activeSessionId 
      ? sessions.find(s => s.id === activeSessionId)?.title || "Obrolan" 
      : (userPrompt.substring(0, 35) || "Lampiran Berkas") + "...";

    // Call corresponding endpoint
    try {
      let aiResponse: Message = { sender: "ai", text: "" };

      if (activeMode === "chat") {
        const payload = {
          messages: updatedMessages.map(m => ({ sender: m.sender, text: m.text })),
          fileData: attachedFile
        };
        const response = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        });
        const resData = await response.json();
        aiResponse = {
          sender: "ai",
          text: resData.text || "Gagal memproses jawaban dari Nexon Chat.",
          timestamp: new Date().toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" })
        };

      } else if (activeMode === "code") {
        const payload = {
          messages: updatedMessages.map(m => ({ sender: m.sender, text: m.text })),
          language: selectedLanguage
        };
        const response = await fetch("/api/code", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        });
        const resData = await response.json();
        aiResponse = {
          sender: "ai",
          text: resData.text || "Gagal memproses kode pemrograman.",
          timestamp: new Date().toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" })
        };

      } else if (activeMode === "canvas") {
        const payload = {
          prompt: userPrompt,
          aspectRatio: aspectRatio
        };
        const response = await fetch("/api/canvas", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        });
        const resData = await response.json();
        aiResponse = {
          sender: "ai",
          text: resData.explanation || "Gambar berhasil digenerasikan.",
          isFallback: resData.isFallback,
          data: resData.data,
          mimeType: resData.mimeType,
          timestamp: new Date().toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" })
        };

      } else if (activeMode === "search") {
        const payload = {
          messages: updatedMessages.map(m => ({ sender: m.sender, text: m.text }))
        };
        const response = await fetch("/api/search", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        });
        const resData = await response.json();
        aiResponse = {
          sender: "ai",
          text: resData.text || "Hasil pencarian web kosong.",
          sources: resData.sources || [],
          timestamp: new Date().toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" })
        };

      } else if (activeMode === "deep-research") {
        // Deep Research step-by-step thinking logs simulation & fetching
        setCurrentThinkingLogs([
          "Memulai mesin analisis mendalam Nexon Deep Research...",
          "Menganalisis domain topik riset dan menyusun rencana pertanyaan..."
        ]);
        
        const payload = { query: userPrompt };
        const response = await fetch("/api/deep-research", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        });
        const resData = await response.json();
        
        if (resData.thinkingLogs) {
          setCurrentThinkingLogs(resData.thinkingLogs);
        }
        
        aiResponse = {
          sender: "ai",
          text: resData.markdown || "Gagal menyintesis laporan riset.",
          sources: resData.sources || [],
          thinkingLogs: resData.thinkingLogs || [],
          timestamp: new Date().toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" })
        };
      }

      const finalMessages = [...updatedMessages, aiResponse];
      setMessages(finalMessages);

      // Synchronize conversation back to Firestore
      if (!currentId) {
        // Create new Firestore document
        const newDocRef = await addDoc(collection(db, "users", user.uid, "chats"), {
          title: currentTitle,
          mode: activeMode,
          messages: finalMessages,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        });
        currentId = newDocRef.id;
        setActiveSessionId(currentId);
      } else {
        // Update existing Firestore document
        const docRef = doc(db, "users", user.uid, "chats", currentId);
        await updateDoc(docRef, {
          messages: finalMessages,
          updatedAt: serverTimestamp()
        });
      }

      // Reload sidebar sessions list
      loadSessions();
      setAttachedFile(null);
      if (fileInputRef.current) fileInputRef.current.value = "";

    } catch (err: any) {
      console.error(err);
      onAddNotification("Penjanaan Gagal ❌", `Terjadi kesalahan saat memproses permintaan: ${err.message}`);
    } finally {
      setIsGenerating(false);
    }
  };

  // Delete chat session
  const handleDeleteSession = async (sessionId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const user = auth.currentUser;
    if (!user) return;

    if (!confirm("Apakah Anda yakin ingin menghapus riwayat obrolan ini secara permanen?")) {
      return;
    }

    try {
      await deleteDoc(doc(db, "users", user.uid, "chats", sessionId));
      setSessions(prev => prev.filter(s => s.id !== sessionId));
      if (activeSessionId === sessionId) {
        setMessages([]);
        setActiveSessionId(null);
      }
      onAddNotification("Obrolan Dihapus", "Riwayat percakapan telah berhasil dihapus dari cloud.");
    } catch (err) {
      console.warn("Gagal menghapus sesi chat:", err);
    }
  };

  // Edit user profile in Firestore
  const handleProfileSave = async () => {
    const user = auth.currentUser;
    if (!user) return;

    try {
      const docRef = doc(db, "users", user.uid);
      await updateDoc(docRef, {
        name: editName,
        role: editRole,
        grade: editGrade,
        school: editSchool
      });
      onSaveProfile({
        name: editName,
        role: editRole,
        grade: editGrade,
        school: editSchool
      });
      setIsProfileModalOpen(false);
      onAddNotification("Profil Disimpan ✨", "Profil personal Anda berhasil diperbarui di server.");
    } catch (err) {
      console.warn("Gagal menyimpan profil:", err);
      // Fallback
      onSaveProfile({
        name: editName,
        role: editRole,
        grade: editGrade,
        school: editSchool
      });
      setIsProfileModalOpen(false);
    }
  };

  // Custom Formatter for Markdown with syntax highlighted code block, quotes, table support
  const formatMessageText = (text: string) => {
    if (!text) return null;
    
    // Split codeblocks
    const parts = text.split(/```/g);
    return parts.map((part, index) => {
      if (index % 2 === 1) {
        // Code Block
        const breakIndex = part.indexOf("\n");
        let lang = "code";
        let code = part;
        if (breakIndex !== -1) {
          const possibleLang = part.substring(0, breakIndex).trim();
          if (possibleLang && possibleLang.length < 15) {
            lang = possibleLang;
            code = part.substring(breakIndex + 1);
          }
        }
        return (
          <div key={index} className="my-4 rounded-xl border border-white/5 bg-[#121215] overflow-hidden font-mono text-sm shadow-2xl">
            <div className="flex items-center justify-between px-4 py-2 bg-white/[0.02] border-b border-white/5 text-xs text-white/40">
              <span className="uppercase tracking-widest font-bold text-[10px] text-indigo-400">{lang}</span>
              <button 
                onClick={() => {
                  navigator.clipboard.writeText(code.trim());
                  onAddNotification("Kode Disalin", "Kode pemrograman berhasil disimpan ke papan klip Anda.");
                }} 
                className="px-2 py-1 hover:bg-white/10 rounded transition-all cursor-pointer flex items-center gap-1.5 text-white/50 hover:text-white"
              >
                <Copy className="w-3 h-3" />
                <span>Salin</span>
              </button>
            </div>
            <pre className="p-4 overflow-x-auto text-white/90 leading-relaxed text-xs">
              <code>{code.trim()}</code>
            </pre>
          </div>
        );
      }

      // Inline lines
      const lines = part.split("\n");
      return lines.map((line, lIdx) => {
        // Bullets
        if (line.trim().startsWith("- ") || line.trim().startsWith("* ")) {
          const clean = line.trim().substring(2);
          return (
            <li key={`${index}-${lIdx}`} className="ml-6 list-disc text-white/80 text-sm leading-relaxed mb-1.5">
              {renderInlineFormatting(clean)}
            </li>
          );
        }

        // Numbered list
        const numMatch = line.trim().match(/^(\d+)\.\s+(.*)/);
        if (numMatch) {
          return (
            <li key={`${index}-${lIdx}`} className="ml-6 list-decimal text-white/80 text-sm leading-relaxed mb-1.5">
              {renderInlineFormatting(numMatch[2])}
            </li>
          );
        }

        // Headers
        if (line.trim().startsWith("### ")) {
          return (
            <h4 key={`${index}-${lIdx}`} className="text-sm font-semibold text-white tracking-tight mt-5 mb-2 flex items-center gap-1">
              <span className="w-1 h-3 bg-indigo-500 rounded"></span>
              {renderInlineFormatting(line.trim().substring(4))}
            </h4>
          );
        }
        if (line.trim().startsWith("## ")) {
          return (
            <h3 key={`${index}-${lIdx}`} className="text-base font-bold text-white tracking-tight mt-6 mb-2 border-b border-white/5 pb-1 flex items-center gap-1.5">
              <span className="w-1.5 h-3.5 bg-indigo-500 rounded"></span>
              {renderInlineFormatting(line.trim().substring(3))}
            </h3>
          );
        }
        if (line.trim().startsWith("# ")) {
          return (
            <h2 key={`${index}-${lIdx}`} className="text-lg font-extrabold text-white tracking-tight mt-7 mb-3 text-indigo-350">
              {renderInlineFormatting(line.trim().substring(2))}
            </h2>
          );
        }

        // Quote block
        if (line.trim().startsWith("> ")) {
          return (
            <blockquote key={`${index}-${lIdx}`} className="border-l-4 border-indigo-500/60 bg-white/[0.02] pl-4 py-2 pr-2 rounded-r-xl my-4 text-sm italic text-white/60">
              {renderInlineFormatting(line.trim().substring(2))}
            </blockquote>
          );
        }

        // Blank space
        if (!line.trim()) return <div key={`${index}-${lIdx}`} className="h-2"></div>;

        return (
          <p key={`${index}-${lIdx}`} className="text-white/80 text-sm leading-relaxed mb-3">
            {renderInlineFormatting(line)}
          </p>
        );
      });
    });
  };

  const renderInlineFormatting = (text: string) => {
    const boldParts = text.split(/\*\*/g);
    return boldParts.map((bPart, bIdx) => {
      const element = bIdx % 2 === 1 ? <strong key={bIdx} className="font-bold text-white/95">{bPart}</strong> : bPart;
      
      if (typeof element === "string") {
        const codeParts = element.split(/`/g);
        return codeParts.map((cPart, cIdx) => {
          if (cIdx % 2 === 1) {
            return <code key={`${bIdx}-${cIdx}`} className="bg-white/10 px-1.5 py-0.5 rounded text-xs font-mono text-indigo-300">{cPart}</code>;
          }
          return cPart;
        });
      }
      return element;
    });
  };

  return (
    <div className="min-h-screen bg-[#0a0a0c] text-white/90 flex font-sans relative overflow-hidden" id="nexon_ai_platform">
      
      {/* Background glow matrix */}
      <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-indigo-500/[0.03] rounded-full blur-3xl pointer-events-none -z-10"></div>
      <div className="absolute bottom-10 right-10 w-96 h-96 bg-purple-500/[0.02] rounded-full blur-3xl pointer-events-none -z-10"></div>

      {/* SIDEBAR */}
      <aside 
        className={`fixed md:relative top-0 bottom-0 left-0 z-40 w-72 bg-[#121215] border-r border-white/5 flex flex-col justify-between transition-transform duration-300 transform 
          ${isSidebarOpen ? "translate-x-0" : "-translate-x-full"} md:translate-x-0`}
      >
        {/* Brand Header */}
        <div className="p-4 border-b border-white/5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center text-white font-bold shadow-lg shadow-indigo-500/25">
              <Sparkles className="w-4 h-4 text-white animate-pulse" />
            </div>
            <div>
              <h1 className="font-extrabold text-sm tracking-widest text-white block uppercase">Nexon AI</h1>
              <span className="text-[9px] text-white/40 tracking-wider font-mono">WORKSPACE LIVE</span>
            </div>
          </div>
          <button 
            onClick={() => setIsSidebarOpen(false)} 
            className="p-1.5 hover:bg-white/5 rounded-lg md:hidden text-white/60 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Action: Obrolan Baru */}
        <div className="p-3">
          <button 
            onClick={() => startNewSession(activeMode)}
            className="w-full py-2.5 px-4 bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-300 hover:text-indigo-200 border border-indigo-500/20 hover:border-indigo-500/40 rounded-xl text-xs font-bold font-mono transition-all flex items-center justify-center gap-2 cursor-pointer shadow-sm group"
          >
            <Plus className="w-4 h-4 group-hover:rotate-90 transition-transform" />
            <span>Obrolan Baru</span>
          </button>
        </div>

        {/* Feature Modes selector */}
        <div className="px-3 py-2 space-y-1">
          <span className="px-3 text-[10px] font-bold font-mono tracking-wider text-white/30 uppercase">Fitur AI</span>
          <button 
            onClick={() => startNewSession("chat")}
            className={`w-full px-3 py-2 rounded-xl text-xs font-medium flex items-center gap-2.5 transition-all cursor-pointer
              ${activeMode === "chat" && !activeSessionId ? "bg-white/5 text-white border-l-2 border-indigo-500" : "text-white/60 hover:bg-white/[0.03] hover:text-white"}`}
          >
            <MessageSquare className="w-4 h-4 text-indigo-400" />
            <span>Asisten Chat</span>
          </button>
          <button 
            onClick={() => startNewSession("code")}
            className={`w-full px-3 py-2 rounded-xl text-xs font-medium flex items-center gap-2.5 transition-all cursor-pointer
              ${activeMode === "code" && !activeSessionId ? "bg-white/5 text-white border-l-2 border-indigo-500" : "text-white/60 hover:bg-white/[0.03] hover:text-white"}`}
          >
            <Code className="w-4 h-4 text-green-400" />
            <span>Asisten Code</span>
          </button>
          <button 
            onClick={() => startNewSession("canvas")}
            className={`w-full px-3 py-2 rounded-xl text-xs font-medium flex items-center gap-2.5 transition-all cursor-pointer
              ${activeMode === "canvas" && !activeSessionId ? "bg-white/5 text-white border-l-2 border-indigo-500" : "text-white/60 hover:bg-white/[0.03] hover:text-white"}`}
          >
            <Image className="w-4 h-4 text-pink-400" />
            <span>Kanvas Gambar</span>
          </button>
          <button 
            onClick={() => startNewSession("search")}
            className={`w-full px-3 py-2 rounded-xl text-xs font-medium flex items-center gap-2.5 transition-all cursor-pointer
              ${activeMode === "search" && !activeSessionId ? "bg-white/5 text-white border-l-2 border-indigo-500" : "text-white/60 hover:bg-white/[0.03] hover:text-white"}`}
          >
            <Search className="w-4 h-4 text-sky-400" />
            <span>Pencarian Cerdas</span>
          </button>
          <button 
            onClick={() => startNewSession("deep-research")}
            className={`w-full px-3 py-2 rounded-xl text-xs font-medium flex items-center gap-2.5 transition-all cursor-pointer
              ${activeMode === "deep-research" && !activeSessionId ? "bg-white/5 text-white border-l-2 border-indigo-500" : "text-white/60 hover:bg-white/[0.03] hover:text-white"}`}
          >
            <Brain className="w-4 h-4 text-purple-400 animate-pulse" />
            <span>Deep Research</span>
          </button>
        </div>

        {/* Scrollable Conversation History */}
        <div className="flex-1 px-3 py-4 overflow-y-auto space-y-2 border-t border-white/[0.04]">
          <span className="px-3 text-[10px] font-bold font-mono tracking-wider text-white/30 uppercase block mb-1">Riwayat Sesi</span>
          {sessions.length === 0 ? (
            <div className="text-center py-6 px-3 text-[11px] text-white/30 font-mono">
              Belum ada riwayat obrolan di cloud.
            </div>
          ) : (
            <div className="space-y-1">
              {sessions.map((sess) => {
                const isActive = activeSessionId === sess.id;
                return (
                  <div 
                    key={sess.id}
                    onClick={() => selectSession(sess.id)}
                    className={`group w-full px-3 py-2.5 rounded-xl text-xs flex items-center justify-between gap-2.5 transition-all cursor-pointer relative overflow-hidden border
                      ${isActive 
                        ? "bg-indigo-600/10 border-indigo-550/20 text-white font-medium" 
                        : "bg-white/[0.01] hover:bg-white/[0.03] border-transparent text-white/75"}`}
                  >
                    <div className="flex items-center gap-2 min-w-0 flex-1">
                      {sess.mode === "chat" && <MessageSquare className="w-3.5 h-3.5 text-indigo-400 shrink-0" />}
                      {sess.mode === "code" && <Code className="w-3.5 h-3.5 text-green-400 shrink-0" />}
                      {sess.mode === "canvas" && <Image className="w-3.5 h-3.5 text-pink-400 shrink-0" />}
                      {sess.mode === "search" && <Search className="w-3.5 h-3.5 text-sky-400 shrink-0" />}
                      {sess.mode === "deep-research" && <Brain className="w-3.5 h-3.5 text-purple-400 shrink-0" />}
                      <span className="truncate flex-1 pr-1">{sess.title}</span>
                    </div>
                    <button 
                      onClick={(e) => handleDeleteSession(sess.id, e)}
                      className="p-1 text-white/20 hover:text-red-400 rounded-lg opacity-0 group-hover:opacity-100 focus:opacity-100 transition-opacity shrink-0 cursor-pointer hover:bg-white/5"
                      title="Hapus obrolan"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Sidebar Footer Personal Profile */}
        <div className="p-3 border-t border-white/5 bg-white/[0.01] space-y-2">
          {/* Active profile card */}
          <div 
            onClick={() => {
              setEditName(userProfile.name);
              setEditRole(userProfile.role);
              setEditGrade(userProfile.grade);
              setEditSchool(userProfile.school);
              setIsProfileModalOpen(true);
            }}
            className="flex items-center gap-2.5 bg-white/5 hover:bg-white/10 px-3 py-2 rounded-xl border border-white/5 hover:border-indigo-500/30 cursor-pointer transition-all"
            title="Edit Profil"
          >
            <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-indigo-500 to-purple-500 text-white flex items-center justify-center font-bold text-xs border border-white/10 shrink-0 shadow-md">
              {userProfile.name ? userProfile.name.substring(0, 2).toUpperCase() : "NX"}
            </div>
            <div className="flex-1 min-w-0">
              <span className="text-xs text-white/90 font-bold block truncate leading-tight">{userProfile.name}</span>
              <span className="text-[10px] text-white/40 block truncate leading-tight">{userProfile.role}</span>
            </div>
            <Settings className="w-3.5 h-3.5 text-white/40 group-hover:text-white" />
          </div>

          {/* Action: Log Out */}
          <button 
            onClick={onLogout}
            className="w-full py-2 px-3 bg-red-500/10 hover:bg-red-500/20 text-red-400 hover:text-red-300 border border-red-500/15 text-xs font-bold font-mono rounded-xl cursor-pointer transition-colors flex items-center justify-center gap-1.5"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Keluar Akun</span>
          </button>
        </div>
      </aside>

      {/* OVERLAY FOR MOBILE SIDEBAR */}
      {isSidebarOpen && (
        <div 
          onClick={() => setIsSidebarOpen(false)}
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-30 md:hidden"
        ></div>
      )}

      {/* MAIN MAIN AREA */}
      <main className="flex-1 flex flex-col min-w-0 h-screen overflow-hidden">
        
        {/* Workspace Top Header */}
        <header className="h-16 border-b border-white/5 bg-[#121215]/80 backdrop-blur-md px-4 flex items-center justify-between z-10 sticky top-0 shrink-0">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="p-2 hover:bg-white/5 rounded-xl text-white/85 hover:text-white cursor-pointer"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold text-white font-display">
                {activeSessionId 
                  ? sessions.find(s => s.id === activeSessionId)?.title 
                  : `Nexon AI - ${activeMode === "chat" ? "Asisten Chat" : activeMode === "code" ? "Asisten Code" : activeMode === "canvas" ? "Kanvas Gambar" : activeMode === "search" ? "Pencarian Cerdas" : "Deep Research"}`}
              </span>
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-mono font-medium bg-indigo-500/15 text-indigo-300 border border-indigo-500/20">
                <span className="w-1 h-1 rounded-full bg-green-400 animate-pulse"></span> Cloud Sync
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-white/40 font-mono tracking-widest hidden sm:inline">[ nexon.my.id/Nexon ]</span>
          </div>
        </header>

        {/* MESSAGES & CHAT BODY CONTENT */}
        <div className="flex-1 overflow-y-auto px-4 py-6 md:px-8 space-y-6">
          {messages.length === 0 ? (
            /* Welcome Landing page with Suggestions */
            <div className="max-w-3xl mx-auto py-12 md:py-20 text-center space-y-8 animate-fadeIn">
              
              <div className="space-y-4">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-medium bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Kecerdasan Buatan Multi-Alat Terpadu</span>
                </div>
                <h2 className="text-3xl md:text-5xl font-extrabold text-white tracking-tight leading-tight">
                  Ada yang bisa saya bantu, <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400 font-display">{userProfile.name}</span>?
                </h2>
                <p className="text-white/50 text-xs md:text-sm leading-relaxed max-w-lg mx-auto">
                  Platform serbaguna Nexon AI untuk membantu produktivitas, menguji baris kode pemrograman, melukis ilustrasi digital, atau melakukan riset mendalam di web.
                </p>
              </div>

              {/* Mode cards display */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 text-left">
                <div 
                  onClick={() => startNewSession("chat")}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer
                    ${activeMode === "chat" ? "bg-indigo-500/5 border-indigo-500/40 shadow-md" : "bg-white/[0.02] border-white/5 hover:bg-white/[0.04]"}`}
                >
                  <MessageSquare className="w-5 h-5 text-indigo-400 mb-2.5" />
                  <h4 className="text-xs font-bold text-white mb-1 font-mono uppercase">💬 Chat Assistant</h4>
                  <p className="text-[11px] text-white/40 leading-normal">Asisten serbaguna menjawab pertanyaan, menerjemahkan bahasa, & menyusun ide.</p>
                </div>

                <div 
                  onClick={() => startNewSession("code")}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer
                    ${activeMode === "code" ? "bg-indigo-500/5 border-indigo-500/40 shadow-md" : "bg-white/[0.02] border-white/5 hover:bg-white/[0.04]"}`}
                >
                  <Code className="w-5 h-5 text-green-400 mb-2.5" />
                  <h4 className="text-xs font-bold text-white mb-1 font-mono uppercase">💻 Code Studio</h4>
                  <p className="text-[11px] text-white/40 leading-normal">AI khusus pemrograman untuk menulis, men-debug, merapikan, & mendikte kode.</p>
                </div>

                <div 
                  onClick={() => startNewSession("canvas")}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer
                    ${activeMode === "canvas" ? "bg-indigo-500/5 border-indigo-500/40 shadow-md" : "bg-white/[0.02] border-white/5 hover:bg-white/[0.04]"}`}
                >
                  <Image className="w-5 h-5 text-pink-400 mb-2.5" />
                  <h4 className="text-xs font-bold text-white mb-1 font-mono uppercase">🎨 AI Canvas</h4>
                  <p className="text-[11px] text-white/40 leading-normal">Hasilkan ilustrasi digital, aset logo, banner kreatif dari deskripsi teks.</p>
                </div>

                <div 
                  onClick={() => startNewSession("search")}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer
                    ${activeMode === "search" ? "bg-indigo-500/5 border-indigo-500/40 shadow-md" : "bg-white/[0.02] border-white/5 hover:bg-white/[0.04]"}`}
                >
                  <Search className="w-5 h-5 text-sky-400 mb-2.5" />
                  <h4 className="text-xs font-bold text-white mb-1 font-mono uppercase">🔍 Web Search</h4>
                  <p className="text-[11px] text-white/40 leading-normal">AI yang terintegrasi dengan Google Search untuk menyajikan data web terkini & aktual.</p>
                </div>

                <div 
                  onClick={() => startNewSession("deep-research")}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer sm:col-span-2 md:col-span-1
                    ${activeMode === "deep-research" ? "bg-indigo-500/5 border-indigo-500/40 shadow-md" : "bg-white/[0.02] border-white/5 hover:bg-white/[0.04]"}`}
                >
                  <Brain className="w-5 h-5 text-purple-400 mb-2.5" />
                  <h4 className="text-xs font-bold text-white mb-1 font-mono uppercase">🧠 Deep Research</h4>
                  <p className="text-[11px] text-white/40 leading-normal">Mesin penelitian otonom multi-tahap, menjelajahi web & merangkum laporan riset mendalam.</p>
                </div>
              </div>

              {/* Sample Quick Questions list based on active mode */}
              <div className="space-y-2.5 max-w-xl mx-auto text-left">
                <span className="text-[10px] font-bold font-mono tracking-wider text-white/30 uppercase block text-center">Rekomendasi Eksplorasi</span>
                {activeMode === "chat" && (
                  <>
                    <button 
                      onClick={() => setInput("Buat rencana itinerary liburan 3 hari 2 malam yang ramah anak di Bandung")}
                      className="w-full p-3 text-xs text-white/60 hover:text-white bg-white/[0.02] hover:bg-white/[0.04] border border-white/5 rounded-xl transition-all flex items-center justify-between group"
                    >
                      <span>"Buat rencana itinerary liburan 3 hari 2 malam yang ramah anak di Bandung"</span>
                      <ArrowRight className="w-3.5 h-3.5 text-white/20 group-hover:translate-x-1 transition-transform" />
                    </button>
                    <button 
                      onClick={() => setInput("Tolong terjemahkan teks ini ke bahasa Jepang formal: 'Terima kasih banyak atas kerja keras Anda hari ini.'")}
                      className="w-full p-3 text-xs text-white/60 hover:text-white bg-white/[0.02] hover:bg-white/[0.04] border border-white/5 rounded-xl transition-all flex items-center justify-between group"
                    >
                      <span>"Tolong terjemahkan teks ke bahasa Jepang formal: 'Terima kasih banyak...'"</span>
                      <ArrowRight className="w-3.5 h-3.5 text-white/20 group-hover:translate-x-1 transition-transform" />
                    </button>
                  </>
                )}
                {activeMode === "code" && (
                  <>
                    <button 
                      onClick={() => setInput("Tuliskan fungsi utilitas debouncing TypeScript yang aman untuk penyesuaian ukuran jendela browser")}
                      className="w-full p-3 text-xs text-white/60 hover:text-white bg-white/[0.02] hover:bg-white/[0.04] border border-white/5 rounded-xl transition-all flex items-center justify-between group"
                    >
                      <span>"Tuliskan fungsi utilitas debouncing TypeScript yang aman..."</span>
                      <ArrowRight className="w-3.5 h-3.5 text-white/20 group-hover:translate-x-1 transition-transform" />
                    </button>
                    <button 
                      onClick={() => setInput("Bagaimana cara memperbaiki bug React: 'Rendered fewer hooks than expected'?")}
                      className="w-full p-3 text-xs text-white/60 hover:text-white bg-white/[0.02] hover:bg-white/[0.04] border border-white/5 rounded-xl transition-all flex items-center justify-between group"
                    >
                      <span>"Bagaimana cara memperbaiki bug React: 'Rendered fewer hooks than expected'?"</span>
                      <ArrowRight className="w-3.5 h-3.5 text-white/20 group-hover:translate-x-1 transition-transform" />
                    </button>
                  </>
                )}
                {activeMode === "canvas" && (
                  <>
                    <button 
                      onClick={() => setInput("Desain logo minimalis bernuansa teknologi futuristik bertuliskan 'NEXON', warna gradasi neon ungu cerah, latar belakang gelap melingkar")}
                      className="w-full p-3 text-xs text-white/60 hover:text-white bg-white/[0.02] hover:bg-white/[0.04] border border-white/5 rounded-xl transition-all flex items-center justify-between group"
                    >
                      <span>"Desain logo minimalis bernuansa teknologi futuristik bertuliskan 'NEXON'..."</span>
                      <ArrowRight className="w-3.5 h-3.5 text-white/20 group-hover:translate-x-1 transition-transform" />
                    </button>
                    <button 
                      onClick={() => setInput("Ilustrasi pemandangan gunung berapi estetis bergaya seni vektor retro, gradasi matahari terbenam kuning-jingga yang tenang")}
                      className="w-full p-3 text-xs text-white/60 hover:text-white bg-white/[0.02] hover:bg-white/[0.04] border border-white/5 rounded-xl transition-all flex items-center justify-between group"
                    >
                      <span>"Ilustrasi pemandangan gunung berapi estetis bergaya seni vektor retro..."</span>
                      <ArrowRight className="w-3.5 h-3.5 text-white/20 group-hover:translate-x-1 transition-transform" />
                    </button>
                  </>
                )}
                {activeMode === "search" && (
                  <>
                    <button 
                      onClick={() => setInput("Apa berita sains terpenting dan terobosan astrofisika terbaru yang dipublikasikan minggu ini?")}
                      className="w-full p-3 text-xs text-white/60 hover:text-white bg-white/[0.02] hover:bg-white/[0.04] border border-white/5 rounded-xl transition-all flex items-center justify-between group"
                    >
                      <span>"Apa berita sains terpenting dan terobosan astrofisika terbaru minggu ini?"</span>
                      <ArrowRight className="w-3.5 h-3.5 text-white/20 group-hover:translate-x-1 transition-transform" />
                    </button>
                  </>
                )}
                {activeMode === "deep-research" && (
                  <>
                    <button 
                      onClick={() => setInput("Analisis komprehensif tentang dampak fusi nuklir sebagai sumber energi bersih global masa depan")}
                      className="w-full p-3 text-xs text-white/60 hover:text-white bg-white/[0.02] hover:bg-white/[0.04] border border-white/5 rounded-xl transition-all flex items-center justify-between group"
                    >
                      <span>"Analisis komprehensif tentang fusi nuklir sebagai sumber energi bersih global..."</span>
                      <ArrowRight className="w-3.5 h-3.5 text-white/20 group-hover:translate-x-1 transition-transform" />
                    </button>
                  </>
                )}
              </div>
            </div>
          ) : (
            /* Render active conversation chat history bubble */
            <div className="max-w-4xl mx-auto space-y-6">
              {messages.map((msg, mIdx) => {
                const isUser = msg.sender === "user";
                return (
                  <div 
                    key={mIdx} 
                    className={`flex gap-4 ${isUser ? "justify-end" : "justify-start"}`}
                  >
                    {/* Bot Avatar Icon */}
                    {!isUser && (
                      <div className="w-8 h-8 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 flex items-center justify-center shrink-0 shadow-inner">
                        <Bot className="w-4 h-4" />
                      </div>
                    )}

                    <div className="max-w-[85%] space-y-1">
                      {/* Name tag and timestamp */}
                      <div className={`flex items-center gap-1.5 text-[10px] text-white/30 font-mono ${isUser ? "justify-end" : "justify-start"}`}>
                        <span className="font-bold text-white/50">{isUser ? userProfile.name : "Nexon AI"}</span>
                        <span>&bull;</span>
                        <span>{msg.timestamp || "Tadi"}</span>
                      </div>

                      {/* Bubble */}
                      <div 
                        className={`p-4 rounded-2xl border text-sm shadow-md transition-all
                          ${isUser 
                            ? "bg-indigo-600/10 border-indigo-500/20 text-white/90 rounded-tr-none" 
                            : "bg-[#121215] border-white/5 text-white/80 rounded-tl-none"}`}
                      >
                        {/* Display message based on payload type */}
                        {msg.mimeType && msg.mimeType.startsWith("image/") ? (
                          /* Image Canvas generated output */
                          <div className="space-y-3">
                            <div className="relative group border border-white/5 rounded-xl overflow-hidden bg-black/40">
                              {msg.isFallback ? (
                                /* SVG Vector Inline Rendering */
                                <div 
                                  className="w-full flex items-center justify-center p-6 bg-[#0c0c0e] overflow-auto max-h-[400px]"
                                  dangerouslySetInnerHTML={{ __html: msg.data || "" }}
                                />
                              ) : (
                                /* Normal PNG/JPEG Base64 Image */
                                <img 
                                  src={`data:${msg.mimeType};base64,${msg.data}`} 
                                  alt="Canvas Generated" 
                                  className="w-full h-auto object-contain max-h-[400px]"
                                  referrerPolicy="no-referrer"
                                />
                              )}
                              
                              {/* Hover overlay with visual tools */}
                              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
                                <button 
                                  onClick={() => {
                                    if (msg.isFallback) {
                                      navigator.clipboard.writeText(msg.data || "");
                                      onAddNotification("SVG Disalin", "Kode markup XML SVG berhasil disimpan ke papan klip.");
                                    } else {
                                      onAddNotification("Fitur Download", "Menyiapkan pengunduhan berkas gambar.");
                                    }
                                  }}
                                  className="p-2.5 bg-white/10 hover:bg-white text-white hover:text-black rounded-xl transition-all cursor-pointer"
                                  title={msg.isFallback ? "Salin Kode SVG" : "Unduh Gambar"}
                                >
                                  {msg.isFallback ? <Copy className="w-4 h-4" /> : <Download className="w-4 h-4" />}
                                </button>
                                {msg.isFallback && (
                                  <button 
                                    onClick={() => setZoomedSvg(msg.data || null)}
                                    className="p-2.5 bg-white/10 hover:bg-white text-white hover:text-black rounded-xl transition-all cursor-pointer"
                                    title="Perbesar Layar"
                                  >
                                    <Maximize2 className="w-4 h-4" />
                                  </button>
                                )}
                              </div>
                            </div>
                            <p className="text-white/80 leading-relaxed">{msg.text}</p>
                            {msg.isFallback && (
                              <div className="p-3 bg-indigo-500/5 rounded-xl border border-indigo-500/10 flex items-center gap-2.5 text-[11px] text-indigo-350">
                                <Sparkles className="w-4 h-4" />
                                <span><strong>Mode Desain Vektor Aktif:</strong> Format ilustrasi di atas murni merupakan grafik vektor SVG cerdas yang responsif tanpa pecah piksel.</span>
                              </div>
                            )}
                          </div>
                        ) : (
                          /* Text response with custom markdown formatting */
                          <div className="prose prose-invert max-w-none text-left">
                            {formatMessageText(msg.text)}
                          </div>
                        )}

                        {/* Search grounded citations */}
                        {msg.sources && msg.sources.length > 0 && (
                          <div className="mt-4 pt-4 border-t border-white/5 space-y-2 text-left">
                            <span className="text-[10px] font-bold font-mono tracking-wider text-white/30 uppercase flex items-center gap-1.5">
                              <Globe className="w-3.5 h-3.5 text-sky-400" />
                              <span>Sumber Terkait & Referensi ({msg.sources.length})</span>
                            </span>
                            <div className="flex flex-wrap gap-2">
                              {msg.sources.map((src, sIdx) => (
                                <a 
                                  key={sIdx}
                                  href={src.uri} 
                                  target="_blank" 
                                  rel="noopener noreferrer"
                                  className="inline-flex items-center gap-1 bg-white/[0.03] hover:bg-[#1f2937] border border-white/5 px-2.5 py-1 rounded-lg text-[10px] text-white/60 hover:text-white transition-all cursor-pointer"
                                >
                                  <span>{src.title}</span>
                                  <ExternalLink className="w-2.5 h-2.5" />
                                </a>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* User Avatar Icon */}
                    {isUser && (
                      <div className="w-8 h-8 rounded-xl bg-indigo-600/10 text-indigo-300 border border-indigo-500/25 flex items-center justify-center shrink-0 shadow-inner">
                        <UserIcon className="w-4 h-4" />
                      </div>
                    )}
                  </div>
                );
              })}

              {/* Show simulated thinking logs during Deep Research */}
              {isGenerating && activeMode === "deep-research" && currentThinkingLogs.length > 0 && (
                <div className="flex gap-4 justify-start animate-fadeIn">
                  <div className="w-8 h-8 rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20 flex items-center justify-center shrink-0">
                    <Loader2 className="w-4 h-4 animate-spin" />
                  </div>
                  <div className="max-w-[85%] space-y-1 text-left w-full">
                    <div className="text-[10px] text-white/30 font-mono">
                      <span>Proses Riset Otonom</span>
                    </div>
                    <div className="bg-[#121215] border border-white/5 p-4 rounded-2xl rounded-tl-none space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold font-mono text-purple-400 flex items-center gap-1.5">
                          <Brain className="w-3.5 h-3.5 animate-pulse" />
                          <span>LOG ANALISIS OTONOM</span>
                        </span>
                        <button 
                          onClick={() => setIsThinkingLogsExpanded(!isThinkingLogsExpanded)}
                          className="p-1 hover:bg-white/5 rounded text-white/40 hover:text-white cursor-pointer"
                        >
                          {isThinkingLogsExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                        </button>
                      </div>

                      {isThinkingLogsExpanded && (
                        <div className="space-y-1.5 pl-1.5 border-l border-white/5 font-mono text-[11px] text-white/60">
                          {currentThinkingLogs.map((log, lIdx) => (
                            <div key={lIdx} className="flex items-start gap-2">
                              {lIdx === currentThinkingLogs.length - 1 ? (
                                <Loader2 className="w-3.5 h-3.5 text-purple-400 animate-spin shrink-0 mt-0.5" />
                              ) : (
                                <Check className="w-3.5 h-3.5 text-green-400 shrink-0 mt-0.5" />
                              )}
                              <span>{log}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* Standard loader */}
              {isGenerating && activeMode !== "deep-research" && (
                <div className="flex gap-4 justify-start">
                  <div className="w-8 h-8 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 flex items-center justify-center shrink-0 shadow-inner">
                    <Loader2 className="w-4 h-4 animate-spin" />
                  </div>
                  <div className="bg-[#121215] border border-white/5 p-4 rounded-2xl rounded-tl-none shadow flex items-center gap-2">
                    <span className="text-xs text-white/50 tracking-wider font-mono animate-pulse uppercase">Nexon AI sedang menganalisis respon terbaik...</span>
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* INPUT INPUT BOX CONTROLLER */}
        <div className="p-4 bg-[#121215]/80 backdrop-blur-md border-t border-white/5 shrink-0">
          <form onSubmit={handleSubmit} className="max-w-4xl mx-auto space-y-3">
            
            {/* Context Panel Settings depending on active mode */}
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
              
              <div className="flex items-center gap-2.5">
                {/* Mode label chip */}
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 font-bold font-mono text-[10px] uppercase text-white/80">
                  {activeMode === "chat" && <MessageSquare className="w-3.5 h-3.5 text-indigo-400" />}
                  {activeMode === "code" && <Code className="w-3.5 h-3.5 text-green-400" />}
                  {activeMode === "canvas" && <Image className="w-3.5 h-3.5 text-pink-400" />}
                  {activeMode === "search" && <Search className="w-3.5 h-3.5 text-sky-400" />}
                  {activeMode === "deep-research" && <Brain className="w-3.5 h-3.5 text-purple-400" />}
                  <span>{activeMode} MODE</span>
                </span>

                {/* Aspect Ratio selector — shown only in Canvas mode */}
                {activeMode === "canvas" && (
                  <div className="flex items-center gap-1.5">
                    <span className="text-white/40 font-mono text-[10px]">Aspek Gambar:</span>
                    <select 
                      value={aspectRatio} 
                      onChange={(e) => setAspectRatio(e.target.value)}
                      className="bg-white/5 border border-white/10 rounded-lg px-2 py-0.5 text-xs text-white/80 font-mono focus:border-indigo-500 cursor-pointer outline-none"
                    >
                      <option value="1:1" className="bg-[#121215]">1:1 (Kotak)</option>
                      <option value="16:9" className="bg-[#121215]">16:9 (Landscape)</option>
                      <option value="9:16" className="bg-[#121215]">9:16 (Vertikal)</option>
                      <option value="3:4" className="bg-[#121215]">3:4 (Portrait)</option>
                      <option value="4:3" className="bg-[#121215]">4:3 (Klasik)</option>
                    </select>
                  </div>
                )}

                {/* Programming Language selector — shown only in Code mode */}
                {activeMode === "code" && (
                  <div className="flex items-center gap-1.5">
                    <span className="text-white/40 font-mono text-[10px]">Bahasa:</span>
                    <select 
                      value={selectedLanguage} 
                      onChange={(e) => setSelectedLanguage(e.target.value)}
                      className="bg-white/5 border border-white/10 rounded-lg px-2 py-0.5 text-xs text-white/80 font-mono focus:border-indigo-500 cursor-pointer outline-none"
                    >
                      <option value="Javascript" className="bg-[#121215]">Javascript</option>
                      <option value="Typescript" className="bg-[#121215]">Typescript</option>
                      <option value="Python" className="bg-[#121215]">Python</option>
                      <option value="HTML/CSS" className="bg-[#121215]">HTML/CSS</option>
                      <option value="Java" className="bg-[#121215]">Java</option>
                      <option value="C++" className="bg-[#121215]">C++</option>
                      <option value="Go" className="bg-[#121215]">Go</option>
                      <option value="Rust" className="bg-[#121215]">Rust</option>
                    </select>
                  </div>
                )}
              </div>

              {/* Status messages indicator */}
              <div className="text-[10px] text-white/30 font-mono">
                Batas ukuran file 8MB &bull; Didukung API Gemini Cerdas
              </div>
            </div>

            {/* Visual indicator for attached file */}
            {attachedFile && (
              <div className="p-2 bg-[#1b1b22] border border-white/5 rounded-xl flex items-center justify-between gap-3 animate-slideIn">
                <div className="flex items-center gap-2 min-w-0">
                  <div className="p-1.5 bg-indigo-500/10 rounded-lg text-indigo-400">
                    <FileText className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <span className="text-xs text-white/80 font-bold block truncate">{attachedFile.name}</span>
                    <span className="text-[9px] text-white/40 font-mono block">{(attachedFile.size / 1024).toFixed(1)} KB &bull; {attachedFile.mimeType}</span>
                  </div>
                </div>
                <button 
                  type="button"
                  onClick={removeAttachedFile}
                  className="p-1 text-white/30 hover:text-white rounded-lg hover:bg-white/5 cursor-pointer"
                  title="Hapus berkas"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Expandable input box container */}
            <div className="relative flex items-center bg-[#1a1a20] border border-white/5 hover:border-indigo-500/35 rounded-2xl p-2 transition-all">
              
              {/* Attachment Button */}
              {activeMode === "chat" && (
                <button 
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="p-2.5 hover:bg-white/5 rounded-xl text-white/60 hover:text-indigo-400 transition-colors cursor-pointer"
                  title="Lampirkan Dokumen/Gambar"
                >
                  <Paperclip className="w-4 h-4" />
                </button>
              )}
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleFileChange} 
                className="hidden" 
                accept="image/*,application/pdf,text/plain"
              />

              {/* Text input area */}
              <textarea 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={
                  activeMode === "canvas" 
                    ? "Lukis deskripsi gambar Anda di sini..." 
                    : activeMode === "deep-research" 
                    ? "Tulis pertanyaan topik riset mendalam..." 
                    : "Ketik pesan Anda ke Nexon AI..."
                }
                rows={1}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    handleSubmit(e);
                  }
                }}
                className="flex-1 max-h-36 resize-none bg-transparent border-0 outline-none text-xs text-white/95 px-3 py-2 placeholder-white/20"
              />

              {/* Send Button */}
              <button 
                type="submit"
                disabled={isGenerating || (!input.trim() && !attachedFile)}
                className={`p-2.5 rounded-xl transition-all flex items-center justify-center cursor-pointer shadow-md
                  ${(input.trim() || attachedFile) && !isGenerating 
                    ? "bg-indigo-600 text-white hover:bg-indigo-550 shadow-indigo-600/20" 
                    : "bg-white/[0.02] text-white/20 cursor-not-allowed"}`}
              >
                {isGenerating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              </button>
            </div>
          </form>
        </div>
      </main>

      {/* FULLSCREEN SVG ZOOM MODAL */}
      {zoomedSvg && (
        <div className="fixed inset-0 bg-black/95 backdrop-blur-md z-50 flex flex-col justify-between p-4 font-sans animate-fadeIn">
          <div className="flex items-center justify-between px-4 py-2 border-b border-white/5 text-white">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold font-mono text-pink-400 uppercase">PRATINJAU VEKTOR PENUH</span>
            </div>
            <button 
              onClick={() => setZoomedSvg(null)}
              className="p-2 hover:bg-white/5 rounded-xl text-white/60 hover:text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div 
            className="flex-1 flex items-center justify-center p-6 overflow-auto max-h-[80vh]"
            dangerouslySetInnerHTML={{ __html: zoomedSvg }}
          />

          <div className="flex items-center justify-center gap-3 py-4">
            <button 
              onClick={() => {
                navigator.clipboard.writeText(zoomedSvg);
                onAddNotification("SVG Disalin", "Kode markup XML SVG berhasil disimpan ke papan klip.");
              }}
              className="px-4 py-2 bg-indigo-500 hover:bg-indigo-600 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shadow-lg shadow-indigo-500/10"
            >
              <Copy className="w-4 h-4" />
              <span>Salin Kode SVG</span>
            </button>
            <button 
              onClick={() => {
                // Download SVG file
                const blob = new Blob([zoomedSvg], { type: "image/svg+xml" });
                const url = URL.createObjectURL(blob);
                const a = document.createElement("a");
                a.href = url;
                a.download = `nexon_canvas_${Date.now()}.svg`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
                onAddNotification("SVG Diunduh", "Berkas vektor SVG berhasil diunduh.");
              }}
              className="px-4 py-2 bg-white/10 hover:bg-white hover:text-black text-white rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer border border-white/5"
            >
              <Download className="w-4 h-4" />
              <span>Unduh Berkas</span>
            </button>
          </div>
        </div>
      )}

      {/* USER PROFILE MODAL */}
      {isProfileModalOpen && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-[#121215] border border-white/5 rounded-2xl w-full max-w-md p-6 space-y-4 animate-slideIn">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <span className="text-sm font-bold text-white flex items-center gap-1.5">
                <Settings className="w-4 h-4 text-indigo-400" />
                <span>Pengaturan Profil Personal</span>
              </span>
              <button 
                onClick={() => setIsProfileModalOpen(false)}
                className="p-1 hover:bg-white/5 rounded text-white/50 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="space-y-1">
                <label className="text-white/40 block font-mono">Nama Pengguna</label>
                <input 
                  type="text" 
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full bg-[#1a1a20] border border-white/5 rounded-xl px-3 py-2.5 text-white/90 outline-none focus:border-indigo-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-white/40 block font-mono">Peran / Jabatan</label>
                <input 
                  type="text" 
                  value={editRole}
                  onChange={(e) => setEditRole(e.target.value)}
                  className="w-full bg-[#1a1a20] border border-white/5 rounded-xl px-3 py-2.5 text-white/90 outline-none focus:border-indigo-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-white/40 block font-mono">Tingkat / Kelas</label>
                <input 
                  type="text" 
                  value={editGrade}
                  onChange={(e) => setEditGrade(e.target.value)}
                  className="w-full bg-[#1a1a20] border border-white/5 rounded-xl px-3 py-2.5 text-white/90 outline-none focus:border-indigo-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-white/40 block font-mono">Nama Lembaga / Sekolah</label>
                <input 
                  type="text" 
                  value={editSchool}
                  onChange={(e) => setEditSchool(e.target.value)}
                  className="w-full bg-[#1a1a20] border border-white/5 rounded-xl px-3 py-2.5 text-white/90 outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <div className="flex items-center gap-3 pt-4 border-t border-white/5">
              <button 
                type="button"
                onClick={() => setIsProfileModalOpen(false)}
                className="flex-1 py-2 bg-white/5 hover:bg-white/10 border border-white/5 text-white/80 rounded-xl text-xs font-bold transition-all cursor-pointer"
              >
                Batal
              </button>
              <button 
                type="button"
                onClick={handleProfileSave}
                className="flex-1 py-2 bg-indigo-600 hover:bg-indigo-550 text-white rounded-xl text-xs font-bold transition-all cursor-pointer shadow-md shadow-indigo-600/20"
              >
                Simpan Profil
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
