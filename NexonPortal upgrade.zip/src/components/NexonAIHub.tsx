import React from "react";
import { Sparkles } from "lucide-react";
import NexonAiMain from "./nexonai/NexonAiMain";

interface NexonAIHubProps {
  userProfile: {
    name: string;
    role: string;
    grade: string;
    school: string;
    nexonAiUrl?: string;
  };
  onSaveProfile: React.Dispatch<React.SetStateAction<{
    name: string;
    role: string;
    grade: string;
    school: string;
    nexonAiUrl?: string;
  }>>;
  onAddNotification: (title: string, msg: string) => void;
  userId: string;
}

export default function NexonAIHub({ userProfile, onSaveProfile, onAddNotification, userId }: NexonAIHubProps) {
  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12 animate-fadeIn" id="nexon_ai_hub_section">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-white/[0.06] pb-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <Sparkles className="w-5.5 h-5.5 text-purple-400 animate-pulse" />
            Nexon AI Workspace
          </h1>
          <p className="text-white/40 text-[11px] sm:text-xs">
            Asisten kecerdasan buatan serbaguna lokal dengan model Chat, Code, Canvas, dan video sinematik.
          </p>
        </div>
      </div>

      {/* Main Integrated Workspace */}
      <div className="rounded-2xl border border-white/[0.06] overflow-hidden bg-[#191919] min-h-[600px] h-[calc(100vh-180px)] max-h-[800px] shadow-2xl relative">
        <NexonAiMain />
      </div>

    </div>
  );
}
