import React, { useState, useEffect } from "react";
import { ChatSession, AIMode } from "./types";
import { Plus, MessageSquare, Code2, Trash2, ChevronLeft, Brain } from "lucide-react";
import { auth } from "../../lib/firebase";
import { User as FirebaseUser } from "firebase/auth";

interface SidebarProps {
  sessions: ChatSession[];
  activeSessionId: string | null;
  onSelectSession: (id: string) => void;
  onNewSession: (mode?: AIMode) => void;
  onDeleteSession: (id: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

export default function Sidebar({
  sessions,
  activeSessionId,
  onSelectSession,
  onNewSession,
  onDeleteSession,
  isOpen,
  onClose,
}: SidebarProps) {
  const [user, setUser] = useState<FirebaseUser | null>(null);

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((u) => {
      setUser(u);
    });
    return () => unsubscribe();
  }, []);

  // Helpers to fetch correct icon for session modes
  const getSessionIcon = (mode: AIMode) => {
    switch (mode) {
      case "code":
        return <Code2 className="w-4 h-4 text-emerald-400" />;
      default:
        return <MessageSquare className="w-4 h-4 text-blue-400" />;
    }
  };

  return (
    <div
      id="sidebar-container"
      className={`fixed inset-y-0 left-0 z-50 w-72 bg-[#141414] border-r border-[#222222]/50 flex flex-col transition-transform duration-300 transform lg:translate-x-0 ${
        isOpen ? "translate-x-0" : "-translate-x-full"
      }`}
    >
      {/* Header/Brand */}
      <div className="p-4 border-b border-[#222222]/50 flex items-center justify-between select-none">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-[#E08462] flex items-center justify-center border border-[#E08462]/20 text-[#141414] font-display font-bold text-sm shadow-md shadow-[#E08462]/10">
            N
          </div>
          <div>
            <span className="font-display font-semibold text-[#ECE6DC] text-sm tracking-wider">
              NEXONAI
            </span>
            <span className="text-[8px] font-mono font-medium text-[#E08462] block -mt-0.5 uppercase tracking-widest">
              WORKSPACE
            </span>
          </div>
        </div>

        {/* Mobile close button */}
        <button
          id="close-sidebar-btn"
          onClick={onClose}
          className="lg:hidden p-1.5 rounded-lg hover:bg-[#222222] text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>
      </div>

      {/* New Session Action */}
      <div className="p-4">
        <button
          id="new-chat-btn"
          onClick={() => {
            onNewSession("chat");
            onClose();
          }}
          className="w-full py-2 px-4 rounded-xl bg-[#222222] hover:bg-[#282828] border border-[#2d2d2d]/80 text-[#ECE6DC] font-medium text-xs flex items-center justify-center gap-2 transition-all hover:scale-[1.01] hover:border-[#3d3d3d] active:scale-[0.99] group cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5 text-[#E08462] group-hover:rotate-90 transition-transform duration-200" />
          Sesi Baru
        </button>
      </div>

      {/* History List */}
      <div className="flex-1 overflow-y-auto px-3 py-2 space-y-1">
        <div className="px-3 py-1.5 text-[10px] font-semibold text-slate-500 uppercase tracking-widest font-display select-none">
          Riwayat Aktivitas
        </div>

        {sessions.length === 0 ? (
          <div className="text-center py-8 px-4 text-xs text-slate-500 italic font-light select-none">
            Belum ada sesi percakapan. Mulai sekarang untuk menyimpan riwayat Anda.
          </div>
        ) : (
          sessions.map((session) => {
            const isActive = session.id === activeSessionId;
            return (
              <div
                key={session.id}
                className={`group relative flex items-center justify-between rounded-xl p-3 transition-all ${
                  isActive
                    ? "bg-[#222222] border border-[#2D2D2D] text-[#ECE6DC] font-medium shadow-inner pl-4"
                    : "text-[#9D9D9D] hover:bg-[#1c1c1c] hover:text-[#ECE6DC]"
                }`}
              >
                {/* Brand color sidebar active notch indicator */}
                {isActive && (
                  <div className="absolute left-0 top-3 bottom-3 w-1 bg-[#E08462] rounded-r-full"></div>
                )}
                <button
                  id={`session-item-${session.id}`}
                  onClick={() => {
                    onSelectSession(session.id);
                    onClose();
                  }}
                  className="flex items-center gap-2.5 flex-1 min-w-0 text-left pr-8 cursor-pointer"
                >
                  <div className="shrink-0">{getSessionIcon(session.mode)}</div>
                  <div className="min-w-0 flex-1">
                    <p className="text-xs truncate font-light leading-snug">
                      {session.title || "Percakapan Baru"}
                    </p>
                    <span className="text-[9px] font-mono text-[#777777] block font-light">
                      {session.createdAt}
                    </span>
                  </div>
                </button>

                {/* Delete button */}
                <button
                  id={`delete-session-${session.id}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    e.preventDefault();
                    onDeleteSession(session.id);
                  }}
                  className="absolute right-2 z-20 opacity-100 lg:opacity-0 lg:group-hover:opacity-100 p-1.5 rounded-lg bg-[#1C1C1C] hover:bg-red-950/40 text-[#777777] hover:text-red-400 transition-all border border-[#2D2D2D]/60 cursor-pointer"
                  title="Hapus Sesi"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })
        )}
      </div>

      {/* User Status Footer */}
      {user && (
        <div className="p-4 border-t border-[#222222]/50 bg-[#191919]/50 flex items-center gap-3 select-none">
          <div className="w-8 h-8 rounded-full bg-[#E08462]/10 border border-[#E08462]/20 flex items-center justify-center font-bold text-[#E08462] text-sm">
            {user.displayName ? user.displayName.charAt(0).toUpperCase() : user.email?.charAt(0).toUpperCase() || "U"}
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-xs font-semibold text-[#ECE6DC] truncate leading-tight">
              {user.displayName || "Nexon User"}
            </p>
            <p className="text-[10px] text-slate-500 truncate mt-0.5">
              {user.email}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
