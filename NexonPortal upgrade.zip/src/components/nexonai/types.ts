export type AIMode = "chat" | "code" | "canvas" | "video";
export type ThinkingLevelType = "high" | "medium" | "normal";

export interface SourceLink {
  title: string;
  url: string;
}

export interface Message {
  id: string;
  sender: "user" | "assistant";
  text: string;
  timestamp: string;
  imageUrl?: string;
  videoUrl?: string;
  sources?: SourceLink[];
  isGenerating?: boolean;
  modelUsed?: string;
  error?: string;
}

export interface ChatSession {
  id: string;
  title: string;
  createdAt: string;
  messages: Message[];
  mode: AIMode;
  thinking: ThinkingLevelType;
  search: boolean;
  deepResearch: boolean;
  canvasModel?: "nano-banana" | "nano-banana-pro";
  videoModel?: "veo-lite" | "veo-pro";
}
