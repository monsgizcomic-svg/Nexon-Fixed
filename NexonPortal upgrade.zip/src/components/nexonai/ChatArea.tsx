import React, { useRef, useEffect, useState } from "react";
import { ChatSession, AIMode, ThinkingLevelType } from "./types";
import MessageItem from "./MessageItem";
import WelcomeScreen from "./WelcomeScreen";
import { 
  Menu, 
  Send, 
  Sparkles, 
  Brain, 
  Trash2, 
  Globe, 
  Plus, 
  X, 
  ChevronDown,
  Mic,
  AudioLines
} from "lucide-react";

interface ChatAreaProps {
  session: ChatSession | null;
  onSendMessage: (text: string) => void;
  onQuickStart: (mode: AIMode, initialPrompt?: string) => void;
  onClearSessionMessages: () => void;
  onToggleSidebar: () => void;
  
  // Controls callbacks passed to App state
  onChangeMode: (mode: AIMode) => void;
  onChangeThinking: (level: ThinkingLevelType) => void;
  onToggleSearch: () => void;
  onToggleDeepResearch: () => void;
}

export default function ChatArea({
  session,
  onSendMessage,
  onQuickStart,
  onClearSessionMessages,
  onToggleSidebar,
  onChangeMode,
  onChangeThinking,
  onToggleSearch,
  onToggleDeepResearch,
}: ChatAreaProps) {
  const [inputText, setInputText] = useState("");
  const [isModelMenuOpen, setIsModelMenuOpen] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [session?.messages, session?.messages?.length]);

  const handleSend = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim()) return;
    onSendMessage(inputText.trim());
    setInputText("");
    setIsModelMenuOpen(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const isGenerating = session?.messages.some((m) => m.isGenerating) || false;

  // Get active model display name for the pill button
  const getModelDisplayName = () => {
    if (!session) return "NexonAi 3.5";
    let name = "NexonAi 3.5";
    if (session.mode === "code") {
      name = "NexonAi 3.5 Programmer";
    } else if (session.mode === "canvas") {
      name = "NexonAi Canvas Studio";
    } else if (session.mode === "video") {
      name = "NexonAi Veo Video";
    } else if (session.deepResearch) {
      name = "NexonAi 3.5 Deep Research";
    } else if (session.search) {
      name = "NexonAi 3.5 Search";
    } else if (session.thinking === "high") {
      name = "NexonAi 3.5 Ultra Pemikiran";
    } else if (session.thinking === "medium") {
      name = "NexonAi 3.5 Medium Pemikiran";
    } else {
      name = "NexonAi 3.5 Pemikiran";
    }
    return name;
  };

  return (
    <div id="chat-area" className="flex-1 flex flex-col h-full bg-[#191919] relative overflow-hidden text-[#ECE6DC]">
      
      {/* 1. Transparent Premium Header/Toolbar */}
      <div className="h-16 px-6 flex items-center justify-between shrink-0 z-30 select-none bg-gradient-to-b from-[#141414]/80 to-transparent border-b border-[#222222]/20 backdrop-blur-sm">
        <div className="flex items-center gap-4">
          <button
            id="toggle-sidebar-mobile"
            onClick={onToggleSidebar}
            className="lg:hidden p-2 -ml-2 rounded-full hover:bg-[#2C2C2C] text-[#ECE6DC] transition-colors cursor-pointer"
          >
            <Menu className="w-6 h-6" />
          </button>

          {session && (
            <div className="flex flex-col text-left">
              <span className="text-sm font-semibold text-[#ECE6DC] font-display max-w-[180px] sm:max-w-[320px] md:max-w-[450px] truncate leading-tight">
                {session.title || "Sesi Baru"}
              </span>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#E08462] animate-pulse"></span>
                <span className="text-[9px] font-mono font-medium text-[#9D9D9D] tracking-wider uppercase">
                  {session.mode === "code" ? "Coding Workspace" : session.mode === "canvas" ? "Canvas Painting" : session.mode === "video" ? "Veo Cinema" : "Intelligence Chat"}
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Action icons like Trash */}
        <div className="flex items-center gap-3">
          {session && session.messages.length > 0 && (
            <button
              id="clear-chat-history"
              onClick={onClearSessionMessages}
              className="p-2 rounded-full hover:bg-red-950/20 text-slate-400 hover:text-red-400 transition-colors cursor-pointer"
              title="Bersihkan Percakapan"
            >
              <Trash2 className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>

      {/* 2. Chat Feed or Welcome Screen */}
      <div className="flex-1 overflow-y-auto min-h-0 px-4">
        {!session || session.messages.length === 0 ? (
          <div className="flex items-center justify-center min-h-full py-12">
            <WelcomeScreen onQuickStart={onQuickStart} />
          </div>
        ) : (
          <div className="divide-y divide-slate-800/10 pb-32 max-w-3xl mx-auto">
            {session.messages.map((message) => (
              <MessageItem key={message.id} message={message} />
            ))}
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      {/* 3. Immersive Bottom Input Console */}
      {session && (
        <div className="p-4 bg-gradient-to-t from-[#191919] via-[#191919]/95 to-transparent shrink-0 z-20">
          <div className="max-w-3xl mx-auto relative">
            
            {/* Interactive Model Settings Popover */}
            {isModelMenuOpen && (
              <div className="absolute bottom-[92px] left-4 bg-[#222222] border border-[#2d2d2d] rounded-2xl shadow-2xl p-4 z-50 w-80 text-left space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-200 text-[#ECE6DC]">
                <div className="flex items-center justify-between border-b border-[#2d2d2d] pb-2">
                  <span className="text-xs font-semibold text-[#ECE6DC] uppercase tracking-wider font-mono">Setelan Nexon AI</span>
                  <button onClick={() => setIsModelMenuOpen(false)} className="text-[#777777] hover:text-white cursor-pointer">
                    <X className="w-4 h-4" />
                  </button>
                </div>
                
                {/* Mode Selection */}
                <div className="space-y-2">
                  <label className="text-[10px] uppercase font-bold text-[#8D8D8D] tracking-wide">Mode AI</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        onChangeMode("chat");
                        setIsModelMenuOpen(false);
                      }}
                      className={`px-3 py-2 rounded-xl text-xs font-medium border text-center transition-all cursor-pointer ${
                        session.mode === "chat"
                          ? "bg-[#E08462]/10 text-[#E08462] border-[#E08462]/30 font-semibold"
                          : "bg-[#2C2C2C] text-slate-400 border-transparent hover:text-slate-200"
                      }`}
                    >
                      Chat AI
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        onChangeMode("code");
                        setIsModelMenuOpen(false);
                      }}
                      className={`px-3 py-2 rounded-xl text-xs font-medium border text-center transition-all cursor-pointer ${
                        session.mode === "code"
                          ? "bg-[#E08462]/10 text-[#E08462] border-[#E08462]/30 font-semibold"
                          : "bg-[#2C2C2C] text-slate-400 border-transparent hover:text-slate-200"
                      }`}
                    >
                      Programmer
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        onChangeMode("canvas");
                        setIsModelMenuOpen(false);
                      }}
                      className={`px-3 py-2 rounded-xl text-xs font-medium border text-center transition-all cursor-pointer ${
                        session.mode === "canvas"
                          ? "bg-[#E08462]/10 text-[#E08462] border-[#E08462]/30 font-semibold"
                          : "bg-[#2C2C2C] text-slate-400 border-transparent hover:text-slate-200"
                      }`}
                    >
                      Canvas Painting
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        onChangeMode("video");
                        setIsModelMenuOpen(false);
                      }}
                      className={`px-3 py-2 rounded-xl text-xs font-medium border text-center transition-all cursor-pointer ${
                        session.mode === "video"
                          ? "bg-[#E08462]/10 text-[#E08462] border-[#E08462]/30 font-semibold"
                          : "bg-[#2C2C2C] text-slate-400 border-transparent hover:text-slate-200"
                      }`}
                    >
                      Veo Video Cinema
                    </button>
                  </div>
                </div>

                {/* Additional capabilities */}
                {["chat", "code"].includes(session.mode) && (
                  <div className="space-y-2">
                    <label className="text-[10px] uppercase font-bold text-[#8D8D8D] tracking-wide">Fungsi Tambahan</label>
                    <div className="space-y-1.5">
                      {/* Thinking Toggle */}
                      <div className="flex items-center justify-between p-2 rounded-xl bg-[#2C2C2C] border border-transparent">
                        <div className="flex items-center gap-2">
                          <Brain className="w-3.5 h-3.5 text-[#E08462]" />
                          <span className="text-xs text-slate-200">Thinking Level</span>
                        </div>
                        <select
                          value={session.thinking}
                          onChange={(e) => onChangeThinking(e.target.value as ThinkingLevelType)}
                          className="bg-[#222222] border border-[#2d2d2d] text-xs rounded-lg px-2 py-1 text-slate-300 focus:outline-none cursor-pointer"
                        >
                          <option value="normal">Normal</option>
                          <option value="medium">Medium</option>
                          <option value="high">High</option>
                        </select>
                      </div>

                      {/* Internet Search Toggle */}
                      <button
                        type="button"
                        onClick={onToggleSearch}
                        className={`w-full flex items-center justify-between p-2 rounded-xl border border-transparent transition-colors cursor-pointer ${
                          session.search ? "bg-[#E08462]/10 text-[#E08462] border-[#E08462]/20" : "bg-[#2C2C2C] text-slate-200 hover:bg-[#333333]"
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <Globe className="w-3.5 h-3.5 text-[#E08462]" />
                          <span className="text-xs">Pencarian Web Real-time</span>
                        </div>
                        <div className={`w-7 h-4 rounded-full transition-all flex items-center p-0.5 ${session.search ? "bg-[#E08462] justify-end" : "bg-slate-700 justify-start"}`}>
                          <div className="w-3 h-3 rounded-full bg-white"></div>
                        </div>
                      </button>

                      {/* Deep Research Toggle */}
                      <button
                        type="button"
                        onClick={onToggleDeepResearch}
                        className={`w-full flex items-center justify-between p-2 rounded-xl border border-transparent transition-colors cursor-pointer ${
                          session.deepResearch ? "bg-[#E08462]/10 text-[#E08462] border-[#E08462]/20" : "bg-[#2C2C2C] text-slate-200 hover:bg-[#333333]"
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <Sparkles className="w-3.5 h-3.5 text-[#E08462]" />
                          <span className="text-xs">Deep Research</span>
                        </div>
                        <div className={`w-7 h-4 rounded-full transition-all flex items-center p-0.5 ${session.deepResearch ? "bg-[#E08462] justify-end" : "bg-slate-700 justify-start"}`}>
                          <div className="w-3 h-3 rounded-full bg-white"></div>
                        </div>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Input Form Box */}
            <form onSubmit={handleSend} className="relative rounded-2xl bg-[#222222] border border-[#2d2d2d]/80 shadow-2xl p-2.5 flex flex-col gap-2 transition-all focus-within:border-[#3a3a3a]">
              
              {/* Text Input area */}
              <div className="relative px-1">
                <textarea
                  id="chat-input-textarea"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder={
                    session.mode === "code"
                      ? "Ketik masalah pemrograman..."
                      : session.mode === "canvas"
                      ? "Ketik imajinasi lukisan gambar Anda..."
                      : session.mode === "video"
                      ? "Ketik deskripsi video sinematik..."
                      : "Ketik pesan ke NexonAi..."
                  }
                  rows={1}
                  disabled={isGenerating}
                  className="w-full bg-transparent border-0 ring-0 focus:ring-0 focus:outline-none text-[#ECE6DC] placeholder-[#757575] text-[14px] md:text-base resize-none py-1 leading-relaxed"
                />
              </div>

              {/* Bottom Action bar */}
              <div className="flex items-center justify-between">
                {/* Left side actions: Plus & Dynamic interactive active model pill */}
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setIsModelMenuOpen(!isModelMenuOpen)}
                    title="Ubah Mode & Setelan"
                    className="w-[34px] h-[34px] rounded-full bg-[#2C2C2C] hover:bg-[#333333] border border-transparent transition-colors flex items-center justify-center text-[#ECE6DC] cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                  </button>

                  {/* Active model pill displaying active settings */}
                  <button
                    type="button"
                    onClick={() => setIsModelMenuOpen(!isModelMenuOpen)}
                    className="h-[34px] px-3.5 rounded-full bg-[#2C2C2C] hover:bg-[#333333] border border-transparent flex items-center gap-2 text-[11px] font-medium text-[#ECE6DC] transition-all select-none cursor-pointer"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-[#E08462] animate-pulse"></span>
                    <span>{getModelDisplayName()}</span>
                    <ChevronDown className={`w-3 h-3 text-slate-400 transition-transform ${isModelMenuOpen ? "rotate-180" : ""}`} />
                  </button>
                </div>

                {/* Right side actions: Mic & Voice line or Send button */}
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    title="Gunakan Suara"
                    className="w-[34px] h-[34px] rounded-full bg-[#2C2C2C] hover:bg-[#333333] border border-transparent transition-colors flex items-center justify-center text-[#ECE6DC] cursor-pointer"
                  >
                    <Mic className="w-4 h-4" />
                  </button>

                  {inputText.trim() ? (
                    <button
                      id="submit-message-btn"
                      type="submit"
                      disabled={isGenerating}
                      className="w-[34px] h-[34px] rounded-full bg-[#ECE6DC] hover:bg-[#f5ebd8] text-[#191919] transition-colors flex items-center justify-center font-bold cursor-pointer"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  ) : (
                    <button
                      type="button"
                      title="Audio Wave"
                      className="w-[34px] h-[34px] rounded-full bg-[#ECE6DC]/90 hover:bg-[#ECE6DC] text-[#191919] transition-colors flex items-center justify-center font-bold cursor-pointer"
                    >
                      <AudioLines className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>

            </form>

          </div>
        </div>
      )}
    </div>
  );
}
