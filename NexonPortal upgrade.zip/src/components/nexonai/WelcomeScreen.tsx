import React from "react";
import { MessageSquare, Code2, Globe, Sparkles, ArrowUpRight, Brain } from "lucide-react";
import { AIMode } from "./types";

interface WelcomeScreenProps {
  onQuickStart?: (mode: AIMode, initialPrompt?: string) => void;
}

export default function WelcomeScreen({ onQuickStart }: WelcomeScreenProps) {
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour >= 4 && hour < 11) {
      return "Selamat pagi";
    } else if (hour >= 11 && hour < 15) {
      return "Selamat siang";
    } else if (hour >= 15 && hour < 18) {
      return "Selamat sore";
    } else {
      return "Selamat malam";
    }
  };

  const starterSuggestions = [
    {
      title: "Asisten Chat",
      desc: "Diskusi ide kreatif, terjemahkan bahasa, atau sekadar bertukar pikiran.",
      icon: MessageSquare,
      color: "from-blue-500/10 to-indigo-500/10 border-blue-500/20 text-blue-400 hover:border-blue-500/40",
      iconColor: "text-blue-400 bg-blue-500/10",
      prompt: "Mari bertukar pikiran tentang strategi pemasaran produk digital baru berbasis AI.",
      mode: "chat" as AIMode,
    },
    {
      title: "AI Programmer",
      desc: "Tulis fungsi, cari kutu (debugging), atau pelajari konsep algoritma baru.",
      icon: Code2,
      color: "from-emerald-500/10 to-teal-500/10 border-emerald-500/20 text-emerald-400 hover:border-emerald-500/40",
      iconColor: "text-emerald-400 bg-emerald-500/10",
      prompt: "Buat fungsi TypeScript untuk memvalidasi alamat email dan jelaskan cara kerjanya.",
      mode: "code" as AIMode,
    },
    {
      title: "Pencarian Web",
      desc: "Temukan fakta terbaru dan ringkasan informasi langsung dari internet global.",
      icon: Globe,
      color: "from-[#E08462]/10 to-orange-500/10 border-[#E08462]/20 text-[#E08462] hover:border-[#E08462]/40",
      iconColor: "text-[#E08462] bg-[#E08462]/10",
      prompt: "Beri tahu saya berita teknologi terbaru hari ini dan ringkas poin pentingnya.",
      mode: "chat" as AIMode,
      isSearch: true,
    },
    {
      title: "Deep Research",
      desc: "Analisis mendalam multi-langkah untuk investigasi topik kompleks secara menyeluruh.",
      icon: Sparkles,
      color: "from-purple-500/10 to-fuchsia-500/10 border-purple-500/20 text-purple-400 hover:border-purple-500/40",
      iconColor: "text-purple-400 bg-purple-500/10",
      prompt: "Lakukan riset mendalam mengenai perkembangan teknologi kuantum saat ini beserta tantangannya.",
      mode: "chat" as AIMode,
      isDeepResearch: true,
    },
  ];

  return (
    <div id="welcome-screen" className="flex flex-col items-center justify-center max-w-4xl w-full mx-auto text-center py-8 md:py-16 px-4 select-none">
      
      {/* Brand Icon Badge */}
      <div className="mb-6 inline-flex items-center gap-2.5 px-4 py-2 rounded-full bg-[#222222]/80 border border-[#2d2d2d] text-xs font-semibold text-[#E08462] font-mono tracking-wider uppercase animate-fade-in">
        <Brain className="w-4 h-4 animate-pulse text-[#E08462]" />
        NexonAi Intelligence Workspace
      </div>

      {/* Hero Headline */}
      <div className="space-y-3 mb-12">
        <h1 className="font-sans text-4xl md:text-5xl font-bold tracking-tight text-[#ECE6DC] leading-tight select-text">
          {getGreeting()}, <span className="text-[#E08462]">NexonAi</span>
        </h1>
        <p className="text-[#9D9D9D] text-sm md:text-base font-light max-w-lg mx-auto leading-relaxed">
          Bagaimana saya bisa membantu produktivitas Anda hari ini? Pilih salah satu opsi di bawah untuk langsung mulai.
        </p>
      </div>

      {/* Suggestions Bento-like Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full text-left">
        {starterSuggestions.map((item, idx) => {
          const IconComponent = item.icon;
          return (
            <button
              key={idx}
              onClick={() => {
                if (onQuickStart) {
                  onQuickStart(item.mode, item.prompt);
                }
              }}
              className={`p-5 rounded-2xl bg-gradient-to-br ${item.color} border flex items-start gap-4 transition-all duration-300 hover:scale-[1.01] hover:shadow-xl hover:shadow-[#141414] active:scale-[0.99] group text-left cursor-pointer`}
            >
              <div className={`p-3 rounded-xl ${item.iconColor} shrink-0 transition-all duration-300 group-hover:scale-110`}>
                <IconComponent className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0 space-y-1">
                <div className="flex items-center gap-1.5 font-bold text-[#ECE6DC] text-sm md:text-base">
                  <span>{item.title}</span>
                  <ArrowUpRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all text-[#E08462]" />
                </div>
                <p className="text-[#777777] text-xs leading-relaxed font-light">
                  {item.desc}
                </p>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
