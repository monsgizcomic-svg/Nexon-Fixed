import React, { useState } from "react";
import { Message } from "./types";
import { Copy, Check, Terminal, ExternalLink, Globe, Film, AlertCircle } from "lucide-react";

interface MessageItemProps {
  key?: string;
  message: Message;
}

export default function MessageItem({ message }: MessageItemProps) {
  const isAssistant = message.sender === "assistant";
  const [copiedCodeId, setCopiedCodeId] = useState<string | null>(null);

  const handleCopyCode = (code: string, id: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCodeId(id);
    setTimeout(() => setCopiedCodeId(null), 2000);
  };

  // Safe manual markdown-like formatter for code blocks, bold text, lists, and line breaks
  const formatMessageText = (rawText: string) => {
    if (!rawText) return null;

    // Split text by code blocks
    const parts = rawText.split(/(```[\s\S]*?```)/g);

    return parts.map((part, index) => {
      if (part.startsWith("```") && part.endsWith("```")) {
        // Code Block
        const lines = part.slice(3, -3).trim().split("\n");
        let language = "code";
        let codeLines = lines;

        // Check if first line is language specifier
        if (lines.length > 0 && /^[a-zA-Z0-9+#-]+$/.test(lines[0])) {
          language = lines[0];
          codeLines = lines.slice(1);
        }

        const codeContent = codeLines.join("\n");
        const blockId = `code-block-${index}`;

        return (
          <div key={index} className="my-4 border border-[#2d2d2d] rounded-xl overflow-hidden bg-[#141414] shadow-inner">
            <div className="flex items-center justify-between px-4 py-2 bg-[#1c1c1c] border-b border-[#2d2d2d]/60">
              <span className="text-xs font-mono text-[#E08462] flex items-center gap-1.5 font-semibold">
                <Terminal className="w-3.5 h-3.5" />
                {language.toUpperCase()}
              </span>
              <button
                id={`copy-btn-${index}`}
                onClick={() => handleCopyCode(codeContent, blockId)}
                className="text-slate-400 hover:text-white transition-colors p-1.5 rounded-lg hover:bg-slate-800 flex items-center gap-1 text-[11px] font-mono cursor-pointer"
              >
                {copiedCodeId === blockId ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>
            <pre className="p-4 overflow-x-auto text-xs md:text-sm font-mono text-slate-300 leading-relaxed max-w-full">
              <code>{codeContent}</code>
            </pre>
          </div>
        );
      } else {
        // Plain text, lines & inline markdown parsing
        const lines = part.split("\n");
        return (
          <div key={index} className="space-y-2">
            {lines.map((line, lineIndex) => {
              // Bullet lists
              if (line.trim().startsWith("- ") || line.trim().startsWith("* ")) {
                const textContent = line.trim().substring(2);
                return (
                  <ul key={lineIndex} className="list-disc pl-6 text-slate-300 text-sm md:text-base font-light my-1 space-y-1">
                    <li>{parseInlineFormatting(textContent)}</li>
                  </ul>
                );
              }

              // Numbered lists
              const numberedMatch = line.trim().match(/^(\d+)\.\s(.*)/);
              if (numberedMatch) {
                const num = numberedMatch[1];
                const textContent = numberedMatch[2];
                return (
                  <ol key={lineIndex} className="list-decimal pl-6 text-slate-300 text-sm md:text-base font-light my-1 space-y-1">
                    <li value={parseInt(num)}>{parseInlineFormatting(textContent)}</li>
                  </ol>
                );
              }

              // Headers
              if (line.trim().startsWith("### ")) {
                return (
                  <h3 key={lineIndex} className="text-base md:text-lg font-display font-semibold text-white mt-4 mb-2">
                    {parseInlineFormatting(line.trim().substring(4))}
                  </h3>
                );
              }
              if (line.trim().startsWith("## ")) {
                return (
                  <h2 key={lineIndex} className="text-lg md:text-xl font-display font-bold text-white mt-5 mb-2.5 border-b border-slate-800/60 pb-1">
                    {parseInlineFormatting(line.trim().substring(3))}
                  </h2>
                );
              }
              if (line.trim().startsWith("# ")) {
                return (
                  <h1 key={lineIndex} className="text-xl md:text-2xl font-display font-extrabold text-[#ECE6DC] mt-6 mb-3">
                    {parseInlineFormatting(line.trim().substring(2))}
                  </h1>
                );
              }

              // Normal paragraph line
              return line.trim() === "" ? (
                <div key={lineIndex} className="h-2" />
              ) : (
                <p key={lineIndex} className="text-slate-300 text-sm md:text-base font-light leading-relaxed">
                  {parseInlineFormatting(line)}
                </p>
              );
            })}
          </div>
        );
      }
    });
  };

  // Helper to parse bold text **like this** and links
  const parseInlineFormatting = (text: string) => {
    // Bold parsing
    const parts = text.split(/(\*\*.*?\*\*)/g);
    return parts.map((part, partIdx) => {
      if (part.startsWith("**") && part.endsWith("**")) {
        return <strong key={partIdx} className="font-semibold text-white">{part.slice(2, -2)}</strong>;
      }
      return part;
    });
  };

  return (
    <div
      id={`message-${message.id}`}
      className={`py-6 md:py-8 border-b border-[#2C2C2C]/30 ${
        isAssistant ? "bg-[#1C1C1C]/40" : "bg-transparent"
      }`}
    >
      <div className="max-w-3xl mx-auto px-4 md:px-6 flex gap-4 md:gap-6">
        {/* Avatar */}
        <div className="shrink-0">
          <div
            className={`w-8 h-8 rounded-xl flex items-center justify-center border font-display text-xs font-semibold ${
              isAssistant
                ? "bg-[#2C2C2C] border-[#3C3C3C] text-[#ECE6DC] shadow-md shadow-[#E08462]/5"
                : "bg-[#252525] border-[#2E2E2E] text-slate-300"
            }`}
          >
            {isAssistant ? "N" : "U"}
          </div>
        </div>

        {/* Content Box */}
        <div className="flex-1 space-y-4 min-w-0">
          {/* Metadata */}
          <div className="flex items-center gap-2 select-none">
            <span className="text-xs font-medium text-[#ECE6DC]">
              {isAssistant ? "NexonAi" : "Anda"}
            </span>
            <span className="text-[10px] font-mono text-[#777777] font-light">
              {message.timestamp}
            </span>
            {isAssistant && message.modelUsed && (
              <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-[#252525] text-[#9D9D9D] uppercase tracking-wider scale-95 origin-left">
                {message.modelUsed.replace("models/", "")}
              </span>
            )}
          </div>

          {/* Error Message */}
          {message.error && (
            <div className="p-3.5 rounded-xl bg-red-950/10 border border-red-900/30 text-red-300 text-xs flex items-start gap-2 max-w-xl">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-400" />
              <div>
                <p className="font-medium text-red-200 mb-0.5">Error Terjadi</p>
                <p className="font-light">{message.error}</p>
              </div>
            </div>
          )}

          {/* Body Text */}
          {message.text && (
            <div className="space-y-3 prose prose-invert prose-sm max-w-none text-[#ECE6DC]/90">
              {formatMessageText(message.text)}
            </div>
          )}

          {/* Canvas Generated Image */}
          {message.imageUrl && (
            <div className="mt-4 group relative max-w-xl rounded-2xl overflow-hidden border border-[#2D2D2D] shadow-xl bg-[#222222]/40">
              <img
                src={message.imageUrl}
                alt="AI Generated Artwork"
                className="w-full h-auto object-cover max-h-[512px] hover:scale-[1.01] transition-transform duration-500"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end justify-between p-4">
                <p className="text-xs text-slate-300 italic max-w-xs drop-shadow-md">
                  Dihasilkan oleh AI Canvas
                </p>
                <a
                  href={message.imageUrl}
                  download={`nexon-canvas-${message.id}.png`}
                  className="px-3 py-1.5 rounded-lg bg-[#E08462] hover:bg-[#c97453] text-[#191919] text-xs font-semibold flex items-center gap-1.5 transition-all shadow-md cursor-pointer"
                >
                  Unduh Gambar
                </a>
              </div>
            </div>
          )}

          {/* Video Generated Player */}
          {message.videoUrl && (
            <div className="mt-4 group relative max-w-xl rounded-2xl overflow-hidden border border-[#2D2D2D] shadow-xl bg-[#222222]/40">
              <video
                src={message.videoUrl}
                controls
                className="w-full h-auto object-cover max-h-[512px]"
              />
              <div className="p-3 bg-[#1C1C1C] border-t border-[#2D2D2D] flex items-center justify-between">
                <span className="text-xs text-slate-400 flex items-center gap-1.5 font-light">
                  <Film className="w-3.5 h-3.5 text-[#E08462]" />
                  Video Veo Terbaru (Selesai)
                </span>
                <a
                  href={message.videoUrl}
                  download={`nexon-veo-${message.id}.mp4`}
                  className="px-3 py-1.5 rounded-lg bg-[#E08462] hover:bg-[#c97453] text-[#191919] text-xs font-semibold flex items-center gap-1.5 transition-all shadow-md cursor-pointer"
                >
                  Unduh Video
                </a>
              </div>
            </div>
          )}

          {/* Sources/Grounding References */}
          {isAssistant && message.sources && message.sources.length > 0 && (
            <div className="mt-6 pt-4 border-t border-[#2D2D2D]/60">
              <h4 className="text-[10px] font-semibold text-[#8D8D8D] flex items-center gap-1.5 mb-2.5 font-display tracking-wider uppercase">
                <Globe className="w-3.5 h-3.5 text-[#E08462]" />
                Referensi Tautan ({message.sources.length})
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {message.sources.map((source, sIdx) => (
                  <a
                    key={sIdx}
                    href={source.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2.5 rounded-xl bg-[#222222]/40 border border-[#2D2D2D]/60 hover:bg-[#252525]/60 hover:border-[#3A3A3A]/60 transition-all flex items-start gap-2.5 group/link text-left"
                  >
                    <div className="w-5 h-5 rounded bg-[#2C2C2C] border border-[#3C3C3C] flex items-center justify-center shrink-0 mt-0.5 text-[9px] text-[#E08462] font-mono font-bold group-hover/link:text-white transition-colors">
                      {sIdx + 1}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-medium text-slate-200 line-clamp-1 group-hover/link:text-[#E08462] transition-colors">
                        {source.title || "Referensi Informasi"}
                      </p>
                      <p className="text-[10px] text-slate-500 truncate font-mono mt-0.5">
                        {source.url}
                      </p>
                    </div>
                    <ExternalLink className="w-3 h-3 text-slate-500 group-hover/link:text-slate-300 shrink-0 mt-1 transition-colors" />
                  </a>
                ))}
              </div>
            </div>
          )}

          {/* Active Generation State / Loader */}
          {message.isGenerating && (
            <div className="flex items-center gap-3 py-1">
              <div className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#E08462] dot animate-bounce" style={{ animationDelay: "0ms" }}></span>
                <span className="w-1.5 h-1.5 rounded-full bg-[#E08462] dot animate-bounce" style={{ animationDelay: "150ms" }}></span>
                <span className="w-1.5 h-1.5 rounded-full bg-[#E08462] dot animate-bounce" style={{ animationDelay: "300ms" }}></span>
              </div>
              <span className="text-xs text-slate-500 font-light italic font-mono animate-pulse">
                {message.text || "Memproses..."}
              </span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
