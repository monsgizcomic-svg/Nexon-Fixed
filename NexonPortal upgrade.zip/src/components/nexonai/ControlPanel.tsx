import React from "react";
import { AIMode, ThinkingLevelType } from "./types";
import { MessageSquare, Code2, Brain, Globe, Sparkles } from "lucide-react";

interface ControlPanelProps {
  mode: AIMode;
  onChangeMode: (mode: AIMode) => void;
  thinking: ThinkingLevelType;
  onChangeThinking: (level: ThinkingLevelType) => void;
  search: boolean;
  onToggleSearch: () => void;
  deepResearch: boolean;
  onToggleDeepResearch: () => void;
}

export default function ControlPanel({
  mode,
  onChangeMode,
  thinking,
  onChangeThinking,
  search,
  onToggleSearch,
  deepResearch,
  onToggleDeepResearch,
}: ControlPanelProps) {
  // Mode configuration options
  const modes = [
    { id: "chat", label: "Chat", icon: MessageSquare, desc: "Asisten Serbaguna", color: "hover:text-blue-400" },
    { id: "code", label: "Code", icon: Code2, desc: "AI Programmer Spesialis", color: "hover:text-emerald-400" },
  ];

  return (
    <div id="control-panel" className="w-full bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl backdrop-blur-md">
      {/* 1. Mode Tabs Picker */}
      <div className="flex flex-wrap gap-1.5 sm:gap-2 mb-4 border-b border-slate-800 pb-4">
        {modes.map((m) => {
          const Icon = m.icon;
          const isActive = mode === m.id;
          return (
            <button
              id={`mode-tab-${m.id}`}
              key={m.id}
              onClick={() => onChangeMode(m.id as AIMode)}
              className={`flex-1 min-w-[75px] sm:min-w-[110px] py-1.5 sm:py-2 px-2 sm:px-3 rounded-xl border flex items-center justify-center gap-1 sm:gap-2 transition-all ${
                isActive
                  ? "bg-slate-800 border-slate-700 text-white font-medium shadow-md"
                  : `bg-slate-950/30 border-slate-900/60 text-slate-400 ${m.color}`
              }`}
            >
              <Icon className="w-3.5 h-3.5 sm:w-4 sm:h-4 shrink-0" />
              <div className="text-left">
                <p className="text-[10px] sm:text-xs font-semibold leading-tight">{m.label}</p>
              </div>
            </button>
          );
        })}
      </div>

      {/* 2. Interactive Controls Toolbar depending on selected mode */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs">
        
        {/* Left Side: General controls (Thinking, Search, Deep Research) */}
        {(mode === "chat" || mode === "code") && (
          <div className="flex flex-wrap items-center gap-3">
            {/* Thinking Level Segmented Selector */}
            <div className="flex items-center gap-2 bg-slate-950/50 p-1 rounded-xl border border-slate-800/80">
              <span className="pl-2 pr-1 text-[10px] uppercase font-mono font-bold text-slate-500 flex items-center gap-1">
                <Brain className="w-3.5 h-3.5 text-indigo-400" />
                Thinking:
              </span>
              {(["normal", "medium", "high"] as ThinkingLevelType[]).map((level) => {
                const isActive = thinking === level;
                return (
                  <button
                    id={`thinking-btn-${level}`}
                    key={level}
                    onClick={() => onChangeThinking(level)}
                    className={`px-2.5 py-1 rounded-lg font-medium text-[11px] capitalize transition-all ${
                      isActive
                        ? "bg-indigo-600/20 text-indigo-300 border border-indigo-500/20 shadow-sm"
                        : "text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    {level}
                  </button>
                );
              })}
            </div>

            {/* Real-time Web Search Toggle */}
            <button
              id="search-toggle-btn"
              onClick={onToggleSearch}
              className={`py-1.5 px-3 rounded-xl border flex items-center gap-1.5 font-medium transition-all ${
                search
                  ? "bg-blue-600/10 border-blue-500/30 text-blue-400 shadow-sm"
                  : "bg-slate-950/40 border-slate-900/80 text-slate-400 hover:text-slate-200"
              }`}
            >
              <Globe className={`w-3.5 h-3.5 ${search ? "animate-spin-slow" : ""}`} />
              <span>Cari Web</span>
            </button>

            {/* Deep Research Toggle */}
            <button
              id="deep-research-toggle-btn"
              onClick={onToggleDeepResearch}
              className={`py-1.5 px-3 rounded-xl border flex items-center gap-1.5 font-medium transition-all ${
                deepResearch
                  ? "bg-purple-600/10 border-purple-500/30 text-purple-400 shadow-sm animate-pulse"
                  : "bg-slate-950/40 border-slate-900/80 text-slate-400 hover:text-slate-200"
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Deep Research</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
