import React, { useState, useEffect } from "react";
import { ChatSession, AIMode, ThinkingLevelType, Message } from "./types";
import Sidebar from "./Sidebar";
import ChatArea from "./ChatArea";
import { auth } from "../../lib/firebase";
import { User as FirebaseUser } from "firebase/auth";

export default function NexonAiMain() {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [authLoading, setAuthLoading] = useState(true);

  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Monitor user state from Firebase
  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((u) => {
      setUser(u);
      setAuthLoading(false);
    });
    return () => unsubscribe();
  }, []);

  // Initialize or load user-specific sessions
  useEffect(() => {
    if (authLoading) return;
    if (!user) return;

    const key = `nexon_ai_sessions_${user.uid}`;
    let saved: ChatSession[] = [];
    try {
      const stored = localStorage.getItem(key);
      if (stored) {
        saved = JSON.parse(stored);
      }
    } catch (e) {
      console.error("Failed to parse sessions:", e);
    }

    if (saved.length > 0) {
      setSessions(saved);
      setActiveSessionId(saved[0].id);
      return;
    }

    // Default first session if none exists
    const initialSession: ChatSession = {
      id: `session-${Date.now()}`,
      title: "Percakapan Baru",
      createdAt: new Date().toLocaleDateString("id-ID", {
        day: "numeric",
        month: "short",
        year: "numeric",
      }),
      messages: [],
      mode: "chat",
      thinking: "normal",
      search: false,
      deepResearch: false,
      canvasModel: "nano-banana",
      videoModel: "veo-lite",
    };
    setSessions([initialSession]);
    setActiveSessionId(initialSession.id);
    try {
      localStorage.setItem(key, JSON.stringify([initialSession]));
    } catch (e) {
      console.error(e);
    }
  }, [user?.uid, authLoading]);

  // Save sessions to localStorage when they change
  const saveSessions = (updatedSessions: ChatSession[]) => {
    setSessions(updatedSessions);
    if (!user) return;
    try {
      const key = `nexon_ai_sessions_${user.uid}`;
      localStorage.setItem(key, JSON.stringify(updatedSessions));
    } catch (e) {
      console.error("Failed to save sessions:", e);
    }
  };

  // Helper to construct a new chat session
  const createNewSession = (mode: AIMode = "chat", initialMessageText?: string) => {
    const newSession: ChatSession = {
      id: `session-${Date.now()}`,
      title: initialMessageText ? (initialMessageText.length > 30 ? initialMessageText.substring(0, 30) + "..." : initialMessageText) : "Percakapan Baru",
      createdAt: new Date().toLocaleDateString("id-ID", {
        day: "numeric",
        month: "short",
        year: "numeric",
      }),
      messages: [],
      mode,
      thinking: "normal",
      search: false,
      deepResearch: false,
      canvasModel: "nano-banana",
      videoModel: "veo-lite",
    };

    const updated = [newSession, ...sessions];
    saveSessions(updated);
    setActiveSessionId(newSession.id);
    return newSession;
  };

  const handleSelectSession = (id: string) => {
    setActiveSessionId(id);
  };

  const handleDeleteSession = (id: string) => {
    const updated = sessions.filter((s) => s.id !== id);
    saveSessions(updated);
    if (activeSessionId === id) {
      if (updated.length > 0) {
        setActiveSessionId(updated[0].id);
      } else {
        const newSess: ChatSession = {
          id: `session-${Date.now()}`,
          title: "Percakapan Baru",
          createdAt: new Date().toLocaleDateString("id-ID", {
            day: "numeric",
            month: "short",
            year: "numeric",
          }),
          messages: [],
          mode: "chat",
          thinking: "normal",
          search: false,
          deepResearch: false,
          canvasModel: "nano-banana",
          videoModel: "veo-lite",
        };
        saveSessions([newSess]);
        setActiveSessionId(newSess.id);
      }
    }
  };

  const handleClearSessionMessages = () => {
    if (!activeSessionId) return;
    const updated = sessions.map((s) => {
      if (s.id === activeSessionId) {
        return { ...s, messages: [], title: "Percakapan Baru" };
      }
      return s;
    });
    saveSessions(updated);
  };

  const activeSession = sessions.find((s) => s.id === activeSessionId) || null;

  // Mode & configuration handlers
  const handleChangeMode = (mode: AIMode) => {
    if (!activeSessionId) return;
    const updated = sessions.map((s) => {
      if (s.id === activeSessionId) {
        return { ...s, mode };
      }
      return s;
    });
    saveSessions(updated);
  };

  const handleChangeThinking = (thinking: ThinkingLevelType) => {
    if (!activeSessionId) return;
    const updated = sessions.map((s) => {
      if (s.id === activeSessionId) {
        return { ...s, thinking };
      }
      return s;
    });
    saveSessions(updated);
  };

  const handleToggleSearch = () => {
    if (!activeSessionId) return;
    const updated = sessions.map((s) => {
      if (s.id === activeSessionId) {
        const nextSearch = !s.search;
        return {
          ...s,
          search: nextSearch,
          deepResearch: nextSearch ? s.deepResearch : false,
        };
      }
      return s;
    });
    saveSessions(updated);
  };

  const handleToggleDeepResearch = () => {
    if (!activeSessionId) return;
    const updated = sessions.map((s) => {
      if (s.id === activeSessionId) {
        const nextDeep = !s.deepResearch;
        return {
          ...s,
          deepResearch: nextDeep,
          search: nextDeep ? true : s.search,
        };
      }
      return s;
    });
    saveSessions(updated);
  };

  // Main prompt executor
  const handleSendMessage = async (text: string) => {
    let currentSession = activeSession;
    if (!currentSession) {
      currentSession = createNewSession("chat", text);
    }

    const mode = currentSession.mode;
    const thinking = currentSession.thinking;
    const search = currentSession.search;
    const deepResearch = currentSession.deepResearch;
    const canvasModel = currentSession.canvasModel || "nano-banana";
    const videoModel = currentSession.videoModel || "veo-lite";

    let updatedTitle = currentSession.title;
    if (currentSession.messages.length === 0) {
      updatedTitle = text.length > 30 ? text.substring(0, 30) + "..." : text;
    }

    // User Message
    const userMessage: Message = {
      id: `msg-user-${Date.now()}`,
      sender: "user",
      text,
      timestamp: new Date().toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" }),
    };

    // Assistant placeholder
    const assistantMessageId = `msg-assistant-${Date.now()}`;
    const assistantMessage: Message = {
      id: assistantMessageId,
      sender: "assistant",
      text: "Menghubungkan ke Nexon AI Engine...",
      timestamp: new Date().toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" }),
      isGenerating: true,
    };

    const initialMessages = [...currentSession.messages, userMessage, assistantMessage];
    
    let updatedSessions = sessions.map((s) => {
      if (s.id === currentSession!.id) {
        return {
          ...s,
          title: updatedTitle,
          messages: initialMessages,
        };
      }
      return s;
    });
    saveSessions(updatedSessions);

    try {
      if (mode === "chat" || mode === "code") {
        // Prepare chat history (exclude last placeholder message)
        const chatHistory = currentSession.messages
          .filter((m) => !m.isGenerating)
          .map((m) => ({
            role: m.sender,
            text: m.text,
          }));

        const response = await fetch("/api/generate", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            message: text,
            history: chatHistory,
            mode,
            thinking,
            search,
            deepResearch,
          }),
        });

        if (!response.ok) {
          const errData = await response.json();
          throw new Error(errData.error || "Gagal menghubungi server generator.");
        }

        const data = await response.json();

        updateMessageInState(currentSession.id, assistantMessageId, {
          text: data.text,
          sources: data.sources,
          modelUsed: data.modelUsed,
          isGenerating: false,
        });
      } else if (mode === "canvas") {
        // Canvas Image Generation
        updateMessageInState(currentSession.id, assistantMessageId, {
          text: "Sedang melukis gambar sesuai imajinasi Anda (Model Nano Banana)...",
        });

        const response = await fetch("/api/canvas/generate", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            prompt: text,
            modelType: canvasModel,
            aspectRatio: "1:1",
            size: "1K",
          }),
        });

        if (!response.ok) {
          const errData = await response.json();
          throw new Error(errData.error || "Gagal menghasilkan gambar dari Canvas.");
        }

        const data = await response.json();

        updateMessageInState(currentSession.id, assistantMessageId, {
          text: `Gambar berhasil dihasilkan menggunakan ${canvasModel === "nano-banana-pro" ? "Nano Banana Pro" : "Nano Banana Standard"}: \n\n*${text}*`,
          imageUrl: data.imageUrl,
          modelUsed: data.modelUsed,
          isGenerating: false,
        });
      } else if (mode === "video") {
        // Video Generation
        updateMessageInState(currentSession.id, assistantMessageId, {
          text: "Mengirimkan perintah ke Veo Video Engine...",
        });

        const initResponse = await fetch("/api/video/generate", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            prompt: text,
            modelType: videoModel,
          }),
        });

        if (!initResponse.ok) {
          const errData = await initResponse.json();
          throw new Error(errData.error || "Gagal menginisialisasi pembuatan video Veo.");
        }

        const { operationName, modelUsed } = await initResponse.json();

        // Start polling status
        updateMessageInState(currentSession.id, assistantMessageId, {
          text: "Veo sedang merancang dan menghasilkan video (Sedang memproses, butuh waktu ~15-30 detik)...",
        });

        let pollCount = 0;
        const maxPolls = 15;
        const pollInterval = setInterval(async () => {
          pollCount++;
          try {
            const statusResponse = await fetch("/api/video/status", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ operationName }),
            });

            if (!statusResponse.ok) {
              clearInterval(pollInterval);
              throw new Error("Gagal memeriksa status video.");
            }

            const statusData = await statusResponse.json();

            if (statusData.done) {
              clearInterval(pollInterval);
              
              if (statusData.error) {
                updateMessageInState(currentSession!.id, assistantMessageId, {
                  text: "Pembuatan video dibatalkan atau gagal diproses oleh model Veo.",
                  error: statusData.error.message || "Kesalahan internal di Veo Engine.",
                  isGenerating: false,
                });
                return;
              }

              updateMessageInState(currentSession!.id, assistantMessageId, {
                text: "Video selesai diproses. Mengunduh file media ke workspace Anda...",
              });

              const downloadRes = await fetch("/api/video/download", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ operationName }),
              });

              if (!downloadRes.ok) {
                throw new Error("Gagal mengunduh file video.");
              }

              const blob = await downloadRes.blob();
              const videoBlobUrl = URL.createObjectURL(blob);

              updateMessageInState(currentSession!.id, assistantMessageId, {
                text: `Klip video sinematik berhasil dihasilkan oleh Veo Terbaru: \n\n*${text}*`,
                videoUrl: videoBlobUrl,
                modelUsed,
                isGenerating: false,
              });
            } else {
              updateMessageInState(currentSession!.id, assistantMessageId, {
                text: `Veo sedang merender video Anda... (Proses render: ${Math.min(99, pollCount * 8)}%)`,
              });
            }
          } catch (pollErr: any) {
            clearInterval(pollInterval);
            updateMessageInState(currentSession!.id, assistantMessageId, {
              text: "Proses polling status terputus.",
              error: pollErr.message,
              isGenerating: false,
            });
          }
        }, 4000);
      }
    } catch (err: any) {
      console.error("Error executing prompt:", err);
      let errorMsg = err.message || "Terjadi kesalahan koneksi atau sistem.";
      if (
        errorMsg.includes("429") || 
        errorMsg.includes("quota") || 
        errorMsg.includes("RESOURCE_EXHAUSTED") ||
        errorMsg.includes("exceeded your current quota")
      ) {
        errorMsg = "Batas kuota gratis NexonAi telah tercapai (RESOURCE_EXHAUSTED). Silakan tunggu beberapa saat atau hubungi Administrator.";
      } else if (
        errorMsg.includes("503") ||
        errorMsg.includes("UNAVAILABLE") ||
        errorMsg.includes("demand") ||
        errorMsg.includes("temporary") ||
        errorMsg.includes("high demand")
      ) {
        errorMsg = "Layanan NexonAi (Gemini) sedang mengalami lonjakan lalu lintas yang sangat tinggi (UNAVAILABLE 503). Silakan coba lagi.";
      }
      updateMessageInState(currentSession.id, assistantMessageId, {
        text: "Gagal memproses jawaban dari NexonAi.",
        error: errorMsg,
        isGenerating: false,
      });
    }
  };

  // Helper to dynamically overwrite a message in state and save
  const updateMessageInState = (sessionId: string, msgId: string, updates: Partial<Message>) => {
    setSessions((prevSessions) => {
      const next = prevSessions.map((s) => {
        if (s.id === sessionId) {
          return {
            ...s,
            messages: s.messages.map((m) => {
              if (m.id === msgId) {
                return { ...m, ...updates };
              }
              return m;
            }),
          };
        }
        return s;
      });
      if (user) {
        try {
          const key = `nexon_ai_sessions_${user.uid}`;
          localStorage.setItem(key, JSON.stringify(next));
        } catch (e) {
          console.error(e);
        }
      }
      return next;
    });
  };

  // Quick start handler from WelcomeScreen
  const handleQuickStart = (mode: AIMode, initialPrompt?: string) => {
    const newSess = createNewSession(mode, initialPrompt);
    if (initialPrompt) {
      setTimeout(() => {
        handleSendMessage(initialPrompt);
      }, 100);
    }
  };

  if (authLoading) {
    return (
      <div id="nexon-loading" className="h-screen w-full bg-[#141414] flex flex-col items-center justify-center gap-4 select-none">
        <div className="relative flex items-center justify-center">
          <div className="w-12 h-12 rounded-2xl bg-[#E08462] animate-spin border border-[#E08462]/20 shadow-lg shadow-[#E08462]/10"></div>
          <div className="absolute font-display font-bold text-[#141414] text-xs">N</div>
        </div>
        <p className="text-[#9D9D9D] text-xs font-mono animate-pulse uppercase tracking-wider">Menghubungkan ke NexonAi...</p>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="flex h-screen w-full bg-[#191919] items-center justify-center text-[#9D9D9D] select-none text-sm">
        Silakan login terlebih dahulu untuk mengakses NexonAi.
      </div>
    );
  }

  return (
    <div id="nexon-root" className="flex h-screen w-full overflow-hidden bg-[#191919] text-[#ECE6DC] font-sans relative">
      
      {/* Background aesthetic glow effect */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none select-none z-0">
        <div className="absolute top-[-10%] left-[-5%] w-[60%] h-[60%] rounded-full bg-[#E08462]/10 blur-[130px]"></div>
        <div className="absolute bottom-[-5%] right-[-5%] w-[50%] h-[50%] rounded-full bg-[#c97453]/8 blur-[130px]"></div>
        {/* Decorative grid lines */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#8080800a_1px,transparent_1px),linear-gradient(to_bottom,#8080800a_1px,transparent_1px)] bg-[size:24px_24px]"></div>
      </div>

      {/* Sidebar Navigation */}
      <Sidebar
        sessions={sessions}
        activeSessionId={activeSessionId}
        onSelectSession={handleSelectSession}
        onNewSession={createNewSession}
        onDeleteSession={handleDeleteSession}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
      />

      {/* Main Interactive Window */}
      <div className="flex-1 flex flex-col min-w-0 lg:pl-72 relative z-10">
        
        <ChatArea
          session={activeSession}
          onSendMessage={handleSendMessage}
          onQuickStart={handleQuickStart}
          onClearSessionMessages={handleClearSessionMessages}
          onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
          onChangeMode={handleChangeMode}
          onChangeThinking={handleChangeThinking}
          onToggleSearch={handleToggleSearch}
          onToggleDeepResearch={handleToggleDeepResearch}
        />

      </div>

      {/* Mobile Sidebar overlay backdrop */}
      {isSidebarOpen && (
        <div
          id="sidebar-overlay-mobile"
          onClick={() => setIsSidebarOpen(false)}
          className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm z-40 lg:hidden"
        />
      )}

    </div>
  );
}
