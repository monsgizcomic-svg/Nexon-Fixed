import { useState, useRef, useEffect } from "react";
import { Message } from "../types";
import { renderFormattedText } from "./DianaChat";
import { 
  Send, 
  RefreshCw, 
  Heart, 
  Wind, 
  MessageSquare, 
  ShieldCheck, 
  HelpCircle,
  Sparkles,
  Info,
  Maximize2,
  Minimize2
} from "lucide-react";

interface LianaCounselProps {
  onAddNotification: (title: string, msg: string) => void;
}

export default function LianaCounsel({ onAddNotification }: LianaCounselProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "init-liana",
      sender: "ai",
      text: "Halo sayang... Selamat datang di ruang BK virtual yang hangat dan aman ini. Saya **Liana**, konselor (guru BK) pribadimu di **NexonAcademic** ❤️.\n\nDi sini, kamu bisa menumpahkan segala keluh kesahmu tanpa perlu merasa takut, sungkan, atau dinilai negatif. Entah itu stres tumpukan modul belajar, cemas menjelang ujian, masalah pertemanan di sekolah, atau sekadar lelah secara emosional.\n\nIngat ya, kesehatan mentalmu jauh lebih berharga daripada angka di lembar kertas ujian. Ceritakan apa saja yang sedang berkecamuk di dalam hatimu sekarang. Liana siap mendengarkan...",
      timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
    }
  ]);

  const [inputText, setInputText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  
  // Breathing animation states
  const [breathPhase, setBreathPhase] = useState<"tarik" | "tahan" | "hembuskan">("tarik");
  const [breathCounter, setBreathCounter] = useState(4);
  const [isBreathingActive, setIsBreathingActive] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Breathing timer loop
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isBreathingActive) {
      interval = setInterval(() => {
        setBreathCounter((prev) => {
          if (prev <= 1) {
            // Shift phases
            if (breathPhase === "tarik") {
              setBreathPhase("tahan");
              return 4; // hold for 4s
            } else if (breathPhase === "tahan") {
              setBreathPhase("hembuskan");
              return 5; // exhale for 5s
            } else {
              setBreathPhase("tarik");
              return 4; // inhale for 4s
            }
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      setBreathCounter(4);
      setBreathPhase("tarik");
    }

    return () => clearInterval(interval);
  }, [isBreathingActive, breathPhase]);

  const sampleBkPrompts = [
    { label: "Stres Belajar", text: "Saya merasa sangat penat belajar tapi materi pelajaran rasanya tidak ada yang masuk ke otak..." },
    { label: "Cemas Nilai", text: "Saya terus-menerus cemas luar biasa nilai ujian saya jelek dan mengecewakan orang tua." },
    { label: "Pertemanan", text: "Saya merasa sangat diasingkan di lingkungan sekolah dan tidak memiliki teman akrab." },
    { label: "Krisis Tenang", text: "Beri saya tips relaksasi kilat ketika tiba-tiba terkena serangan panik saat ujian berlangsung." }
  ];

  const handleSendMessage = async (customText?: string) => {
    const finalQuery = customText || inputText;
    if (!finalQuery.trim()) return;

    const userMsgId = Date.now().toString();
    const newUserMessage: Message = {
      id: userMsgId,
      sender: "user",
      text: finalQuery,
      timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages(prev => [...prev, newUserMessage]);
    setInputText("");
    setIsLoading(true);

    // Scroll to bottom
    setTimeout(() => {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, 100);

    try {
      const response = await fetch("/api/counsel", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...messages, newUserMessage].slice(-10) // Limit context
        })
      });

      if (!response.ok) {
        let errMsg = `Server Error (Status: ${response.status})`;
        try {
          const text = await response.text();
          try {
            const errData = JSON.parse(text);
            if (errData && errData.error) {
              errMsg = errData.error;
            } else if (errData && errData.message) {
              errMsg = errData.message;
            }
          } catch {
            if (text) {
              const cleanText = text.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
              errMsg = cleanText.substring(0, 150) || errMsg;
            }
          }
        } catch {}
        throw new Error(errMsg);
      }

      const data = await response.json();
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        sender: "ai",
        text: data.text,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
      }]);

    } catch (err: any) {
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        sender: "ai",
        text: `**Liana:** Saya mendengar suaramu, tapi ada gangguan jaringan di sini. Tarik napas sejenak, saya selalu di sini untuk bersamamu... (Error: ${err.message})`,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
      }]);
    } finally {
      setIsLoading(false);
      setTimeout(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
      }, 100);
    }
  };

  const handleResetChat = () => {
    if (confirm("Hapus seluruh catatan curhat kali ini untuk memulai dari awal?")) {
      setMessages([
        {
          id: "init-liana",
          sender: "ai",
          text: "Halo sayang, Liana ada di sini lagi. Tarik napas perlahan... Ceritakan apa yang mengganjal di pikiranmu.",
          timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-5" id="liana_counseling_wrapper">
      
      {/* 1. Breathing Exercise and Safety Panel on Left (Mobile-proofed) */}
      <div className="lg:col-span-4 flex flex-col gap-4">
        {/* Breathing Assist Card */}
        <div className="bg-[#0d0f17] border border-rose-500/20 rounded-2xl p-5 shadow-2xl text-center flex flex-col items-center justify-between min-h-[320px]">
          <div>
            <div className="flex items-center justify-center gap-1.5 text-rose-450 font-semibold mb-1">
              <Wind className="w-5 h-5 text-rose-400 animate-pulse" />
              <span>Meditasi Pernapasan Siswa</span>
            </div>
            <p className="text-xs text-white/60 leading-relaxed font-sans">
              Jika kamu merasa cemas, panik, atau detak jantung kencang karena urusan tugas sekolah, mari gunakan bantuan ritme napas Liana di bawah ini.
            </p>
          </div>

          {/* Animated Circle Stage */}
          <div className="my-6 relative flex items-center justify-center">
            {/* Pulsing Breathing Background circles */}
            <div className={`absolute rounded-full bg-rose-500/10 transition-all duration-1000 ${
              isBreathingActive && breathPhase === "tarik" ? "w-36 h-36 scale-120 opacity-80" : 
              isBreathingActive && breathPhase === "tahan" ? "w-36 h-36 scale-120 opacity-100" :
              "w-24 h-24 scale-100 opacity-40"
            }`}></div>
            
            <div className={`w-28 h-28 rounded-full flex flex-col items-center justify-center text-white font-bold transition-all duration-1000 shadow-xl relative z-10 select-none border border-rose-500/30 ${
              isBreathingActive && breathPhase === "tarik" ? "bg-rose-500 hover:bg-rose-600 scale-110" : 
              isBreathingActive && breathPhase === "tahan" ? "bg-amber-600 hover:bg-amber-700 scale-110" : 
              "bg-rose-950/80 hover:bg-rose-900/80 text-rose-100 scale-100"
            }`}>
              <span className="text-xs tracking-wide uppercase font-mono">
                {!isBreathingActive ? "Tenang" : breathPhase}
              </span>
              <span className="text-2xl mt-0.5 animate-pulse">
                {!isBreathingActive ? "🧘‍♀️" : breathCounter}
              </span>
            </div>
          </div>

          <div className="w-full">
            {isBreathingActive ? (
              <div className="space-y-2">
                <p className="text-xs font-semibold text-rose-300 animate-pulse min-h-[16px] font-mono">
                  {breathPhase === "tarik" && "Tarik napas dalam-dalam secara perlahan..."}
                  {breathPhase === "tahan" && "Tahan napas Anda sejenak... Rasakan kedamaian."}
                  {breathPhase === "hembuskan" && "Hembuskan perlahan lewat mulut secara santai..."}
                </p>
                <button
                  type="button"
                  onClick={() => setIsBreathingActive(false)}
                  className="w-full py-2 bg-rose-950/40 text-rose-300 hover:bg-rose-900/40 hover:text-white border border-rose-500/30 rounded-xl text-xs cursor-pointer transition-colors"
                >
                  Hentikan Latihan
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => {
                  setIsBreathingActive(true);
                  setBreathPhase("tarik");
                  setBreathCounter(4);
                  onAddNotification("Mulai Relaksasi", "Latihan pernapasan 4-4-5 diaktifkan untuk menenangkan pikiranmu.");
                }}
                className="w-full py-2 bg-gradient-to-r from-rose-500 to-amber-500 hover:from-rose-600 hover:to-amber-600 text-white font-medium rounded-xl text-xs shadow-xs cursor-pointer transition-all border border-rose-500/10"
              >
                Mulai Tarik Napas Tenang
              </button>
            )}
          </div>
        </div>

        {/* Security & Confidentiality Badges */}
        <div className="bg-[#12141c] border border-white/10 rounded-2xl p-4 text-xs space-y-2 shadow-xl">
          <div className="flex items-center gap-2 text-white/80 font-semibold font-mono">
            <ShieldCheck className="w-4 h-4 text-emerald-450 shrink-0" />
            <span>Privasi Terjaga</span>
          </div>
          <p className="text-white/60 leading-relaxed font-sans">
            Sesi konseling bimbingan konseling di NexonAcademic ini dijamin kerahasiaannya. Seluruh obrolan bersifat personal antara kamu dan Ibu Liana.
          </p>
          <div className="bg-white/5 p-2.5 rounded-lg border border-white/10 flex items-start gap-2 mt-1">
            <Info className="w-3.5 h-3.5 text-white/30 shrink-0 mt-0.5" />
            <p className="text-[10px] text-white/30 font-mono">
              Disclaimer: Ibu Liana adalah asisten pendukung BK bertenaga AI. Silakan konsultasikan masalah kritis serius dengan konselor sekolah sesungguhnya.
            </p>
          </div>
        </div>
      </div>
       {/* 2. Counselor Chat Panel on Right */}
      <div 
        className={`flex flex-col bg-[#0d0f17] shadow-2xl transition-all duration-350 ease-out ${
          isExpanded 
            ? "fixed inset-0 z-[100] m-0 rounded-none w-screen h-screen p-2 md:p-4" 
            : "lg:col-span-8 h-[calc(100vh-10rem)] md:h-[calc(100vh-6rem)] rounded-2xl border border-rose-500/20 overflow-hidden"
        }`}
      >
        
        {/* BK Hub Header */}
        <div className="bg-gradient-to-r from-rose-950 via-slate-900 to-amber-950/70 text-white p-4 flex items-center justify-between border-b border-rose-500/10 rounded-t-2xl">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-rose-500/10 flex items-center justify-center border border-rose-500/25 relative">
              <span className="text-xl">❤️</span>
              <span className="absolute bottom-0 right-0 w-3 h-3 bg-pink-400 rounded-full border-2 border-slate-900 animate-pulse"></span>
            </div>
            <div>
              <div className="font-semibold flex items-center gap-1.5 text-base">
                Ibu Liana, S.Psi <span className="text-xs bg-rose-550 bg-rose-500/20 text-rose-300 px-1.5 py-0.5 rounded border border-rose-500/30">Guru BK (Counselor)</span>
              </div>
              <div className="text-xs text-white/40 font-mono">Konseling Ramah • Ruang Curhat Aman</div>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button 
              type="button"
              onClick={() => setIsExpanded(!isExpanded)} 
              title={isExpanded ? "Kecilkan Layar" : "Perbesar Layar"} 
              className="p-2 hover:bg-white/10 rounded-lg text-white/50 hover:text-white transition-colors cursor-pointer flex items-center justify-center"
            >
              {isExpanded ? <Minimize2 className="w-4.5 h-4.5" /> : <Maximize2 className="w-4.5 h-4.5" />}
            </button>
            <button 
              type="button"
              onClick={handleResetChat} 
              title="Mulai Ulang Curhat" 
              className="p-2 hover:bg-white/10 rounded-lg text-white/50 hover:text-white transition-colors cursor-pointer flex items-center justify-center"
            >
              <RefreshCw className="w-4.5 h-4.5" />
            </button>
          </div>
        </div>

        {/* Chat Stage */}
        <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-[#08090d]">
          {messages.map((msg) => (
            <div 
              key={msg.id}
              className={`flex gap-3 max-w-[85%] sm:max-w-[75%] ${msg.sender === "user" ? "ml-auto flex-row-reverse" : "mr-auto"}`}
            >
              <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                msg.sender === "user" ? "bg-[#1f2937] text-indigo-300 border border-indigo-500/20" : "bg-rose-950 text-rose-400 border border-rose-500/20"
              }`}>
                {msg.sender === "user" ? "S" : <Heart className="w-4 h-4 fill-current text-rose-450" />}
              </div>
              
              <div className="flex flex-col space-y-1">
                <div className={`p-4 rounded-2xl leading-relaxed text-sm shadow-xl ${
                  msg.sender === "user" 
                    ? "bg-indigo-900/30 text-indigo-100 border border-indigo-500/30 rounded-tr-none" 
                    : "bg-white/5 text-white/95 border border-white/10 rounded-tl-none font-medium"
                }`}>
                  {renderFormattedText(msg.text, "liana")}
                </div>
                <span className="text-[10px] text-white/30 px-1 font-mono">{msg.timestamp}</span>
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex gap-3 mr-auto max-w-[75%] font-sans">
              <div className="w-8 h-8 rounded-full bg-rose-955 bg-rose-950 text-rose-400 border border-rose-500/25 flex items-center justify-center shrink-0 animate-pulse">
                <Heart className="w-4 h-4 fill-current text-rose-450" />
              </div>
              <div className="bg-[#12141c] text-white/80 border border-white/10 shadow-xl p-4 rounded-2xl rounded-tl-none flex items-center gap-2">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-pink-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-pink-500"></span>
                </span>
                <span className="text-xs text-rose-300 font-medium font-mono">Liana sedang menuangkan empati terbaiknya untukmu...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Suggested BK Questions on Initial State */}
        {messages.length === 1 && (
          <div className="p-3 bg-[#0d0f17] border-t border-rose-500/10 font-sans">
            <p className="text-[10px] font-semibold text-rose-400 uppercase tracking-wider mb-2 flex items-center gap-1 px-1 font-mono">
              <Sparkles className="w-3 h-3 text-amber-500 animate-pulse" /> Pilih Hal yang Ingin Kamu Diskusikan:
            </p>
            <div className="grid grid-cols-2 gap-2">
              {sampleBkPrompts.map((p, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setInputText(p.text)}
                  className="p-2.5 text-left bg-[#12141c] hover:bg-rose-500/10 border border-white/5 hover:border-rose-500/30 rounded-xl text-xs transition-colors cursor-pointer shadow-lg text-white/80 hover:text-white"
                >
                  <div className="font-semibold text-rose-400 font-mono mb-0.5">{p.label}</div>
                  <div className="text-white/40 truncate text-[10px]">{p.text}</div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Input box */}
        <div className="p-3 border-t border-white/10 bg-[#0d0f17] font-sans">
          <div className="flex items-center gap-2">
            <textarea
              rows={3}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              placeholder="Ceritakan beban pikiranmu atau perasaanmu ke Ibu Liana..."
              className="flex-1 px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl focus:outline-hidden focus:ring-1.5 focus:ring-rose-500/40 focus:border-rose-500/40 text-sm transition-all text-white placeholder-white/20 resize-none font-sans"
            />
            <button
              type="button"
              disabled={!inputText.trim()}
              onClick={() => handleSendMessage()}
              className="p-3 bg-gradient-to-r from-rose-500 to-amber-500 hover:from-rose-600 hover:to-amber-600 text-white rounded-xl shadow-xs transition-all cursor-pointer flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed shrink-0"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

    </div>
  );
}
