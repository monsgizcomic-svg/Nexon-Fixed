import React, { useState, useEffect, useRef, DragEvent, ChangeEvent } from "react";
import { Message } from "../types";
import { 
  Send, 
  Paperclip, 
  X, 
  Bot, 
  User, 
  RefreshCw, 
  Sparkles, 
  FileText, 
  Image as ImageIcon,
  CheckCircle,
  HelpCircle,
  Maximize2,
  Minimize2
} from "lucide-react";

interface DianaChatProps {
  onAddNotification: (title: string, msg: string) => void;
}

export interface ChatRoom {
  id: string;
  name: string;
  messages: Message[];
}

export default function DianaChat({ onAddNotification }: DianaChatProps) {
  const [rooms, setRooms] = useState<ChatRoom[]>(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("diana_chat_rooms");
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed) && parsed.length > 0) return parsed;
        } catch (e) {
          console.warn("Failed to parse Diana chat history");
        }
      }
    }
    return [
      {
        id: "default",
        name: "Kelas Umum",
        messages: [
          {
            id: "init-diana",
            sender: "ai",
            text: "Halo! Saya **Diana**, Guru Akademik kecerdasan buatan Anda di **NexonAcademic** 🎓.\n\nSaya menguasai berbagai mata pelajaran mulai dari *Matematika, Fisika, Kimia, hingga Sejarah dan Sastra*. \n\nKamu bisa bertanya apapun, berdiskusi materi rumit, latihan ujian, atau **mengirimkan file tugas, gambar coretan rumus, atau dokumen teks** untuk saya koreksi langsung. Apa yang ingin kamu pelajari hari ini?",
            timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
          }
        ]
      }
    ];
  });
  
  const [activeRoomId, setActiveRoomId] = useState<string>("default");

  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem("diana_chat_rooms", JSON.stringify(rooms));
    }
  }, [rooms]);

  const activeRoom = rooms.find(r => r.id === activeRoomId) || rooms[0];
  const messages = activeRoom.messages;

  const setMessages = (updater: Message[] | ((prev: Message[]) => Message[])) => {
    setRooms(prevRooms => prevRooms.map(r => {
      if (r.id === activeRoomId) {
        return {
          ...r,
          messages: typeof updater === "function" ? updater(r.messages) : updater
        };
      }
      return r;
    }));
  };

  const handleCreateRoom = () => {
    const name = prompt("Masukkan nama kelas baru (misal: Kelas IPA, Kelas Sejarah):");
    if (!name || !name.trim()) return;
    
    const newRoom: ChatRoom = {
      id: Date.now().toString(),
      name: name.trim(),
      messages: [
        {
          id: "init-diana-" + Date.now(),
          sender: "ai",
          text: `Halo! Selamat datang di **${name.trim()}**.\n\nMateri apa yang ingin kita bahas di kelas ini hari ini?`,
          timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
        }
      ]
    };
    
    setRooms(prev => [...prev, newRoom]);
    setActiveRoomId(newRoom.id);
  };

  const handleDeleteRoom = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (rooms.length <= 1) {
      alert("Anda harus memiliki setidaknya satu kelas.");
      return;
    }
    if (confirm("Hapus kelas ini dan semua riwayat obrolannya?")) {
      const newRooms = rooms.filter(r => r.id !== id);
      setRooms(newRooms);
      if (activeRoomId === id) {
        setActiveRoomId(newRooms[0].id);
      }
    }
  };
  
  const [inputText, setInputText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [attachedFile, setAttachedFile] = useState<{ name: string; type: string; base64: string } | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const samplePrompts = [
    { title: "Tanya Matematika", text: "Jelaskan konsep integral tentu beserta contoh soal sehari-hari yang mudah dipahami." },
    { title: "Kuis Fisika", text: "Buatkan 3 pertanyaan kuis seru tentang Hukum Termodinamika dan beri kunci jawabannya." },
    { title: "Koreksi Tugas", text: "Tolong periksa dan jelaskan kesalahan dari file tugas kimia yang saya kirimkan ini." },
    { title: "Sintesis Sejarah", text: "Ringkas peristiwa Sumpah Pemuda dalam bentuk peta poin-poin penting kronologis." }
  ];

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = () => {
    setIsDragOver(false);
  };

  const convertFileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        const result = reader.result as string;
        // Strip the mime declaration prefix (e.g., data:image/png;base64, )
        const base64Data = result.split(",")[1];
        resolve(base64Data);
      };
      reader.onerror = (error) => reject(error);
    });
  };

  const processFile = async (file: File) => {
    if (file.size > 10 * 1024 * 1024) {
      alert("Maaf, ukuran berkas maksimal adalah 10MB demi kenyamanan akses.");
      return;
    }
    
    try {
      const base64 = await convertFileToBase64(file);
      setAttachedFile({
        name: file.name,
        type: file.type,
        base64: base64
      });
      onAddNotification("Berkas Tersemat!", `Berkas "${file.name}" siap dianalisis oleh Diana.`);
    } catch (err) {
      console.error("Gagal membaca file:", err);
      alert("Terjadi kesalahan saat mengunggah berkas.");
    }
  };

  const handleDrop = async (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      await processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = async (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      await processFile(e.target.files[0]);
    }
  };

  const handleSendMessage = async (textToSend?: string) => {
    const finalQuery = textToSend || inputText;
    if (!finalQuery.trim() && !attachedFile) return;

    const userMsgId = Date.now().toString();
    const newUserMessage: Message = {
      id: userMsgId,
      sender: "user",
      text: finalQuery,
      timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      fileName: attachedFile?.name,
      fileType: attachedFile?.type
    };

    setMessages(prev => [...prev, newUserMessage]);
    setInputText("");
    setIsLoading(true);
    
    // Auto scroll down
    setTimeout(() => {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, 100);

    // Save attached file context to prepare body
    const payloadFile = attachedFile ? {
      base64: attachedFile.base64,
      mimeType: attachedFile.type || "application/octet-stream"
    } : null;

    // Reset attachment in UI
    setAttachedFile(null);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...messages, newUserMessage].slice(-10), // Send last 10 messages for context
          fileData: payloadFile,
          roomName: activeRoom.name
        })
      });

      if (!response.ok) {
        let errMsg = `Server Error (Status: ${response.status})`;
        try {
          const text = await response.text();
          try {
            const errData = JSON.parse(text);
            if (errData && errData.error) {
              errMsg = errData.error;
            } else if (errData && errData.message) {
              errMsg = errData.message;
            }
          } catch {
            if (text) {
              const cleanText = text.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
              errMsg = cleanText.substring(0, 150) || errMsg;
            }
          }
        } catch {}
        throw new Error(errMsg);
      }

      const data = await response.json();
      
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        sender: "ai",
        text: data.text,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
      }]);

    } catch (err: any) {
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        sender: "ai",
        text: `**Diana:** Ada masalah saat menyambungkan ke pustaka kecerdasan buatan saya. Silakan coba kirim ulang pertanyaan akademik Anda. (Error: ${err.message})`,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
      }]);
    } finally {
      setIsLoading(false);
      setTimeout(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
      }, 100);
    }
  };

  const handleResetChat = () => {
    if (confirm(`Reset ulang riwayat obrolan di kelas ${activeRoom.name}?`)) {
      setMessages([
        {
          id: "init-diana",
          sender: "ai",
          text: `Halo! Saya Diana kembali segar. Silakan tanyakan materi atau tugas di kelas **${activeRoom.name}** ini.`,
          timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    }
  };

  return (
    <div 
      className={`flex flex-col bg-[#0d0f17] shadow-2xl transition-all duration-350 ease-out ${
        isExpanded 
          ? "fixed inset-0 z-[100] m-0 rounded-none w-screen h-screen p-2 md:p-4" 
          : "h-[calc(100vh-10rem)] md:h-[calc(100vh-6rem)] rounded-2xl border border-white/10 overflow-hidden"
      }`} 
      id="diana_chat_panel"
    >
      {/* Head */}
      <div className="bg-gradient-to-r from-teal-950 to-slate-900 border-b border-white/5 text-white p-4 flex items-center justify-between shadow-xs rounded-t-2xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-teal-500/10 flex items-center justify-center border border-teal-500/30 relative">
            <span className="text-xl font-bold">👩‍🏫</span>
            <span className="absolute bottom-0 right-0 w-3 h-3 bg-teal-400 rounded-full border-2 border-slate-900"></span>
          </div>
          <div>
            <div className="font-semibold flex items-center gap-1.5 text-base">
              Ibu Diana <span className="text-xs bg-teal-500/20 text-teal-300 px-1.5 py-0.5 rounded border border-teal-500/30">Guru MIPA</span>
            </div>
            <div className="text-xs text-white/40 font-mono">Spesialis MIPA & Sastra • Siap Koreksi Tugas</div>
          </div>
        </div>
        <div className="flex items-center gap-1.5">
          <button 
            type="button"
            onClick={() => setIsExpanded(!isExpanded)} 
            title={isExpanded ? "Kecilkan Layar" : "Perbesar Layar"} 
            className="p-2 hover:bg-white/10 rounded-lg text-white/50 hover:text-white transition-colors cursor-pointer flex items-center justify-center"
          >
            {isExpanded ? <Minimize2 className="w-4.5 h-4.5" /> : <Maximize2 className="w-4.5 h-4.5" />}
          </button>
          <button 
            type="button"
            onClick={handleResetChat} 
            title="Reset Obrolan Kelas" 
            className="p-2 hover:bg-white/10 rounded-lg text-white/50 hover:text-white transition-colors cursor-pointer flex items-center justify-center"
          >
            <RefreshCw className="w-4.5 h-4.5" />
          </button>
        </div>
      </div>

      {/* Room Tabs */}
      <div className="flex bg-[#0d0f17] overflow-x-auto border-b border-white/5 scrollbar-hide p-1 gap-1">
        {rooms.map(room => (
          <div 
            key={room.id}
            onClick={() => setActiveRoomId(room.id)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-md cursor-pointer whitespace-nowrap text-sm font-medium transition-colors ${
              activeRoomId === room.id 
                ? "bg-teal-500/15 text-teal-300 border border-teal-500/20" 
                : "text-white/50 hover:text-white hover:bg-white/5 border border-transparent"
            }`}
          >
            <span>{room.name}</span>
            <button 
              onClick={(e) => handleDeleteRoom(room.id, e)}
              className="text-white/20 hover:text-rose-400 p-0.5 rounded transition-colors"
              title="Hapus Kelas"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        ))}
        <button 
          onClick={handleCreateRoom}
          className="flex items-center gap-1 px-3 py-1.5 rounded-md cursor-pointer whitespace-nowrap text-sm font-medium text-white/50 hover:text-white hover:bg-white/5 transition-colors border border-dashed border-white/20 hover:border-white/40"
        >
          <span>+ Tambah Kelas</span>
        </button>
      </div>

      {/* Messages Stage */}
      <div 
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`flex-1 p-4 overflow-y-auto space-y-4 bg-[#08090d] relative transition-all duration-200 ${isDragOver ? "bg-teal-950/20 ring-2 ring-teal-500/40 ring-inset" : ""}`}
      >
        {/* Drag over overlay */}
        {isDragOver && (
          <div className="absolute inset-0 bg-teal-950/90 backdrop-blur-md flex flex-col items-center justify-center border-2 border-dashed border-teal-400/80 m-2 rounded-xl z-10 pointer-events-none">
            <div className="p-4 bg-teal-500/20 text-teal-400 rounded-full animate-bounce mb-3 border border-teal-500/30">
              <Paperclip className="w-8 h-8" />
            </div>
            <p className="text-teal-350 font-medium">Lepaskan Berkas di Sini</p>
            <p className="text-teal-400/60 text-xs mt-1">Mendukung gambar, latihan soal, dokumen PDF, teks, dll (Maks 10MB)</p>
          </div>
        )}

        {messages.map((msg) => (
          <div 
            key={msg.id}
            className={`flex gap-3 max-w-[85%] sm:max-w-[75%] ${msg.sender === "user" ? "ml-auto flex-row-reverse" : "mr-auto"}`}
          >
            <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
              msg.sender === "user" ? "bg-[#1f2937] text-indigo-300 border border-indigo-500/30" : "bg-teal-950 text-teal-400 border border-teal-500/30"
            }`}>
              {msg.sender === "user" ? <User className="w-4.5 h-4.5" /> : <Bot className="w-4.5 h-4.5" />}
            </div>
            
            <div className="flex flex-col space-y-1">
              <div className={`p-4 rounded-2xl leading-relaxed text-sm shadow-xl ${
                msg.sender === "user" 
                  ? "bg-indigo-900/30 text-indigo-100 border border-indigo-500/30 rounded-tr-none" 
                  : "bg-[#12141c] text-white/95 border border-white/5 rounded-tl-none"
              }`}>
                {/* Optional attachment label above text */}
                {msg.fileName && (
                  <div className="mb-2.5 py-1.5 px-2 bg-black/60 rounded-lg flex items-center gap-2 text-xs text-white/60 border border-white/5 font-mono">
                    {msg.fileType?.includes("image") ? <ImageIcon className="w-3.5 h-3.5 text-blue-400" /> : <FileText className="w-3.5 h-3.5 text-amber-400" />}
                    <span className="truncate max-w-[150px]" title={msg.fileName}>{msg.fileName}</span>
                    <CheckCircle className="w-3.5 h-3.5 text-green-400 ml-auto shrink-0" />
                  </div>
                )}
                {renderFormattedText(msg.text, "diana")}
              </div>
              <span className="text-[10px] text-white/30 px-1 font-mono">{msg.timestamp}</span>
            </div>
          </div>
        ))}
        
        {isLoading && (
          <div className="flex gap-3 mr-auto max-w-[75%]">
            <div className="w-8 h-8 rounded-full bg-teal-950 text-teal-400 border border-teal-500/30 flex items-center justify-center shrink-0 animate-pulse">
              <Bot className="w-4.5 h-4.5" />
            </div>
            <div className="bg-[#12141c] text-white/80 border border-white/10 p-4 rounded-2xl rounded-tl-none flex items-center gap-2.5 shadow-xl">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-teal-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-teal-500"></span>
              </span>
              <span className="text-xs text-teal-300 font-medium font-mono">Diana sedang membaca berkas & merangkum rumus Anda...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Prompts Grid */}
      {messages.length === 1 && (
        <div className="p-3 bg-[#0d0f17] border-t border-white/5">
          <p className="text-[11px] font-semibold text-white/30 uppercase tracking-wider mb-2 flex items-center gap-1 px-1">
            <Sparkles className="w-3 h-3 text-teal-400 animate-pulse" /> Inspirasi Belajar Bersama Diana:
          </p>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
            {samplePrompts.map((p, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => {
                  setInputText(p.text);
                }}
                className="p-2.5 text-left bg-[#12141c] hover:bg-teal-500/10 border border-white/5 hover:border-teal-500/30 rounded-xl text-xs transition-all cursor-pointer shadow-lg"
              >
                <div className="font-semibold text-teal-400 mb-0.5">{p.title}</div>
                <div className="text-white/40 truncate text-[10px]">{p.text}</div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input controls panel */}
      <div className="p-3 border-t border-white/5 bg-[#0d0f17]">
        {/* Attachment preview if selected */}
        {attachedFile && (
          <div className="mb-2 p-2 bg-teal-500/10 border border-teal-500/35 rounded-lg flex items-center justify-between text-xs animate-fadeIn">
            <div className="flex items-center gap-2 font-medium text-teal-300">
              {attachedFile.type.includes("image") ? <ImageIcon className="w-4 h-4 text-teal-400" /> : <FileText className="w-4 h-4 text-teal-400" />}
              <span className="truncate max-w-[220px]">{attachedFile.name}</span>
              <span className="text-[9px] bg-teal-500/20 text-teal-300 px-1.5 py-0.5 rounded-full font-mono uppercase border border-teal-500/20">Siap dikirim</span>
            </div>
            <button 
              onClick={() => setAttachedFile(null)} 
              className="p-1 hover:bg-teal-500/20 text-teal-400 rounded-full cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        <div className="flex items-center gap-2">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept="image/*,.txt,.json,.csv,.pdf"
            className="hidden"
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            title="Sematkan berkas atau gambar tugas"
            className="p-2.5 bg-white/5 hover:bg-white/10 border border-white/10 text-white/70 hover:text-teal-400 rounded-xl transition-all cursor-pointer flex items-center justify-center shrink-0"
          >
            <Paperclip className="w-5 h-5" />
          </button>
          
          <div className="flex-1 relative">
            <textarea
              rows={3}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              placeholder={attachedFile ? "Beri pertanyaan terkait berkas yang Anda unggah..." : "Tanya Diana matematika, fisika atau koreksi tugas..."}
              className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl focus:outline-hidden focus:ring-1.5 focus:ring-teal-500/30 focus:border-teal-500/40 text-sm transition-all text-white/90 placeholder-white/20 resize-none font-sans"
            />
          </div>

          <button
            type="button"
            disabled={!inputText.trim() && !attachedFile}
            onClick={() => handleSendMessage()}
            className="p-2.5 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white rounded-xl shadow-xs transition-all cursor-pointer flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed shrink-0"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
        <div className="mt-1.5 text-[10px] text-white/30 text-center font-mono">
          Tips: seret-lepaskan file tugas di ruangan obrolan ini untuk membacakan otomatis!
        </div>
      </div>
    </div>
  );
}

// Custom Markdown parser for premium UI and correct formatting of raw **bold** and *italics*
export function parseInlineStyles(text: string, theme: "diana" | "liana" = "diana"): React.ReactNode[] {
  if (!text) return [];
  const parts = text.split(/(\*\*.*?\*\*|\*.*?\*)/g);
  const boldClass = theme === "diana" ? "font-extrabold text-teal-300" : "font-extrabold text-rose-350";
  const italicClass = theme === "diana" ? "italic text-teal-200" : "italic text-rose-200";
  return parts.map((part, index) => {
    if (part.startsWith("**") && part.endsWith("**")) {
      return <strong key={index} className={boldClass}>{part.slice(2, -2)}</strong>;
    }
    if (part.startsWith("*") && part.endsWith("*")) {
      return <em key={index} className={italicClass}>{part.slice(1, -1)}</em>;
    }
    return part;
  });
}

export function renderFormattedText(text: string, theme: "diana" | "liana" = "diana") {
  if (!text) return null;
  const lines = text.split("\n");
  let inList = false;
  const listItems: React.ReactNode[] = [];
  const elements: React.ReactNode[] = [];

  const flushList = (keyPrefix: string) => {
    if (listItems.length > 0) {
      elements.push(
        <ul key={`ul-${keyPrefix}`} className="list-disc pl-5 my-2 space-y-1.5 text-white/80">
          {[...listItems]}
        </ul>
      );
      listItems.length = 0; // clear
    }
  };

  lines.forEach((line, index) => {
    const trimmed = line.trim();
    
    // Bullet point list item
    if (trimmed.startsWith("* ") || trimmed.startsWith("- ")) {
      inList = true;
      const content = trimmed.slice(2);
      listItems.push(
        <li key={`li-${index}`} className="leading-relaxed">
          {parseInlineStyles(content, theme)}
        </li>
      );
    } else {
      if (inList) {
        flushList(String(index));
        inList = false;
      }

      if (trimmed === "") {
        elements.push(<div key={`spacer-${index}`} className="h-2" />);
      } else if (trimmed.startsWith("### ")) {
        elements.push(
          <h3 key={`h3-${index}`} className="text-sm font-bold text-white mt-3.5 mb-1 tracking-tight font-display">
            {parseInlineStyles(trimmed.slice(4), theme)}
          </h3>
        );
      } else if (trimmed.startsWith("## ")) {
        elements.push(
          <h2 key={`h2-${index}`} className="text-base font-bold text-white mt-4.5 mb-1.5 tracking-tight font-display">
            {parseInlineStyles(trimmed.slice(3), theme)}
          </h2>
        );
      } else if (trimmed.startsWith("# ")) {
        elements.push(
          <h1 key={`h1-${index}`} className="text-lg font-bold text-white mt-5 mb-2 tracking-tight font-display">
            {parseInlineStyles(trimmed.slice(2), theme)}
          </h1>
        );
      } else {
        elements.push(
          <p key={`p-${index}`} className="leading-relaxed mb-2 text-white/90">
            {parseInlineStyles(line, theme)}
          </p>
        );
      }
    }
  });

  if (inList) {
    flushList("end");
  }

  return <div className="space-y-1">{elements}</div>;
}

