# NexonAcademic - Panduan Instalasi & Deploy ke Google Cloud Run

Projek ini adalah platform pembelajaran multi-agen akademik dan bimbingan konseling lengkap berteknologi tinggi dengan frontend React (Vite, Tailwind CSS) dan backend full-stack Express.js terintegrasi dengan Google Gemini AI.

---

## 🛠️ Persyaratan Sistem
Sebelum menjalankan aplikasi, pastikan Anda telah menginstal:
* [Node.js](https://nodejs.org/) (Sangat direkomendasikan versi LTS terbaru, minimal v18.0.0+)
* [Git](https://git-scm.com/) (Opsional)

---

## 🚀 Cara Menjalankan di Komputer Lokal

### 1. Instalasi Dependensi
Ekstrak file `.zip` ini ke folder baru, kemudian buka terminal/dashboard CMD di folder tersebut dan jalankan perintah:
```bash
npm install
```

### 2. Atur Kunci API Gemini
Buat file baru bernama `.env` di direktori utama projek ini dan isi dengan kunci API Gemini Anda:
```env
GEMINI_API_KEY=KUNCI_API_GEMINI_ANDA_DI_SINI
```
> Anda bisa mendapatkan kunci API Gemini gratis dari [Google AI Studio](https://aistudio.google.com/).

### 3. Jalankan dalam Mode Pengembangan (Development)
Jalankan dev server dengan perintah:
```bash
npm run dev
```
Buka browser Anda dan akses halaman web di alamat: `http://localhost:3000`

---

## ☁️ Cara Deploy ke Google Cloud Run (Menjadikannya Web Online Sendiri)

Anda dapat dengan mudah mendeploy aplikasi full-stack ini secara langsung ke Google Cloud Run menggunakan terminal gcloud CLI Anda.

### Persiapan Akun Google Cloud:
1. Pastikan Anda sudah menginstal [Google Cloud SDK (gcloud CLI)](https://cloud.google.com/sdk/docs/install) di PC/Laptop Anda.
2. Login ke akun Google Anda melalui gcloud CLI:
   ```bash
   gcloud auth login
   ```
3. Atur ID Projek Google Cloud Anda:
   ```bash
   gcloud config set project ID_PROJEK_GOOGLE_CLOUD_ANDA
   ```

### Langkah Deploy:
1. Jalankan perintah deploy otomatis berikut di dalam terminal direktori projek Anda:
   ```bash
   gcloud run deploy nexon-academic --source . --port 3000 --allow-unauthenticated --region asia-east1
   ```
2. Terminal akan menanyakan beberapa konfigurasi dasar serta mengunggah source code ke Cloud Build untuk membuat kontainer bertenaga tinggi secara otomatis.
3. Setelah proses build selesai (sekitar 1-2 menit), Cloud Run akan memberikan **URL Publik unik** yang aman (HTTPS) yang bisa langsung dibuka siapapun melalui internet!

---

## 🌐 Menghubungkan ke Custom Domain (Domain Anda Sendiri)
Jika Anda sudah memiliki nama domain yang dibeli di penyedia domain luar (seperti Niagahoster, Domainesia, Namecheap, GoDaddy, dll.), Anda bisa mengarahkannya ke Cloud Run:

1. Buka halaman **Google Cloud Console** di bagian **Cloud Run**.
2. Pilih layanan `nexon-academic` yang baru Anda deploy.
3. Klik tab **Manage Custom Domains** (Kelola Domain Khusus) di atas panel.
4. Klik **Add Mapping** (Tambahkan Pemetaan), pilih domain Anda, dan ikuti instruksi DNS pemetaan.
5. Anda akan dipandu untuk menambahkan record **CNAME** atau **A (IP Address)** di DNS Management penyedia domain Anda.
6. Tunggu sekitar beberapa menit hingga beberapa jam untuk propagasi DNS dan sertifikat keamanan SSL gratis akan diterbitkan Google secara otomatis!

---

Selamat berinovasi dan belajar bersama NexonAcademic! 🎓✨
